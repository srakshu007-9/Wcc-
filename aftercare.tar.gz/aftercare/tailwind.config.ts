import type { Config } from "tailwindcss";

const config: Config = {
  content: ["./app/**/*.{ts,tsx}", "./components/**/*.{ts,tsx}", "./lib/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        cream: { DEFAULT: "#F6EFE4", dark: "#EBE1D0", light: "#FBF7F0" },
        terra: { DEFAULT: "#C8553A", dark: "#A8432C", light: "#E8896F" },
        ink: { DEFAULT: "#1F1B18", soft: "#4A423B", muted: "#7A6F65" },
        ok: { DEFAULT: "#3F7D58", soft: "#DCEBDF" },
        warn: { DEFAULT: "#B7791F", soft: "#F6E7C8" },
        crit: { DEFAULT: "#B23A3A", soft: "#F3D5D1" },
      },
      fontFamily: {
        sans: ["var(--font-inter)", "system-ui", "sans-serif"],
        display: ["var(--font-display)", "var(--font-inter)", "sans-serif"],
      },
      borderRadius: { xl2: "1.25rem" },
      boxShadow: { soft: "0 1px 2px rgba(31,27,24,.06), 0 8px 24px -8px rgba(31,27,24,.12)" },
    },
  },
  plugins: [],
};
export default config;
