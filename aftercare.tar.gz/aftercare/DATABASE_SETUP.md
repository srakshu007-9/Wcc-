# Database setup (Supabase)

1. Create a project at https://supabase.com (free tier is enough).
2. Open **SQL Editor**, paste the entire contents of `supabase/schema.sql`, and run it. It creates:
   - `profiles`, `cases`, `case_steps`, `documents`, `document_chunks` (pgvector, 1536 dims), `evidence`
   - `agent_runs`, `agent_events`, `actions`, `approvals`, `communications`
   - `blockers`, `followups`, `escalations`, `resolutions`, `state_transitions`
   - `evaluation_runs`, `audit_logs`
   - `match_chunks()` for per-case semantic search
   - a trigger that creates a profile on signup
   - a private storage bucket `case-documents`
   - row-level security on every table
3. **Authentication → Providers → Email**: for the one-click **Try the demo** button, turn **Confirm email** off. Leave it on if you only want real sign-ups (the demo button will then explain what to change).
4. **Project Settings → API**: copy the Project URL, `anon` key and `service_role` key into your environment (see `.env.example`).

## Security model

- Browsers only hold the `anon` key. RLS lets a signed-in user read only their own cases and everything linked to them.
- All writes to agent-owned tables happen server-side with the service-role key, after the API route has checked that the case belongs to the signed-in user (`ownedCase`). The service-role key must never be exposed to the client.
- Documents live in a private bucket under `<user_id>/<case_id>/…`. Deleting a case removes its rows (cascade) and its stored files.

## Re-running

The schema file uses `if not exists` for tables, but policies are created without it. To reset a dev project, drop the tables (or the schema) first, then re-run.
