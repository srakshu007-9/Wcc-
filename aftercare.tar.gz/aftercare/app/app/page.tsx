"use client";
import Link from "next/link";
import { PlusCircle } from "lucide-react";
import { useApi } from "@/lib/client";
import type { CaseRow } from "@/lib/types";
import { ErrorBox, Spinner, Stat } from "@/components/ui";
import { CaseRowCard } from "@/components/CaseRowCard";
import { ActivityFeed } from "@/components/ActivityFeed";
import { SafetyPanel } from "@/components/SafetyPanel";

export default function Overview() {
  const cases = useApi<CaseRow[]>("/api/cases", { pollMs: 6000 });
  const activity = useApi<any[]>("/api/activity", { pollMs: 6000 });
  const list = cases.data ?? [];
  const active = list.filter((c) => c.status !== "COMPLETED" && c.status !== "FAILED");
  const blocked = list.filter((c) => ["BLOCKED", "FOLLOW_UP_REQUIRED", "ESCALATION_REQUIRED", "HUMAN_INTERVENTION_REQUIRED"].includes(c.status) || !!c.open_blocker);
  const monitoring = list.filter((c) => c.status === "MONITORING");
  const done = list.filter((c) => c.status === "COMPLETED");
  const needs = list.filter((c) => c.pending_approval);

  return (
    <div className="mx-auto max-w-6xl">
      <section className="rounded-[1.75rem] bg-terra p-7 text-cream-light sm:p-10">
        <h1 className="font-display text-4xl font-extrabold leading-tight sm:text-6xl">Your cases are being watched.</h1>
        <p className="mt-3 max-w-xl text-cream-light/90">Each case keeps its own state, evidence and history. AFTERCARE only closes one when the outcome is verified.</p>
        <Link href="/app/new" className="btn mt-6 bg-cream-light text-ink hover:bg-white"><PlusCircle className="h-4 w-4" aria-hidden /> Create a case</Link>
      </section>

      {cases.error && <div className="mt-6"><ErrorBox message={cases.error} onRetry={cases.reload} /></div>}

      <section aria-label="Case counts" className="mt-6 grid grid-cols-2 gap-4 lg:grid-cols-5">
        <Stat label="Active cases" value={active.length} />
        <Stat label="Blocked" value={blocked.length} tone={blocked.length ? "crit" : undefined} />
        <Stat label="Monitoring" value={monitoring.length} />
        <Stat label="Resolution verified" value={done.length} tone={done.length ? "ok" : undefined} />
        <Stat label="Needs approval" value={needs.length} tone={needs.length ? "warn" : undefined} />
      </section>

      <div className="mt-8 grid gap-8 lg:grid-cols-[1.5fr_1fr]">
        <section aria-labelledby="active-h">
          <h2 id="active-h" className="font-display text-2xl font-extrabold">Active cases</h2>
          <div className="mt-4 space-y-4">
            {cases.loading && <Spinner label="Loading cases" />}
            {!cases.loading && active.length === 0 && (
              <div className="card p-8 text-center">
                <p className="font-display text-xl font-extrabold">No active cases yet</p>
                <p className="mt-1 text-ink-muted">Describe something you're trying to get finished and AFTERCARE will take it from there.</p>
                <Link href="/app/new" className="btn-primary mt-4">Create your first case</Link>
              </div>
            )}
            {active.map((c) => <CaseRowCard key={c.id} c={c} />)}
          </div>
        </section>
        <section aria-labelledby="feed-h">
          <h2 id="feed-h" className="font-display text-2xl font-extrabold">Agent activity</h2>
          <div className="card mt-4 max-h-[34rem] overflow-y-auto p-5">
            <ActivityFeed events={(activity.data ?? []).slice(0, 12)} />
          </div>
        </section>
      </div>
      <div className="mt-10"><SafetyPanel /></div>
    </div>
  );
}
