"use client";
import Link from "next/link";
import { useApi } from "@/lib/client";
import type { CaseRow } from "@/lib/types";
import { ErrorBox, Spinner } from "@/components/ui";
import { CaseRowCard } from "@/components/CaseRowCard";

export default function Cases() {
  const { data, error, loading, reload } = useApi<CaseRow[]>("/api/cases", { pollMs: 6000 });
  return (
    <div className="mx-auto max-w-4xl">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <h1 className="font-display text-4xl font-extrabold">My cases</h1>
        <Link href="/app/new" className="btn-primary">Create case</Link>
      </div>
      <div className="mt-6 space-y-4">
        {error && <ErrorBox message={error} onRetry={reload} />}
        {loading && <Spinner label="Loading cases" />}
        {!loading && !error && data?.length === 0 && (
          <div className="card p-8 text-center">
            <p className="font-display text-xl font-extrabold">Nothing here yet</p>
            <p className="mt-1 text-ink-muted">Create a case and it will appear here with its live state.</p>
          </div>
        )}
        {data?.map((c) => <CaseRowCard key={c.id} c={c} />)}
      </div>
    </div>
  );
}
