"use client";
import { use, useState } from "react";
import { useRouter } from "next/navigation";
import { CheckCircle2, Circle, CircleDot, FileText, Trash2 } from "lucide-react";
import { api, useApi } from "@/lib/client";
import { caseId as fmtId, type CaseDetail } from "@/lib/types";
import { Confidence, ErrorBox, Progress, SimulatedTag, Spinner, StatePill, WhyAsking, dateTimeShort } from "@/components/ui";
import { ApprovalCard } from "@/components/case/ApprovalCard";
import { BlockerCard } from "@/components/case/BlockerCard";
import { ResolutionCard } from "@/components/case/ResolutionCard";
import { StateHistory, Timeline } from "@/components/case/Timeline";
import { AgentFlow } from "@/components/case/AgentFlow";
import { DemoPanel } from "@/components/case/DemoPanel";
import { ActivityFeed } from "@/components/ActivityFeed";
import { SafetyPanel } from "@/components/SafetyPanel";

const WORKING = ["UNDERSTANDING", "EVIDENCE_COLLECTION", "PLANNING"];

function Section({ id, title, children }: { id: string; title: string; children: React.ReactNode }) {
  return (
    <section aria-labelledby={id} className="card p-6">
      <h2 id={id} className="font-display text-2xl font-extrabold">{title}</h2>
      <div className="mt-4">{children}</div>
    </section>
  );
}

export default function CasePage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params);
  const router = useRouter();
  const [busy, setBusy] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [tab, setTab] = useState<"workspace" | "agent">("workspace");
  const { data: d, error: loadError, loading, reload } = useApi<CaseDetail>(`/api/cases/${id}`, {
    pollMs: (x) => (busy || (x && WORKING.includes(x.case.status)) ? 1500 : 7000),
  });
  const demo = process.env.NEXT_PUBLIC_DEMO_MODE !== "false";

  async function run(label: string, url: string, json?: unknown) {
    setBusy(label);
    setError(null);
    setNotice(null);
    try {
      const r = await api<{ message?: string } | null>(url, { method: "POST", json });
      if (r && typeof r === "object" && "message" in r && r.message) setNotice(r.message);
      await reload();
    } catch (e) {
      setError(e instanceof Error ? e.message : "That action failed.");
      await reload();
    } finally {
      setBusy(null);
    }
  }

  async function upload(f: File) {
    setBusy("upload");
    setError(null);
    try {
      const fd = new FormData();
      fd.set("caseId", id);
      fd.set("kind", "resolution");
      fd.set("file", f);
      await api("/api/documents/upload", { method: "POST", body: fd });
      await reload();
    } catch (e) {
      setError(e instanceof Error ? e.message : "Upload failed.");
    } finally {
      setBusy(null);
    }
  }

  async function remove() {
    if (!confirm("Delete this case, its history and its stored documents? This cannot be undone.")) return;
    setBusy("delete");
    try {
      await api(`/api/cases/${id}`, { method: "DELETE" });
      router.push("/app/cases");
    } catch (e) {
      setError(e instanceof Error ? e.message : "Delete failed.");
      setBusy(null);
    }
  }

  if (loading) return <Spinner label="Loading case" />;
  if (loadError || !d) return <ErrorBox message={loadError ?? "Case not found."} onRetry={reload} />;

  const c = d.case;
  const pending = d.actions.find((a) => a.status === "pending_approval");
  const openBlocker = [...d.blockers].reverse().find((b) => b.status === "open");
  const found = d.evidence.filter((e) => e.kind === "found");
  const missing = d.evidence.filter((e) => e.kind === "missing");
  const docName = (docId: string | null) => d.documents.find((x) => x.id === docId)?.filename ?? "document";
  const failed = c.status === "FAILED" || c.status === "HUMAN_INTERVENTION_REQUIRED";

  return (
    <div className="mx-auto max-w-5xl space-y-6">
      <header className="card p-6 sm:p-8">
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div className="min-w-0">
            <p className="text-sm font-semibold text-terra">Case #{fmtId(c.case_number)}</p>
            <h1 className="font-display text-4xl font-extrabold leading-tight sm:text-5xl">{c.title}</h1>
          </div>
          <div className="flex items-center gap-3">
            <StatePill state={c.status} />
            <button onClick={remove} disabled={!!busy} className="btn-ghost !p-2.5" aria-label="Delete case"><Trash2 className="h-4 w-4" aria-hidden /></button>
          </div>
        </div>
        <div className="mt-5 flex items-center gap-4">
          <div className="flex-1"><Progress value={c.progress} /></div>
          <span className="font-display text-2xl font-extrabold">{c.progress}%</span>
        </div>
        <div className="mt-3 flex flex-wrap items-center gap-x-6 gap-y-1 text-sm">
          <Confidence value={c.confidence} />
          <span className="text-ink-muted">Escalation level {c.escalation_level}</span>
          {c.sim_clock_offset_hours > 0 && <SimulatedTag>{`Case clock +${c.sim_clock_offset_hours}h (simulated)`}</SimulatedTag>}
          <span className="text-ink-muted">Updated {dateTimeShort(c.updated_at)}</span>
        </div>
      </header>

      {error && <ErrorBox message={error} />}
      {notice && <p role="status" className="rounded-xl bg-ok-soft p-3 text-sm font-semibold text-ok">{notice}</p>}
      {WORKING.includes(c.status) && <div className="card p-5"><Spinner label="The agents are working on this case…" /></div>}
      {failed && (
        <div className="card border-crit/40 p-5">
          <p className="font-semibold text-crit">{c.status === "FAILED" ? "Action blocked" : "Needs human intervention"}</p>
          <p className="mt-1 text-sm text-ink-soft">
            {[...d.events].reverse().find((e) => e.type === "action_blocked" || e.type === "human_intervention")?.message ?? "Something needs your attention."}
          </p>
          <button className="btn-primary mt-3" disabled={!!busy} onClick={() => run(c.status === "FAILED" ? "retry" : "monitor", c.status === "FAILED" ? `/api/cases/${id}/analyze` : `/api/cases/${id}/monitor`)}>
            {busy ? "Retrying…" : "Try again"}
          </button>
        </div>
      )}

      {openBlocker && c.status !== "COMPLETED" && <BlockerCard blocker={openBlocker} />}

      {pending && (
        <ApprovalCard
          key={pending.id}
          action={pending}
          busy={!!busy}
          onApprove={(edits) => run("approve", `/api/cases/${id}/approve`, { actionId: pending.id, ...edits })}
          onReject={(note) => run("reject", `/api/cases/${id}/reject`, { actionId: pending.id, note })}
        />
      )}

      <ResolutionCard d={d} />

      {demo && c.status !== "COMPLETED" && <DemoPanel c={c} busy={busy} run={run} onUpload={upload} />}

      <div role="tablist" aria-label="Case views" className="flex gap-2">
        {(["workspace", "agent"] as const).map((t) => (
          <button key={t} role="tab" aria-selected={tab === t} onClick={() => setTab(t)} className={`btn ${tab === t ? "bg-ink text-cream-light" : "border border-ink/20"}`}>
            {t === "workspace" ? "Case workspace" : "Live agent"}
          </button>
        ))}
      </div>

      {tab === "agent" ? (
        <AgentFlow d={d} />
      ) : (
        <div className="space-y-6">
          <div className="grid gap-6 md:grid-cols-2">
            <Section id="goal" title="Goal">
              <p className="text-lg font-semibold">{c.desired_outcome ?? c.original_goal}</p>
              <p className="mt-2 text-sm text-ink-muted">You said: “{c.original_goal}”</p>
              {c.category && <p className="mt-2 text-sm">Category: <span className="font-semibold">{c.category}</span></p>}
              {c.missing_information?.length > 0 && <p className="mt-2 text-sm text-ink-soft">Still unknown: {c.missing_information.join("; ")}</p>}
            </Section>
            <Section id="state" title="Current state">
              <p className="text-lg font-semibold">{c.current_state_summary ?? "Not assessed yet"}</p>
              <p className="mt-2 text-sm">Next action: <span className="font-semibold">{c.next_action ?? "None"}</span></p>
              {c.response_due_at && <p className="mt-1 text-sm text-ink-muted">Response expected by {dateTimeShort(c.response_due_at)}</p>}
            </Section>
          </div>

          <Section id="evidence" title="Evidence">
            {found.length === 0 && missing.length === 0 && <p className="text-ink-muted">No evidence assessed yet.</p>}
            {found.length === 0 && missing.length > 0 && <p className="mb-3 font-semibold text-warn">INSUFFICIENT_EVIDENCE: nothing in the uploaded documents proves this case yet.</p>}
            <ul className="space-y-3">
              {found.map((e) => (
                <li key={e.id} className="flex gap-3 rounded-xl bg-cream p-3 text-sm">
                  <CheckCircle2 className="mt-0.5 h-5 w-5 shrink-0 text-ok" aria-hidden />
                  <div>
                    <p className="font-semibold">{e.label}</p>
                    <p>{e.fact}</p>
                    <p className="mt-1 inline-flex items-center gap-1 text-ink-muted"><FileText className="h-3.5 w-3.5" aria-hidden /> {docName(e.document_id)}{e.page ? `, page ${e.page}` : ""} · “{e.quote}”</p>
                  </div>
                </li>
              ))}
              {missing.map((e) => (
                <li key={e.id} className="rounded-xl bg-warn-soft p-3 text-sm">
                  <p className="font-semibold text-warn">Missing: {e.label}</p>
                  <div className="mt-2"><WhyAsking title="Why do we need this?">{e.fact}</WhyAsking></div>
                </li>
              ))}
            </ul>
            {d.documents.length > 0 && (
              <p className="mt-4 text-sm text-ink-muted">
                {d.documents.length} document(s): {d.documents.map((x) => `${x.filename}${x.kind === "resolution" ? " (resolution)" : ""}`).join(", ")}
              </p>
            )}
          </Section>

          <Section id="plan" title="Agent plan">
            {d.steps.length === 0 ? <p className="text-ink-muted">No plan yet.</p> : (
              <ol className="space-y-3">
                {d.steps.map((s) => (
                  <li key={s.id} className="flex gap-3">
                    {s.status === "done" ? <CheckCircle2 className="mt-0.5 h-5 w-5 shrink-0 text-ok" aria-label="done" /> : s.status === "active" ? <CircleDot className="mt-0.5 h-5 w-5 shrink-0 text-terra" aria-label="current" /> : <Circle className="mt-0.5 h-5 w-5 shrink-0 text-ink/30" aria-label="pending" />}
                    <div>
                      <p className={`font-semibold ${s.status === "done" ? "text-ink-muted line-through" : ""}`}>
                        {s.title} {s.requires_approval && <span className="ml-1 rounded-full bg-warn-soft px-2 py-0.5 text-xs font-semibold text-warn no-underline">Needs your approval</span>}
                      </p>
                      <p className="text-sm text-ink-soft">{s.description}</p>
                    </div>
                  </li>
                ))}
              </ol>
            )}
          </Section>

          <Section id="timeline" title="Timeline"><Timeline events={d.events} /></Section>

          <Section id="state-history" title="State machine history">
            <StateHistory transitions={d.transitions} current={c.status} />
          </Section>

          <Section id="comms" title="Communications">
            {d.communications.length === 0 ? <p className="text-ink-muted">Nothing has been sent or received yet.</p> : (
              <ul className="space-y-3">
                {d.communications.map((m) => (
                  <li key={m.id} className={`rounded-xl border p-4 text-sm ${m.direction === "outbound" ? "border-terra/30 bg-terra/5" : "border-ink/10 bg-cream"}`}>
                    <p className="flex flex-wrap items-center gap-2 font-semibold">
                      {m.direction === "outbound" ? "Sent" : "Received"} · {m.counterparty} {m.simulated && <SimulatedTag />}
                    </p>
                    {m.subject && <p className="mt-1 font-semibold">{m.subject}</p>}
                    <p className="mt-1 whitespace-pre-wrap">{m.body}</p>
                    <p className="mt-1 text-xs text-ink-muted">{dateTimeShort(m.created_at)}</p>
                  </li>
                ))}
              </ul>
            )}
          </Section>

          <Section id="activity" title="Case activity"><ActivityFeed events={[...d.events].reverse().slice(0, 20)} showCase={false} /></Section>

          <Section id="audit" title="Audit trail">
            <ul className="space-y-2 text-sm">
              {d.audit.length === 0 && <li className="text-ink-muted">No audit entries yet.</li>}
              {[...d.audit].reverse().map((a) => (
                <li key={a.id} className="flex flex-wrap gap-x-3">
                  <span className="text-ink-muted">{dateTimeShort(a.created_at)}</span>
                  <span className="font-semibold">{a.actor}</span>
                  <span>{String(a.event).replace(/_/g, " ")}</span>
                </li>
              ))}
            </ul>
          </Section>

          <SafetyPanel />
        </div>
      )}
    </div>
  );
}
