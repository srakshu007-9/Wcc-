"use client";
import { useApi } from "@/lib/client";
import { ErrorBox, Spinner } from "@/components/ui";
import { ActivityFeed } from "@/components/ActivityFeed";

export default function Activity() {
  const { data, error, loading, reload } = useApi<any[]>("/api/activity", { pollMs: 5000 });
  return (
    <div className="mx-auto max-w-3xl">
      <h1 className="font-display text-4xl font-extrabold">Activity</h1>
      <p className="mt-2 text-ink-soft">Every agent run, approval and state change across your cases, newest first. Each line is written by the backend when it happens.</p>
      <div className="card mt-6 p-6">
        {error && <ErrorBox message={error} onRetry={reload} />}
        {loading && <Spinner label="Loading activity" />}
        {data && <ActivityFeed events={data} />}
      </div>
    </div>
  );
}
