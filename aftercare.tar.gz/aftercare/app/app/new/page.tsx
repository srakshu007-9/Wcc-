"use client";
import { useCallback, useEffect, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { AnimatePresence, motion } from "framer-motion";
import { CheckCircle2, FileText, Loader2, Trash2, UploadCloud } from "lucide-react";
import { api } from "@/lib/client";
import { ErrorBox } from "@/components/ui";

const ACCEPT = ".pdf,.docx,.png,.jpg,.jpeg,.txt";
const EXAMPLE = "My scholarship was approved two months ago but I haven't received the payment.";

const STAGES = [
  ["UNDERSTANDING", "Understanding goal"],
  ["EVIDENCE_COLLECTION", "Reading evidence"],
  ["PLANNING", "Building case and planning next actions"],
  ["WAITING_FOR_APPROVAL", "Preparing your approval"],
] as const;

type Doc = { id: string; filename: string; extraction_status: string; extraction_error: string | null; page_count: number | null };

export default function NewCase() {
  const router = useRouter();
  const [goal, setGoal] = useState("");
  const [caseId, setCaseId] = useState<string | null>(null);
  const [docs, setDocs] = useState<Doc[]>([]);
  const [uploading, setUploading] = useState(false);
  const [running, setRunning] = useState(false);
  const [status, setStatus] = useState<string>("NEW");
  const [error, setError] = useState<string | null>(null);
  const [drag, setDrag] = useState(false);
  const input = useRef<HTMLInputElement>(null);
  const goalOk = goal.trim().length >= 10;

  // The case row must exist before documents can be attached to it.
  const ensureCase = useCallback(async () => {
    if (caseId) return caseId;
    const c = await api<{ id: string }>("/api/cases", { method: "POST", json: { goal: goal.trim() } });
    setCaseId(c.id);
    return c.id;
  }, [caseId, goal]);

  async function upload(files: FileList | File[]) {
    if (!goalOk) {
      setError("Describe your goal first (at least 10 characters), then add documents.");
      return;
    }
    setError(null);
    setUploading(true);
    try {
      const id = await ensureCase();
      for (const f of Array.from(files)) {
        const fd = new FormData();
        fd.set("caseId", id);
        fd.set("file", f);
        try {
          const d = await api<Doc>("/api/documents/upload", { method: "POST", body: fd });
          setDocs((x) => [...x, d]);
        } catch (e) {
          setError(`${f.name}: ${e instanceof Error ? e.message : "upload failed"}`);
        }
      }
    } catch (e) {
      setError(e instanceof Error ? e.message : "Could not start the case.");
    } finally {
      setUploading(false);
    }
  }

  async function addSamples() {
    if (!goalOk) {
      setGoal(EXAMPLE);
    }
    setError(null);
    setUploading(true);
    try {
      const id = caseId ?? (await api<{ id: string }>("/api/cases", { method: "POST", json: { goal: (goalOk ? goal : EXAMPLE).trim() } })).id;
      setCaseId(id);
      const d = await api<Doc[]>(`/api/cases/${id}/samples`, { method: "POST" });
      setDocs((x) => [...x, ...d]);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Could not add sample documents.");
    } finally {
      setUploading(false);
    }
  }

  async function analyze() {
    setError(null);
    setRunning(true);
    try {
      const id = await ensureCase();
      setStatus("UNDERSTANDING");
      await api(`/api/cases/${id}/analyze`, { method: "POST" });
      router.push(`/app/cases/${id}`);
    } catch (e) {
      setRunning(false);
      setError(e instanceof Error ? e.message : "Analysis failed.");
    }
  }

  // Real progress: poll the case status while the analysis request is in flight.
  useEffect(() => {
    if (!running || !caseId) return;
    const t = setInterval(async () => {
      try {
        const c = await api<{ case: { status: string } }>(`/api/cases/${caseId}`);
        setStatus(c.case.status);
      } catch {
        /* the analyze request reports errors */
      }
    }, 1200);
    return () => clearInterval(t);
  }, [running, caseId]);

  const stageIdx = Math.max(0, STAGES.findIndex(([s]) => s === status));

  if (running) {
    return (
      <div className="mx-auto max-w-xl py-10">
        <h1 className="font-display text-4xl font-extrabold">AFTERCARE is building your case</h1>
        <ol className="mt-8 space-y-4" aria-live="polite">
          {STAGES.map(([s, label], i) => (
            <motion.li key={s} animate={{ opacity: i <= stageIdx ? 1 : 0.35 }} className="flex items-center gap-3 text-lg">
              {i < stageIdx || status === "WAITING_FOR_APPROVAL" ? <CheckCircle2 className="h-6 w-6 text-ok" aria-hidden /> : i === stageIdx ? <Loader2 className="h-6 w-6 animate-spin text-terra" aria-hidden /> : <span className="h-6 w-6 rounded-full border-2 border-ink/20" aria-hidden />}
              {label}
            </motion.li>
          ))}
        </ol>
        {error && <div className="mt-6"><ErrorBox message={error} /></div>}
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-3xl">
      <h1 className="font-display text-4xl font-extrabold leading-tight sm:text-6xl">What are you trying to get finished?</h1>
      <label htmlFor="goal" className="sr-only">Describe your goal</label>
      <textarea
        id="goal"
        value={goal}
        onChange={(e) => setGoal(e.target.value)}
        rows={4}
        maxLength={4000}
        disabled={!!caseId && docs.length > 0 && false}
        placeholder={EXAMPLE}
        className="field mt-6 resize-y text-lg"
      />
      <button className="mt-2 text-sm font-semibold text-terra hover:underline" onClick={() => setGoal(EXAMPLE)} type="button">Use the scholarship example</button>

      <h2 className="mt-8 font-display text-2xl font-extrabold">Upload evidence</h2>
      <div
        onDragOver={(e) => { e.preventDefault(); setDrag(true); }}
        onDragLeave={() => setDrag(false)}
        onDrop={(e) => { e.preventDefault(); setDrag(false); upload(e.dataTransfer.files); }}
        className={`mt-3 flex flex-col items-center rounded-2xl border-2 border-dashed p-8 text-center transition-colors ${drag ? "border-terra bg-terra/5" : "border-ink/25 bg-cream-light"}`}
      >
        <UploadCloud className="h-8 w-8 text-terra" aria-hidden />
        <p className="mt-2 font-semibold">Drag files here, or</p>
        <button type="button" className="btn-dark mt-3" onClick={() => input.current?.click()} disabled={uploading}>
          {uploading ? "Uploading…" : "Choose files"}
        </button>
        <input ref={input} type="file" multiple accept={ACCEPT} className="sr-only" aria-label="Upload evidence files" onChange={(e) => e.target.files && upload(e.target.files)} />
        <p className="mt-3 text-sm text-ink-muted">PDF, DOCX, TXT, PNG or JPG, up to 8 MB each. Images are stored but need a text version to count as evidence.</p>
        <button type="button" className="mt-3 text-sm font-semibold text-terra hover:underline" onClick={addSamples} disabled={uploading}>
          No files handy? Add sample scholarship documents (demo)
        </button>
      </div>

      <ul className="mt-4 space-y-2" aria-label="Uploaded documents">
        <AnimatePresence>
          {docs.map((d) => (
            <motion.li key={d.id} initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} className="card flex items-center gap-3 p-3">
              <FileText className="h-5 w-5 text-terra" aria-hidden />
              <div className="min-w-0 flex-1">
                <p className="truncate font-semibold">{d.filename}</p>
                <p className={`text-xs ${d.extraction_status === "ok" ? "text-ok" : "text-warn"}`}>
                  {d.extraction_status === "ok" ? `Text read${d.page_count ? ` · ${d.page_count} page(s)` : ""}` : d.extraction_error ?? "No text could be read from this file."}
                </p>
              </div>
              <Trash2 className="hidden" aria-hidden />
            </motion.li>
          ))}
        </AnimatePresence>
      </ul>

      {error && <div className="mt-4"><ErrorBox message={error} /></div>}

      <button className="btn-primary mt-8 !px-8 !py-4 text-base" onClick={analyze} disabled={!goalOk || uploading}>
        Let AFTERCARE analyze
      </button>
      {!goalOk && <p className="mt-2 text-sm text-ink-muted">Add a sentence or two about your goal to continue.</p>}
    </div>
  );
}
