import { redirect } from "next/navigation";
import { AppShell } from "@/components/AppShell";
import { serverClient } from "@/lib/supabase/server";

export const dynamic = "force-dynamic";

export default async function AppLayout({ children }: { children: React.ReactNode }) {
  if (!process.env.NEXT_PUBLIC_SUPABASE_URL || !process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY) {
    return (
      <main id="main" className="mx-auto max-w-xl px-5 py-20">
        <h1 className="font-display text-4xl font-extrabold">Setup needed</h1>
        <p className="mt-3 text-ink-soft">Supabase environment variables are missing. Copy .env.example to .env.local, fill in your Supabase and OpenAI values, then restart. DEPLOYMENT.md has the full steps.</p>
      </main>
    );
  }
  const sb = await serverClient();
  const { data } = await sb.auth.getUser();
  if (!data.user) redirect("/login");
  return <AppShell email={data.user.email ?? undefined}>{children}</AppShell>;
}
