"use client";
import { useState } from "react";
import { ChevronDown } from "lucide-react";
import { api, useApi } from "@/lib/client";
import { Check, ErrorBox, Spinner } from "@/components/ui";

type Metric = { key: string; label: string; passed: number; total: number; score: number | null; cases: { id: string; passed: boolean; detail: string }[] };
type Run = { id: string; created_at: string; model: string; total_cases: number; results: Metric[] };

const LABELS: [string, string][] = [
  ["goal_understanding", "Goal understanding accuracy"],
  ["evidence_extraction", "Evidence extraction accuracy"],
  ["evidence_grounding", "Evidence grounding"],
  ["plan_correctness", "Plan correctness"],
  ["blocker_detection", "Blocker detection"],
  ["state_transitions", "State transition correctness"],
  ["followup_correctness", "Follow-up correctness"],
  ["resolution_verification", "Resolution verification accuracy"],
  ["unsupported_action_rate", "Unsupported-action rate (lower is better)"],
  ["approval_compliance", "Human-approval compliance"],
];

export default function Evaluations() {
  const { data, error, loading, reload } = useApi<Run[]>("/api/evaluations");
  const [running, setRunning] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  const [open, setOpen] = useState<string | null>(null);
  const latest = data?.[0];

  async function run() {
    setRunning(true);
    setErr(null);
    try {
      await api("/api/evaluations/run", { method: "POST" });
      await reload();
    } catch (e) {
      setErr(e instanceof Error ? e.message : "Evaluation failed.");
    } finally {
      setRunning(false);
    }
  }

  return (
    <div className="mx-auto max-w-4xl">
      <h1 className="font-display text-4xl font-extrabold">Evaluations</h1>
      <p className="mt-2 max-w-2xl text-ink-soft">
        A hand-labelled benchmark runs the real prompts and guards against the configured model. Scores below are measured from the last run. Nothing is estimated.
      </p>
      <div className="mt-6 flex flex-wrap items-center gap-4">
        <button className="btn-primary" onClick={run} disabled={running}>{running ? "Running benchmark…" : "Run evaluation"}</button>
        {running && <Spinner label="This calls the model about 20 times and can take a minute" />}
        {latest && <p className="text-sm text-ink-muted">Last run {new Date(latest.created_at).toLocaleString()} · model {latest.model}</p>}
      </div>
      {(err || error) && <div className="mt-4"><ErrorBox message={(err || error)!} onRetry={run} /></div>}
      {loading && <div className="mt-6"><Spinner label="Loading results" /></div>}

      <ul className="mt-8 space-y-3">
        {LABELS.map(([key, label]) => {
          const m = latest?.results.find((r) => r.key === key);
          const isRate = key === "unsupported_action_rate";
          const good = m && m.score !== null ? (isRate ? m.score === 0 : m.score >= 0.8) : null;
          return (
            <li key={key} className="card">
              <button className="flex w-full items-center justify-between gap-4 p-5 text-left" onClick={() => setOpen(open === key ? null : key)} aria-expanded={open === key} disabled={!m}>
                <span className="font-semibold">{label}</span>
                <span className="flex items-center gap-3">
                  {m && m.score !== null ? (
                    <>
                      <span className={`font-display text-2xl font-extrabold ${good ? "text-ok" : "text-warn"}`}>{Math.round(m.score * 100)}%</span>
                      <span className="text-sm text-ink-muted">{isRate ? `${m.total - m.passed} of ${m.total} cases flagged` : `${m.passed} of ${m.total} cases passed`}</span>
                      <ChevronDown className={`h-4 w-4 transition-transform ${open === key ? "rotate-180" : ""}`} aria-hidden />
                    </>
                  ) : (
                    <span className="text-sm font-semibold text-ink-muted">Not evaluated yet</span>
                  )}
                </span>
              </button>
              {m && open === key && (
                <ul className="space-y-2 border-t border-ink/10 p-5 text-sm">
                  {m.cases.map((c) => (
                    <li key={c.id} className="flex items-start gap-2">
                      <span className="mt-0.5"><Check ok={c.passed} /></span>
                      <div><p className="font-semibold">{c.id}</p><p className="text-ink-soft">{c.detail}</p></div>
                    </li>
                  ))}
                </ul>
              )}
            </li>
          );
        })}
      </ul>
      <p className="mt-6 text-sm text-ink-muted">
        The benchmark is small by design (see EVALUATION.md). Treat results as regression checks for these scenarios, not as general accuracy claims.
      </p>
    </div>
  );
}
