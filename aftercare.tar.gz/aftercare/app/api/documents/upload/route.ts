import { route } from "@/lib/api";
import { AppError } from "@/lib/supabase/admin";
import { ownedCase } from "@/lib/workflow/events";
import { ingestDocument } from "@/lib/retrieval/store";
import { addResolutionEvidence } from "@/lib/workflow/orchestrator";
import { z } from "zod";

export const maxDuration = 60;

const Fields = z.object({ caseId: z.string().uuid(), kind: z.enum(["evidence", "resolution"]).default("evidence") });

export const POST = route(async (user, req) => {
  const form = await req.formData().catch(() => {
    throw new AppError("BAD_FORM", "Upload must be multipart/form-data.", 400);
  });
  const f = Fields.parse({ caseId: form.get("caseId"), kind: form.get("kind") ?? "evidence" });
  const file = form.get("file");
  if (!(file instanceof File)) throw new AppError("NO_FILE", "No file was attached.", 400);
  const buffer = Buffer.from(await file.arrayBuffer());
  if (f.kind === "resolution") {
    await addResolutionEvidence(f.caseId, user.id, { filename: file.name, mime: file.type, buffer });
    return { uploaded: true };
  }
  const c = await ownedCase(f.caseId, user.id);
  if (c.status !== "NEW") throw new AppError("INVALID_STATE", "Evidence documents can only be added before analysis.", 409);
  return ingestDocument({ userId: user.id, caseId: f.caseId, filename: file.name, mime: file.type, buffer });
});
