import { route, jsonBody } from "@/lib/api";
import { CreateCaseInput } from "@/lib/schemas";
import { createCase } from "@/lib/workflow/orchestrator";
import { listCases } from "@/lib/workflow/read";

export const GET = route(async (user) => listCases(user.id));

export const POST = route(async (user, req) => {
  const input = CreateCaseInput.parse(await jsonBody(req));
  return createCase(user.id, input.goal);
});
