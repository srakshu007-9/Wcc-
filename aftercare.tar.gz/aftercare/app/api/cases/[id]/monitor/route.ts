import { route } from "@/lib/api";
import { monitorCase } from "@/lib/workflow/orchestrator";

export const maxDuration = 120;

export const POST = route(async (user, _req, ctx) => monitorCase((await ctx.params).id, user.id));
