import { route, jsonBody } from "@/lib/api";
import { RejectInput } from "@/lib/schemas";
import { rejectAction } from "@/lib/workflow/orchestrator";

export const maxDuration = 120;

export const POST = route(async (user, req, ctx) => {
  const i = RejectInput.parse(await jsonBody(req));
  return rejectAction((await ctx.params).id, user.id, i.actionId, i.note);
});
