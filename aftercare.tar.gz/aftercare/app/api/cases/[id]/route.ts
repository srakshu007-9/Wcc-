import { route } from "@/lib/api";
import { caseDetail } from "@/lib/workflow/read";
import { deleteCase } from "@/lib/workflow/orchestrator";

export const maxDuration = 60;

export const GET = route(async (user, _req, ctx) => caseDetail((await ctx.params).id, user.id));

export const DELETE = route(async (user, _req, ctx) => {
  await deleteCase((await ctx.params).id, user.id);
  return { deleted: true };
});
