import { route, jsonBody } from "@/lib/api";
import { ApproveInput } from "@/lib/schemas";
import { approveAction } from "@/lib/workflow/orchestrator";

export const maxDuration = 60;

export const POST = route(async (user, req, ctx) => {
  const i = ApproveInput.parse(await jsonBody(req));
  return approveAction((await ctx.params).id, user.id, i.actionId, { body: i.editedBody, subject: i.editedSubject });
});
