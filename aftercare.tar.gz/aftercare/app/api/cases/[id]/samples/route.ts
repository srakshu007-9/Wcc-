import { route } from "@/lib/api";
import { AppError } from "@/lib/supabase/admin";
import { ownedCase } from "@/lib/workflow/events";
import { ingestDocument } from "@/lib/retrieval/store";

export const maxDuration = 60;

// Demo sample documents (clearly labeled). Real text is extracted, chunked, embedded and analysed like any upload.
const SAMPLES = [
  {
    filename: "approval.txt",
    text: `SCHOLARSHIP APPROVAL LETTER (DEMO SAMPLE)\n\nWe are pleased to inform you that your scholarship application has been approved.\nApplication Reference: SCH-2291\nThe scholarship amount will be disbursed to the registered bank account after fee verification.\n\nOffice of Student Financial Aid`,
  },
  {
    filename: "fee_receipt.txt",
    text: `FEE RECEIPT (DEMO SAMPLE)\n\nTuition fee for the current semester has been received.\nReceipt status: Paid by student.\nThis receipt does not relate to any scholarship payment.`,
  },
  {
    filename: "application.txt",
    text: `SCHOLARSHIP APPLICATION FORM (DEMO SAMPLE)\n\nApplicant has applied for the merit scholarship.\nApplication Reference: SCH-2291\nPayment mode requested: Direct bank transfer to the registered account.`,
  },
];

export const POST = route(async (user, _req, ctx) => {
  const caseId = (await ctx.params).id;
  const c = await ownedCase(caseId, user.id);
  if (c.status !== "NEW") throw new AppError("INVALID_STATE", "Sample documents can only be added before analysis.", 409);
  const docs = [];
  for (const s of SAMPLES)
    docs.push(await ingestDocument({ userId: user.id, caseId, filename: s.filename, mime: "text/plain", buffer: Buffer.from(s.text) }));
  return docs;
});
