import { route } from "@/lib/api";
import { advanceCase } from "@/lib/workflow/orchestrator";
import { AppError } from "@/lib/supabase/admin";

export const maxDuration = 120;

export const POST = route(async (user, _req, ctx) => {
  if (process.env.NEXT_PUBLIC_DEMO_MODE === "false") throw new AppError("DEMO_DISABLED", "Demo Mode is disabled in this deployment.", 403);
  return advanceCase((await ctx.params).id, user.id);
});
