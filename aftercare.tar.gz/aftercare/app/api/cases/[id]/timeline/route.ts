import { route } from "@/lib/api";
import { caseDetail } from "@/lib/workflow/read";

export const GET = route(async (user, _req, ctx) => {
  const d = await caseDetail((await ctx.params).id, user.id);
  return { events: d.events, transitions: d.transitions };
});
