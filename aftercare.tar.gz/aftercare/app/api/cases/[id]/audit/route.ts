import { route } from "@/lib/api";
import { caseDetail } from "@/lib/workflow/read";

export const GET = route(async (user, _req, ctx) => (await caseDetail((await ctx.params).id, user.id)).audit);
