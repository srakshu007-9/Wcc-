import { route } from "@/lib/api";
import { analyzeCase } from "@/lib/workflow/orchestrator";

export const maxDuration = 120;

export const POST = route(async (user, _req, ctx) => analyzeCase((await ctx.params).id, user.id));
