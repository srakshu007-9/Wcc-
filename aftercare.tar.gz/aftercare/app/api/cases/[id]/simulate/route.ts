import { route, jsonBody } from "@/lib/api";
import { SimulateInput } from "@/lib/schemas";
import { simulate } from "@/lib/workflow/orchestrator";

export const maxDuration = 120;

export const POST = route(async (user, req, ctx) => {
  const i = SimulateInput.parse(await jsonBody(req));
  return simulate((await ctx.params).id, user.id, i.kind);
});
