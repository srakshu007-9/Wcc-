import { route } from "@/lib/api";
import { verifyCase } from "@/lib/workflow/orchestrator";

export const maxDuration = 60;

export const POST = route(async (user, _req, ctx) => verifyCase((await ctx.params).id, user.id));
