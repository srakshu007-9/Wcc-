import { route } from "@/lib/api";
import { recentActivity } from "@/lib/workflow/read";

export const GET = route(async (user) => recentActivity(user.id, 60));
