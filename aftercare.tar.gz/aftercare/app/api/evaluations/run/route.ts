import { route } from "@/lib/api";
import { admin, AppError } from "@/lib/supabase/admin";
import { runEvaluation } from "@/lib/evaluation/run";

export const maxDuration = 300;

export const POST = route(async (user) => {
  const r = await runEvaluation();
  const { data, error } = await admin()
    .from("evaluation_runs")
    .insert({ user_id: user.id, total_cases: r.totalCases, results: r.metrics, metrics: Object.fromEntries(r.metrics.map((m) => [m.key, m.score])), model: r.model })
    .select()
    .single();
  if (error) throw new AppError("DB_FAILURE", `Could not save evaluation results: ${error.message}`, 500);
  return data;
});
