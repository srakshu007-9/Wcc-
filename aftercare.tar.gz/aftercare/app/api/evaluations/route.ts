import { route } from "@/lib/api";
import { admin } from "@/lib/supabase/admin";

export const GET = route(async (user) => {
  const { data } = await admin().from("evaluation_runs").select("*").eq("user_id", user.id).order("created_at", { ascending: false }).limit(10);
  return data ?? [];
});
