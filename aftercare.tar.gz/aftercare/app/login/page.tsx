"use client";
import { Suspense, useState } from "react";
import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import { browserClient } from "@/lib/supabase/browser";
import { ErrorBox, Spinner } from "@/components/ui";

function LoginForm() {
  const router = useRouter();
  const params = useSearchParams();
  const next = params.get("next") || "/app";
  const [mode, setMode] = useState<"in" | "up">("in");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [info, setInfo] = useState<string | null>(null);

  const configured = !!process.env.NEXT_PUBLIC_SUPABASE_URL && !!process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError(null);
    setInfo(null);
    try {
      const sb = browserClient();
      if (mode === "up") {
        const { data, error } = await sb.auth.signUp({ email, password });
        if (error) throw error;
        if (!data.session) {
          setInfo("Account created. Check your email to confirm it, then sign in.");
          setMode("in");
          return;
        }
      } else {
        const { error } = await sb.auth.signInWithPassword({ email, password });
        if (error) throw error;
      }
      router.push(next);
      router.refresh();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not sign in.");
    } finally {
      setBusy(false);
    }
  }

  async function demo() {
    setBusy(true);
    setError(null);
    try {
      const sb = browserClient();
      const id = crypto.randomUUID().slice(0, 8);
      const demoEmail = `demo-${id}@aftercare-demo.app`;
      const demoPass = crypto.randomUUID();
      const { data, error } = await sb.auth.signUp({ email: demoEmail, password: demoPass });
      if (error) throw error;
      if (!data.session) {
        throw new Error("Instant demo needs email confirmation turned off in Supabase (Authentication → Providers → Email). See DEPLOYMENT.md.");
      }
      router.push(next);
      router.refresh();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not start the demo.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <main id="main" className="mx-auto grid min-h-screen max-w-5xl items-center gap-10 px-5 py-10 md:grid-cols-2">
      <div>
        <Link href="/" className="font-display text-xl font-extrabold">AFTERCARE</Link>
        <h1 className="mt-6 font-display text-5xl font-extrabold leading-[0.95] sm:text-6xl">From submitted to actually resolved.</h1>
        <p className="mt-4 max-w-md text-ink-soft">Sign in to manage your cases, or try an instant demo account with the full lifecycle and controlled simulations.</p>
      </div>
      <div className="card p-6 sm:p-8">
        {!configured && (
          <div className="mb-4"><ErrorBox message="Supabase is not configured for this deployment. Set NEXT_PUBLIC_SUPABASE_URL and NEXT_PUBLIC_SUPABASE_ANON_KEY (see .env.example)." /></div>
        )}
        <h2 className="font-display text-2xl font-extrabold">{mode === "in" ? "Sign in" : "Create account"}</h2>
        <form onSubmit={submit} className="mt-5 space-y-4">
          <div>
            <label htmlFor="email" className="mb-1 block text-sm font-semibold">Email</label>
            <input id="email" type="email" required autoComplete="email" value={email} onChange={(e) => setEmail(e.target.value)} className="field" />
          </div>
          <div>
            <label htmlFor="password" className="mb-1 block text-sm font-semibold">Password</label>
            <input id="password" type="password" required minLength={8} autoComplete={mode === "in" ? "current-password" : "new-password"} value={password} onChange={(e) => setPassword(e.target.value)} className="field" />
            {mode === "up" && <p className="mt-1 text-xs text-ink-muted">At least 8 characters.</p>}
          </div>
          {error && <ErrorBox message={error} />}
          {info && <p role="status" className="rounded-xl bg-ok-soft p-3 text-sm text-ok">{info}</p>}
          <button className="btn-primary w-full" disabled={busy || !configured}>
            {busy ? <Spinner label="One moment" /> : mode === "in" ? "Sign in" : "Create account"}
          </button>
        </form>
        <button className="btn-ghost mt-3 w-full" onClick={demo} disabled={busy || !configured}>Try the demo</button>
        <p className="mt-4 text-center text-sm text-ink-muted">
          {mode === "in" ? "New here?" : "Already have an account?"}{" "}
          <button className="font-semibold text-terra underline" onClick={() => { setMode(mode === "in" ? "up" : "in"); setError(null); }}>
            {mode === "in" ? "Create an account" : "Sign in"}
          </button>
        </p>
      </div>
    </main>
  );
}

export default function LoginPage() {
  return (
    <Suspense fallback={null}>
      <LoginForm />
    </Suspense>
  );
}
