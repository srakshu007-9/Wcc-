import Link from "next/link";
import { ShieldCheck, FileSearch, ScrollText, HelpCircle } from "lucide-react";
import { LiveCase } from "@/components/LiveCase";

const HOW = [
  ["Understand", "Reads your goal and works out what “finished” actually means for you."],
  ["Evidence", "Reads your documents and cites exactly where each fact comes from. Missing proof is called out, never invented."],
  ["Plan", "Builds the shortest safe path and marks every step that needs your say-so."],
  ["Act", "Drafts the message or request. Nothing consequential goes out without your approval."],
  ["Monitor", "Watches the clock and the replies, and compares what should have happened with what did."],
  ["Recover", "When a response is overdue, it names the blocker, replans, and drafts the follow-up."],
  ["Verify", "Closes the case only when there is evidence that the original goal was achieved."],
];

const REAL = ["Scholarships", "Insurance claims", "Refunds", "Applications", "Reimbursements", "Follow-ups"];

const TRUST = [
  [ShieldCheck, "Human approval", "Every outbound message, submission or escalation waits for you to approve, edit or reject it."],
  [FileSearch, "Evidence grounding", "Each conclusion points to a quote in your documents. Quotes that can't be found are discarded."],
  [ScrollText, "Audit trail", "Every state change, agent run and decision is stored and visible."],
  [HelpCircle, "Uncertainty handling", "When proof is missing the agent says INSUFFICIENT_EVIDENCE instead of guessing."],
] as const;

export default function Landing() {
  return (
    <main id="main" className="overflow-x-hidden">
      <header className="mx-auto flex max-w-7xl items-center justify-between px-5 py-5 sm:px-8">
        <Link href="/" className="font-display text-xl font-extrabold tracking-tight">
          AFTERCARE
        </Link>
        <nav aria-label="Primary" className="flex items-center gap-2 text-sm font-semibold sm:gap-6">
          <a href="#how" className="hidden hover:text-terra sm:inline">How it works</a>
          <a href="#trust" className="hidden hover:text-terra sm:inline">Trust</a>
          <Link href="/login" className="btn-dark">Sign in</Link>
        </nav>
      </header>

      <section className="relative mx-auto max-w-7xl px-5 pb-20 pt-6 sm:px-8">
        <div className="rounded-[2rem] bg-terra px-6 pb-16 pt-12 text-cream-light sm:px-12 sm:pt-16">
          <h1 className="font-display text-[clamp(3.2rem,15vw,12.5rem)] font-extrabold leading-[0.85] tracking-tighter">AFTERCARE</h1>
          <div className="mt-10 grid items-end gap-10 lg:grid-cols-[1.1fr_1fr]">
            <div>
              <p className="font-display text-3xl font-extrabold leading-tight sm:text-5xl">The AI that doesn't stop at “submitted.”</p>
              <p className="mt-5 max-w-xl text-lg leading-relaxed text-cream-light/90">
                Important processes get stuck between starting and finishing. AFTERCARE manages the entire lifecycle: understanding the goal, gathering evidence, taking approved actions, recovering from blockers, and verifying the final outcome.
              </p>
              <div className="mt-8 flex flex-wrap gap-3">
                <Link href="/login?next=/app/new" className="btn bg-cream-light !px-7 !py-3.5 text-base text-ink hover:bg-white">Start a case</Link>
                <a href="#how" className="btn border border-cream-light/60 !px-7 !py-3.5 text-base text-cream-light hover:bg-white/10">See how it works</a>
              </div>
            </div>
            <div className="flex justify-center text-ink lg:justify-end"><LiveCase /></div>
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-5xl px-5 py-16 sm:px-8" aria-labelledby="gap">
        <h2 id="gap" className="font-display text-4xl font-extrabold sm:text-6xl">The gap</h2>
        <p className="mt-6 max-w-2xl text-2xl leading-snug text-ink-soft">
          Most software knows when something was submitted. Very little software knows whether it was actually resolved.
        </p>
        <div className="mt-10 flex flex-wrap items-center gap-4 font-display text-5xl font-extrabold sm:text-8xl">
          <span>Submitted</span>
          <span className="text-terra" aria-label="is not">≠</span>
          <span className="text-ok">Resolved</span>
        </div>
      </section>

      <section id="how" className="mx-auto max-w-5xl px-5 py-16 sm:px-8" aria-labelledby="how-h">
        <h2 id="how-h" className="font-display text-4xl font-extrabold sm:text-6xl">How AFTERCARE works</h2>
        <ol className="mt-10 divide-y divide-ink/10 border-y border-ink/10">
          {HOW.map(([t, d], i) => (
            <li key={t} className="grid gap-2 py-5 sm:grid-cols-[3rem_12rem_1fr] sm:items-baseline">
              <span className="font-display text-xl font-extrabold text-terra">{i + 1}</span>
              <span className="font-display text-2xl font-extrabold">{t}</span>
              <span className="text-ink-soft">{d}</span>
            </li>
          ))}
        </ol>
      </section>

      <section className="mx-auto max-w-5xl px-5 py-16 sm:px-8" aria-labelledby="real">
        <h2 id="real" className="font-display text-4xl font-extrabold sm:text-6xl">Built for real life</h2>
        <ul className="mt-8 flex flex-wrap gap-3">
          {REAL.map((r) => (
            <li key={r} className="rounded-full border border-ink/20 bg-cream-light px-5 py-2.5 text-lg font-semibold">{r}</li>
          ))}
        </ul>
      </section>

      <section id="trust" className="mx-auto max-w-5xl px-5 py-16 sm:px-8" aria-labelledby="trust-h">
        <h2 id="trust-h" className="font-display text-4xl font-extrabold sm:text-6xl">Trust by design</h2>
        <div className="mt-8 grid gap-4 sm:grid-cols-2">
          {TRUST.map(([Icon, t, d]) => (
            <div key={t} className="card p-6">
              <Icon className="h-6 w-6 text-terra" aria-hidden />
              <h3 className="mt-3 font-display text-xl font-extrabold">{t}</h3>
              <p className="mt-1 text-ink-soft">{d}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-5 pb-20 sm:px-8">
        <div className="rounded-[2rem] bg-ink px-8 py-14 text-cream-light sm:px-14">
          <p className="max-w-3xl font-display text-3xl font-extrabold leading-tight sm:text-5xl">Chatbots answer. AFTERCARE manages state.</p>
          <Link href="/login?next=/app/new" className="btn-primary mt-8 !px-7 !py-3.5 text-base">Start a case</Link>
        </div>
      </section>

      <footer className="mx-auto max-w-7xl px-5 pb-10 text-sm text-ink-muted sm:px-8">
        AFTERCARE · External actions in Demo Mode are simulated and labeled as such.
      </footer>
    </main>
  );
}
