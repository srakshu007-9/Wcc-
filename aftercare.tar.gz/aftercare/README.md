# AFTERCARE

**From submitted to actually resolved.**

AFTERCARE is an AI completion agent. It takes an unresolved real-world process (a scholarship that was approved but never paid, a stuck refund, a delayed claim), understands the goal, reads your documents, plans, drafts actions for your approval, monitors for a response, detects blockers, recovers, and **only closes the case when there is evidence the original goal was achieved**.

Chatbots answer. AFTERCARE manages state.

## What is in this repo

- Next.js 15 (App Router), React 19, TypeScript, Tailwind, Framer Motion
- Supabase: Postgres, pgvector, Auth, private Storage, row-level security
- OpenAI for the six agents (swappable in `lib/llm.ts`) with zod-validated structured output
- A real state machine (`lib/state-machine.ts`) where every transition is stored and shown in the UI
- Document pipeline: upload, text extraction (PDF with page numbers, DOCX, TXT), chunking, embeddings, per-case semantic retrieval
- Grounding guard: an evidence item or a resolution is discarded unless its quote literally appears in the cited chunk
- Human approval gate on every outbound action (approve, edit, or reject and replan)
- Demo Mode: simulates only the outside world (delays, replies, a confirmation document). Agents, database and state machine are real.
- Evaluation harness with a hand-labelled benchmark. The UI shows "Not evaluated yet" until you run it.

## Quick start

```bash
npm install
cp .env.example .env.local     # fill in values
# 1. Run supabase/schema.sql in the Supabase SQL editor  (see DATABASE_SETUP.md)
npm run dev
```

Open http://localhost:3000, click **Try the demo** on the sign-in page, then **Create case → Use the scholarship example → Add sample scholarship documents → Let AFTERCARE analyze**.

## The 3–5 minute demo

1. Create case with the scholarship example and sample documents.
2. Read the evidence: approval and application reference are found with quotes; payment confirmation is listed as missing.
3. Approve the drafted status request. It is recorded as a **simulated** external action.
4. Click **Advance case** (or **Simulate delay**). The Monitoring Agent detects the overdue response, raises a blocker, the planner replans, the Action Agent drafts a follow-up.
5. Approve the follow-up. Click **Simulate response** to see that a bare "your request has been processed" is **not** accepted: run verification and the case stays active.
6. Click **Provide resolution evidence (demo)** then **Run verification** (or keep using **Advance case**). The Verification Agent cites the confirmation text and the case closes with **Goal verified**.

## Honest status

Verified in this repository: `npm install`, `npm run lint`, `npm run build` all pass; the state machine, monitoring rules and chunker pass scripted checks.

Not verified here: calls against a live Supabase project and the OpenAI API. They need your credentials. Follow `DEPLOYMENT.md`, run one case end to end, then run **Evaluations** to get real measured numbers for your chosen model.

Known limits:
- OCR is not bundled. PNG/JPG uploads are stored but flagged as unreadable; upload a PDF/DOCX/TXT for them to count as evidence.
- No real email or third-party API is connected. Approved actions are recorded as simulated communications and labeled as such.
- Separate `/actions`, `/follow-up` and `/escalate` endpoints are not exposed. Follow-up and escalation are produced by the monitoring workflow and approved through `/approve`.

## Docs

- `DATABASE_SETUP.md` Supabase schema and Auth settings
- `DEPLOYMENT.md` Vercel + Supabase go-live steps
- `ARCHITECTURE.md` agents, state machine, data flow, safety
- `EVALUATION.md` metrics and how they are computed
