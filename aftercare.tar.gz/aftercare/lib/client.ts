"use client";
import { useCallback, useEffect, useRef, useState } from "react";

export class ApiError extends Error {
  constructor(public code: string, message: string) {
    super(message);
  }
}

export async function api<T = unknown>(url: string, init?: RequestInit & { json?: unknown }): Promise<T> {
  let res: Response;
  try {
    res = await fetch(url, {
      ...init,
      headers: init?.json ? { "content-type": "application/json", ...init?.headers } : init?.headers,
      body: init?.json ? JSON.stringify(init.json) : init?.body,
    });
  } catch {
    throw new ApiError("NETWORK", "Could not reach the server. Check your connection and try again.");
  }
  let body: { ok?: boolean; data?: T; error?: { code: string; message: string } } | null = null;
  try {
    body = await res.json();
  } catch {
    /* non-JSON error page */
  }
  if (res.status === 401) {
    window.location.href = "/login";
    throw new ApiError("UNAUTHENTICATED", "Please sign in.");
  }
  if (!res.ok || !body?.ok) {
    throw new ApiError(body?.error?.code ?? "HTTP_" + res.status, body?.error?.message ?? `Request failed (${res.status}). Please retry.`);
  }
  return body.data as T;
}

/** Fetch + optional polling. */
export function useApi<T>(url: string | null, opts?: { pollMs?: number | ((d: T | null) => number | null) }) {
  const [data, setData] = useState<T | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const dataRef = useRef<T | null>(null);

  const load = useCallback(async () => {
    if (!url) return;
    try {
      const d = await api<T>(url);
      dataRef.current = d;
      setData(d);
      setError(null);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Failed to load");
    } finally {
      setLoading(false);
    }
  }, [url]);

  useEffect(() => {
    load();
  }, [load]);

  const pollOpt = opts?.pollMs;
  useEffect(() => {
    if (!url || pollOpt === undefined) return;
    let stop = false;
    let t: ReturnType<typeof setTimeout>;
    const tick = () => {
      const ms = typeof pollOpt === "function" ? pollOpt(dataRef.current) : pollOpt;
      if (!ms || stop) {
        t = setTimeout(tick, 4000);
        return;
      }
      t = setTimeout(async () => {
        await load();
        if (!stop) tick();
      }, ms);
    };
    tick();
    return () => {
      stop = true;
      clearTimeout(t);
    };
  }, [url, pollOpt, load]);

  return { data, error, loading, reload: load };
}
