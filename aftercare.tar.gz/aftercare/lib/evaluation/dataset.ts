// Benchmark dataset. Labels are written by hand; nothing here is a result.
import type { CaseState } from "@/lib/state-machine";

export const INTAKE_CASES = [
  { id: "intake-scholarship", text: "My scholarship was approved two months ago but I still haven't received the amount.", category: /scholar|educat/i, outcome: /scholar|payment|amount|money|fund|disburs/i },
  { id: "intake-insurance", text: "I filed a health insurance claim six weeks ago after my surgery and nobody has told me if it will be paid.", category: /insur|claim|health/i, outcome: /claim|settle|pay|reimburs/i },
  { id: "intake-refund", text: "I returned a laptop to an online store three weeks ago and the refund never showed up in my account.", category: /refund|retail|consumer|purchase|order|e-?commerce/i, outcome: /refund|money|payment/i },
  { id: "intake-reimbursement", text: "My company still hasn't reimbursed my travel expenses from the March conference.", category: /reimburs|expense|employ|work|travel/i, outcome: /reimburs|expense|pay/i },
  { id: "intake-vague", text: "Things are not going well with my paperwork.", vague: true },
] as const;

export const SCHOLARSHIP_DOCS = {
  approval: `SCHOLARSHIP APPROVAL LETTER\n\nWe are pleased to inform you that your scholarship application has been approved.\nApplication Reference: SCH-2291\nThe scholarship amount will be disbursed to the registered bank account after verification.\n\nOffice of Student Financial Aid`,
  receipt: `FEE RECEIPT\n\nTuition fee received for the current semester.\nReceipt status: Paid by student.\nThis receipt does not relate to any scholarship payment.`,
  irrelevant: `Meeting notes\n\nWe discussed the weekend picnic and who will bring snacks.`,
};

export const EVIDENCE_CASES = [
  {
    id: "evidence-approval-only",
    goal: "My scholarship was approved but I haven't received the payment.",
    required: ["Scholarship approval letter", "Application reference", "Payment confirmation"],
    docs: [SCHOLARSHIP_DOCS.approval],
    expectInsufficientOverall: false,
    mustFind: /approv/i,
    mustMiss: /payment|confirm/i,
    mustNotFind: /payment (was )?(received|credited|made|confirmed)|credited|disbursed to/i,
  },
  {
    id: "evidence-receipt-only",
    goal: "My scholarship was approved but I haven't received the payment.",
    required: ["Scholarship approval letter", "Application reference", "Payment confirmation"],
    docs: [SCHOLARSHIP_DOCS.receipt],
    expectInsufficientOverall: true,
    mustFind: null,
    mustMiss: /approv|payment|confirm/i,
    mustNotFind: /approv(ed|al)/i,
  },
  {
    id: "evidence-irrelevant",
    goal: "My scholarship was approved but I haven't received the payment.",
    required: ["Scholarship approval letter", "Application reference", "Payment confirmation"],
    docs: [SCHOLARSHIP_DOCS.irrelevant],
    expectInsufficientOverall: true,
    mustFind: null,
    mustMiss: /approv|payment|confirm/i,
    mustNotFind: /approv(ed|al)|payment/i,
  },
] as const;

export const MONITOR_SCENARIOS = [
  { id: "inside-window", expect: "none", hoursFromDue: -30, comms: ["outbound"] },
  { id: "overdue-no-response", expect: "overdue", hoursFromDue: 40, comms: ["outbound"] },
  { id: "response-received", expect: "response_received", hoursFromDue: -10, comms: ["outbound", "inbound"] },
  { id: "stale-inbound-then-new-outbound", expect: "overdue", hoursFromDue: 5, comms: ["inbound", "outbound"] },
  { id: "no-tracked-request", expect: "none", hoursFromDue: null, comms: [] },
] as const;

export const TRANSITION_CASES: { from: CaseState; to: CaseState; legal: boolean }[] = [
  { from: "NEW", to: "UNDERSTANDING", legal: true },
  { from: "NEW", to: "COMPLETED", legal: false },
  { from: "PLANNING", to: "WAITING_FOR_APPROVAL", legal: true },
  { from: "WAITING_FOR_APPROVAL", to: "ACTION_EXECUTED", legal: false },
  { from: "WAITING_FOR_APPROVAL", to: "ACTION_READY", legal: true },
  { from: "ACTION_EXECUTED", to: "MONITORING", legal: true },
  { from: "MONITORING", to: "BLOCKED", legal: true },
  { from: "MONITORING", to: "COMPLETED", legal: false },
  { from: "BLOCKED", to: "FOLLOW_UP_REQUIRED", legal: true },
  { from: "FOLLOW_UP_REQUIRED", to: "ACTION_EXECUTED", legal: false },
  { from: "FOLLOW_UP_REQUIRED", to: "WAITING_FOR_APPROVAL", legal: true },
  { from: "RESOLUTION_VERIFICATION", to: "COMPLETED", legal: true },
  { from: "COMPLETED", to: "MONITORING", legal: false },
  { from: "RESOLUTION_PENDING", to: "COMPLETED", legal: false },
];

export const RECOVERY_CASES = [
  { id: "recovery-first-overdue", escalationLevel: 0, followUpsSent: 0, expect: "FOLLOW_UP" },
  { id: "recovery-followup-overdue", escalationLevel: 1, followUpsSent: 1, expect: "ESCALATE" },
] as const;

export const VERIFICATION_CASES = [
  {
    id: "verify-ack-only",
    inbound: ["Your request has been processed. Thank you for contacting us."],
    resolutionDoc: null as string | null,
    expect: ["NOT_RESOLVED", "INSUFFICIENT_EVIDENCE"],
  },
  {
    id: "verify-confirmation",
    inbound: ["Please find the payment confirmation attached."],
    resolutionDoc: "PAYMENT CONFIRMATION\nThe sanctioned scholarship amount has been credited to the student's registered bank account.\nDisbursement status: PAID.",
    expect: ["RESOLUTION_VERIFIED"],
  },
  { id: "verify-nothing", inbound: [] as string[], resolutionDoc: null as string | null, expect: ["INSUFFICIENT_EVIDENCE", "NOT_RESOLVED"] },
  {
    id: "verify-delayed",
    inbound: ["Your payment is on hold pending verification of bank account details."],
    resolutionDoc: "STATUS NOTE\nThe disbursement is on hold. No amount has been credited yet.",
    expect: ["NOT_RESOLVED", "INSUFFICIENT_EVIDENCE"],
  },
] as const;
