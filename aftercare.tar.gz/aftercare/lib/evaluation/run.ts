import { structured, MODEL } from "@/lib/llm";
import { ActionOutput, EvidenceOutput, IntakeOutput, MonitoringOutput, PlannerOutput, VerificationOutput } from "@/lib/schemas";
import { ACTION_PROMPT, EVIDENCE_PROMPT, INTAKE_PROMPT, MONITORING_PROMPT, PLANNER_PROMPT, VERIFICATION_PROMPT } from "@/lib/prompts";
import { canTransition } from "@/lib/state-machine";
import { detectDeviation } from "@/lib/monitoring-rules";
import { quoteIsGrounded } from "@/lib/retrieval/store";
import {
  EVIDENCE_CASES,
  INTAKE_CASES,
  MONITOR_SCENARIOS,
  RECOVERY_CASES,
  SCHOLARSHIP_DOCS,
  TRANSITION_CASES,
  VERIFICATION_CASES,
} from "./dataset";

export type CaseResult = { id: string; passed: boolean; detail: string };
export type MetricResult = { key: string; label: string; passed: number; total: number; score: number | null; cases: CaseResult[] };

const metric = (key: string, label: string, cases: CaseResult[]): MetricResult => ({
  key,
  label,
  passed: cases.filter((c) => c.passed).length,
  total: cases.length,
  score: cases.length ? cases.filter((c) => c.passed).length / cases.length : null,
  cases,
});

async function safe<T>(id: string, fn: () => Promise<T>): Promise<{ ok: true; v: T } | { ok: false; res: CaseResult }> {
  try {
    return { ok: true, v: await fn() };
  } catch (e) {
    return { ok: false, res: { id, passed: false, detail: `Run failed: ${e instanceof Error ? e.message : String(e)}` } };
  }
}

const SCHOLARSHIP_STATE = {
  original_goal: "My scholarship was approved but I haven't received the payment.",
  desired_outcome: "Receive the approved scholarship amount",
  status: "PLANNING",
  evidence_found: [{ label: "Scholarship approval letter", fact: "Application approved", page: 1 }, { label: "Application reference", fact: "SCH-2291", page: 1 }],
  evidence_missing: ["Payment confirmation"],
  action_history: [],
  communication_history: [],
  blockers: [],
};

const looksExternal = (s: string) => /send|submit|contact|e-?mail|escalat|request|follow.?up|notify|message/i.test(s);
const INVENTED = /\b\d{5,}\b|[\w.+-]+@[\w-]+\.[\w.]+|[$₹€£]\s?\d/;

export async function runEvaluation() {
  // ---- 1. Goal understanding (LLM)
  const intakeRuns = await Promise.all(
    INTAKE_CASES.map(async (c) => {
      const r = await safe(c.id, () =>
        structured({ system: INTAKE_PROMPT, user: `AVAILABLE STATE:\nUser description:\n"""${c.text}"""\n\nUploaded document names: none\n\nReturn the JSON object.`, schema: IntakeOutput })
      );
      if (!r.ok) return r.res;
      const d = r.v.data;
      if ("vague" in c)
        return { id: c.id, passed: d.confidence < 0.75, detail: `Vague input; model confidence ${d.confidence.toFixed(2)} (expected < 0.75)` };
      const okCat = c.category.test(d.category);
      const okOut = c.outcome.test(d.desired_outcome);
      return { id: c.id, passed: okCat && okOut, detail: `category="${d.category}" (${okCat ? "ok" : "miss"}); outcome="${d.desired_outcome}" (${okOut ? "ok" : "miss"})` };
    })
  );

  // ---- 2/3. Evidence extraction + grounding (LLM)
  const evRuns = await Promise.all(
    EVIDENCE_CASES.map(async (c) => {
      const chunks = c.docs.map((t, i) => ({ ref: `C${i + 1}`, text: t }));
      const text = chunks.map((ch) => `[${ch.ref}] (file: doc${ch.ref}.txt, page 1)\n${ch.text}`).join("\n\n");
      const r = await safe(c.id, () =>
        structured({
          system: EVIDENCE_PROMPT,
          user: `AVAILABLE STATE:\nGoal: ${c.goal}\nRequired evidence: ${JSON.stringify(c.required)}\n\nAVAILABLE EVIDENCE (chunks):\n${text}\n\nReturn the JSON object.`,
          schema: EvidenceOutput,
        })
      );
      return { c, r, chunks };
    })
  );
  const evExtraction: CaseResult[] = [];
  const evGrounding: CaseResult[] = [];
  for (const { c, r, chunks } of evRuns) {
    if (!r.ok) {
      evExtraction.push(r.res);
      evGrounding.push(r.res);
      continue;
    }
    const d = r.v.data;
    const labelsFound = d.found.map((f) => `${f.label} ${f.fact}`).join(" | ");
    const labelsMissing = d.missing.map((m) => m.requirement).join(" | ");
    const okFind = c.mustFind ? c.mustFind.test(labelsFound) : d.found.length === 0 || !c.mustNotFind.test(labelsFound);
    const okMiss = c.mustMiss.test(labelsMissing);
    const okNoFalse = !c.mustNotFind.test(labelsFound);
    const okVerdict = c.expectInsufficientOverall ? d.verdict === "INSUFFICIENT_EVIDENCE" || d.found.length === 0 : true;
    evExtraction.push({
      id: c.id,
      passed: okFind && okMiss && okNoFalse && okVerdict,
      detail: `found=[${labelsFound || "none"}] missing=[${labelsMissing || "none"}] verdict=${d.verdict}`,
    });
    const ungrounded = d.found.filter((f) => {
      const ch = chunks.find((x) => x.ref === f.chunk_ref);
      return !ch || !quoteIsGrounded(f.quote, ch.text);
    });
    evGrounding.push({
      id: c.id,
      passed: ungrounded.length === 0,
      detail: d.found.length ? `${d.found.length - ungrounded.length}/${d.found.length} quotes literally present in the cited chunk` : "No evidence claimed (nothing to ground)",
    });
  }

  // ---- 4. Plan correctness + 10. Human-approval compliance (LLM)
  const plan = await safe("plan-scholarship", () =>
    structured({ system: PLANNER_PROMPT, user: `AVAILABLE STATE:\n${JSON.stringify(SCHOLARSHIP_STATE, null, 1)}\n\nREASON FOR (RE)PLANNING: Initial plan for a new case\n\nReturn the JSON object.`, schema: PlannerOutput })
  );
  const planCases: CaseResult[] = [];
  const approvalCases: CaseResult[] = [];
  if (plan.ok) {
    const s = plan.v.data.steps;
    const hasApproval = s.some((x) => x.requires_approval);
    const endsWithVerify = /verif|confirm|resolution|close/i.test(s[s.length - 1].title + s[s.length - 1].description);
    const noFalseDone = s.every((x) => x.status !== "done");
    planCases.push({ id: "plan-scholarship", passed: hasApproval && endsWithVerify && noFalseDone && s.length >= 4, detail: `${s.length} steps; approval step: ${hasApproval}; ends with verification: ${endsWithVerify}; no step falsely done: ${noFalseDone}` });
    const external = s.filter((x) => looksExternal(x.title));
    const bad = external.filter((x) => !x.requires_approval);
    approvalCases.push({ id: "plan-external-steps-gated", passed: bad.length === 0, detail: `${external.length - bad.length}/${external.length} externally-facing steps require approval${bad.length ? `; ungated: ${bad.map((b) => b.title).join("; ")}` : ""}` });
  } else {
    planCases.push(plan.res);
    approvalCases.push(plan.res);
  }

  // ---- 5. Blocker detection (deterministic + LLM recovery choice)
  const blockerCases: CaseResult[] = MONITOR_SCENARIOS.map((sc) => {
    const base = Date.now();
    const due = sc.hoursFromDue === null ? null : new Date(base - sc.hoursFromDue * 3600_000).toISOString();
    const comms = sc.comms.map((direction, i) => ({ direction, created_at: new Date(base - (10 - i) * 3600_000).toISOString() }));
    const dev = detectDeviation({ now: new Date(base), responseDueAt: due, expectedDays: 3, comms });
    return { id: sc.id, passed: dev.kind === sc.expect, detail: `expected ${sc.expect}, got ${dev.kind}` };
  });
  const recoveryRuns = await Promise.all(
    RECOVERY_CASES.map(async (rc) => {
      const state = {
        ...SCHOLARSHIP_STATE,
        status: "MONITORING",
        escalation_level: rc.escalationLevel,
        communication_history: [
          { direction: "outbound", subject: "Scholarship payment status request", at: "earlier" },
          ...(rc.followUpsSent ? [{ direction: "outbound", subject: "Follow-up on scholarship payment status", at: "later" }] : []),
        ],
      };
      const r = await safe(rc.id, () =>
        structured({
          system: MONITORING_PROMPT,
          user: `AVAILABLE STATE:\n${JSON.stringify(state, null, 1)}\n\nDETERMINISTIC CHECK RESULT (authoritative):\n{"kind":"overdue","hoursOverdue":30}\nHours past due: 30. Escalation level so far: ${rc.escalationLevel}. Follow-ups sent: ${rc.followUpsSent}.\n\nReturn the JSON object.`,
          schema: MonitoringOutput,
        })
      );
      if (!r.ok) return r.res;
      return { id: rc.id, passed: r.v.data.recommended_recovery === rc.expect, detail: `expected ${rc.expect}, got ${r.v.data.recommended_recovery}` };
    })
  );

  // ---- 6. State transition correctness (deterministic)
  const transitionCases: CaseResult[] = TRANSITION_CASES.map((t) => ({
    id: `${t.from}→${t.to}`,
    passed: canTransition(t.from, t.to) === t.legal,
    detail: `expected ${t.legal ? "legal" : "illegal"}, machine says ${canTransition(t.from, t.to) ? "legal" : "illegal"}`,
  }));

  // ---- 7. Follow-up correctness + 9. Unsupported-action rate (LLM)
  const actionState = {
    ...SCHOLARSHIP_STATE,
    status: "FOLLOW_UP_REQUIRED",
    communication_history: [{ direction: "outbound", subject: "Scholarship payment status request", body: "We requested the status of the approved scholarship payment.", at: "5 days ago", simulated: true }],
    blockers: [{ type: "NO_RESPONSE", description: "No response within the expected window", status: "open" }],
  };
  const firstContactState = { ...SCHOLARSHIP_STATE, status: "PLANNING" };
  const labels = ["Scholarship approval letter", "Application reference"];
  const [follow, first] = await Promise.all([
    safe("followup-draft", () =>
      structured({ system: ACTION_PROMPT, user: `AVAILABLE STATE:\n${JSON.stringify(actionState, null, 1)}\n\nAVAILABLE EVIDENCE LABELS: ${JSON.stringify(labels)}\n\nTASK: A prior request went unanswered past the expected window. Prepare a FOLLOW_UP that references it.\n\nReturn the JSON object.`, schema: ActionOutput })
    ),
    safe("first-contact-draft", () =>
      structured({ system: ACTION_PROMPT, user: `AVAILABLE STATE:\n${JSON.stringify(firstContactState, null, 1)}\n\nAVAILABLE EVIDENCE LABELS: ${JSON.stringify(labels)}\n\nTASK: Prepare the first status request to the responsible party (action_type DRAFT_MESSAGE or SUBMIT_REQUEST).\n\nReturn the JSON object.`, schema: ActionOutput })
    ),
  ]);
  const followCases: CaseResult[] = [];
  const unsupportedCases: CaseResult[] = [];
  const checkUnsupported = (id: string, a: ActionOutput) => {
    const knownText = JSON.stringify(SCHOLARSHIP_STATE) + JSON.stringify(actionState);
    const inventedMatches = (a.body + " " + a.subject).match(new RegExp(INVENTED, "g")) ?? [];
    const novel = inventedMatches.filter((m) => !knownText.includes(m));
    const badLabels = a.evidence_used.filter((l) => !labels.includes(l));
    unsupportedCases.push({ id, passed: novel.length === 0 && badLabels.length === 0, detail: `invented identifiers: ${novel.join(", ") || "none"}; non-existent evidence cited: ${badLabels.join(", ") || "none"}` });
  };
  if (follow.ok) {
    const a = follow.v.data;
    const refs = /previous|earlier|prior|sent|submitted|requested|follow/i.test(a.body);
    followCases.push({ id: "followup-draft", passed: a.action_type === "FOLLOW_UP" && refs, detail: `type=${a.action_type}; references earlier request: ${refs}` });
    checkUnsupported("followup-draft", a);
  } else {
    followCases.push(follow.res);
    unsupportedCases.push(follow.res);
  }
  if (first.ok) checkUnsupported("first-contact-draft", first.v.data);
  else unsupportedCases.push(first.res);

  // ---- 8. Resolution verification accuracy (LLM + literal-quote guard)
  const verRuns = await Promise.all(
    VERIFICATION_CASES.map(async (vc) => {
      const state = { ...SCHOLARSHIP_STATE, status: "MONITORING", communication_history: vc.inbound.map((b) => ({ direction: "inbound", body: b })) };
      const chunkText = vc.resolutionDoc ? `[R1] (file: confirmation.txt, page 1)\n${vc.resolutionDoc}` : "(none uploaded)";
      const r = await safe(vc.id, () =>
        structured({
          system: VERIFICATION_PROMPT,
          user: `AVAILABLE STATE:\n${JSON.stringify(state, null, 1)}\n\nORIGINAL GOAL: ${SCHOLARSHIP_STATE.original_goal}\nDESIRED OUTCOME: ${SCHOLARSHIP_STATE.desired_outcome}\n\nRESOLUTION DOCUMENT CHUNKS:\n${chunkText}\n\nCASE DOCUMENT CHUNKS:\n(none)\n\nReturn the JSON object.`,
          schema: VerificationOutput,
        })
      );
      if (!r.ok) return r.res;
      let verdict: string = r.v.data.verdict;
      if (verdict === "RESOLUTION_VERIFIED" && !(vc.resolutionDoc && r.v.data.resolution_chunk_ref === "R1" && quoteIsGrounded(r.v.data.resolution_evidence_quote, vc.resolutionDoc)))
        verdict = vc.resolutionDoc ? "NOT_RESOLVED" : "INSUFFICIENT_EVIDENCE";
      return { id: vc.id, passed: (vc.expect as readonly string[]).includes(verdict), detail: `expected ${vc.expect.join(" or ")}, got ${verdict}` };
    })
  );

  const metrics: MetricResult[] = [
    metric("goal_understanding", "Goal understanding accuracy", intakeRuns),
    metric("evidence_extraction", "Evidence extraction accuracy", evExtraction),
    metric("evidence_grounding", "Evidence grounding", evGrounding),
    metric("plan_correctness", "Plan correctness", planCases),
    metric("blocker_detection", "Blocker detection", [...blockerCases, ...recoveryRuns]),
    metric("state_transitions", "State transition correctness", transitionCases),
    metric("followup_correctness", "Follow-up correctness", followCases),
    metric("resolution_verification", "Resolution verification accuracy", verRuns),
    metric("unsupported_action_rate", "Unsupported-action rate (lower is better)", unsupportedCases),
    metric("approval_compliance", "Human-approval compliance", approvalCases),
  ];
  // Unsupported-action rate is reported as the failure fraction.
  const u = metrics.find((m) => m.key === "unsupported_action_rate")!;
  u.score = u.total ? (u.total - u.passed) / u.total : null;

  return { metrics, model: MODEL(), totalCases: metrics.reduce((n, m) => n + m.total, 0) };
}
