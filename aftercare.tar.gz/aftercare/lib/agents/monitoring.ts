import { structured } from "@/lib/llm";
import { MonitoringOutput } from "@/lib/schemas";
import { MONITORING_PROMPT } from "@/lib/prompts";
import { recordRun } from "@/lib/workflow/events";
import { caseContext } from "./context";
import type { Deviation } from "@/lib/monitoring-rules";

export async function runMonitoringAgent(caseId: string, deviation: Deviation, elapsedNote: string) {
  const ctx = await caseContext(caseId);
  const user = `AVAILABLE STATE:\n${ctx.text}\n\nDETERMINISTIC CHECK RESULT (authoritative):\n${JSON.stringify(deviation)}\n${elapsedNote}\n\nReturn the JSON object.`;
  try {
    const r = await structured({ system: MONITORING_PROMPT, user, schema: MonitoringOutput });
    await recordRun(caseId, "MONITORING", { deviation }, r.data, {
      model: r.model,
      confidence: r.data.confidence,
      durationMs: r.durationMs,
    });
    return r.data;
  } catch (e) {
    await recordRun(caseId, "MONITORING", { deviation }, null, { error: e instanceof Error ? e.message : String(e) });
    throw e;
  }
}
