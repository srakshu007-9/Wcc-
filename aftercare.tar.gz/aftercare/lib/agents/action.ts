import { admin } from "@/lib/supabase/admin";
import { structured } from "@/lib/llm";
import { ActionOutput } from "@/lib/schemas";
import { ACTION_PROMPT } from "@/lib/prompts";
import { recordRun } from "@/lib/workflow/events";
import { caseContext } from "./context";

export type ActionMode = "first_contact" | "follow_up" | "escalation";

const MODE_HINT: Record<ActionMode, string> = {
  first_contact: "Prepare the first status request to the responsible party (action_type DRAFT_MESSAGE or SUBMIT_REQUEST).",
  follow_up: "A prior request went unanswered past the expected window. Prepare a FOLLOW_UP that references it.",
  escalation: "A follow-up also went unanswered. Prepare an ESCALATE message to a higher authority.",
};

/** Prepares an action and stores it as pending_approval. It NEVER executes anything. */
export async function runAction(caseId: string, mode: ActionMode, extra?: { blockerId?: string; reason?: string }) {
  const ctx = await caseContext(caseId);
  const evidenceLabels = ctx.evidence.filter((e) => e.kind === "found").map((e) => e.label);
  const user = `AVAILABLE STATE:\n${ctx.text}\n\nAVAILABLE EVIDENCE LABELS: ${JSON.stringify(evidenceLabels)}\n\nTASK: ${MODE_HINT[mode]}${extra?.reason ? `\nCONTEXT: ${extra.reason}` : ""}\n\nReturn the JSON object.`;
  try {
    const r = await structured({ system: ACTION_PROMPT, user, schema: ActionOutput });
    // Only labels that actually exist may be cited.
    const used = r.data.evidence_used.filter((l) => evidenceLabels.includes(l));
    const db = admin();
    const { data: action, error } = await db
      .from("actions")
      .insert({
        case_id: caseId,
        type: r.data.action_type,
        title: r.data.title,
        recipient: r.data.recipient,
        purpose: r.data.purpose,
        subject: r.data.subject,
        body: r.data.body,
        evidence_used: used,
        risk: r.data.risk,
        explanation: r.data.why_asking,
        requires_approval: true,
        status: "pending_approval",
        simulated: true,
      })
      .select()
      .single();
    if (error) throw new Error(error.message);
    await recordRun(caseId, "ACTION", { mode }, { ...r.data, evidence_used: used }, {
      model: r.model,
      confidence: r.data.confidence,
      durationMs: r.durationMs,
    });
    return action;
  } catch (e) {
    await recordRun(caseId, "ACTION", { mode }, null, { error: e instanceof Error ? e.message : String(e) });
    throw e;
  }
}
