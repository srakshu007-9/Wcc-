import { admin } from "@/lib/supabase/admin";

/** Assemble the persisted case state that every agent receives (AVAILABLE STATE). */
export async function caseContext(caseId: string) {
  const db = admin();
  const [c, ev, actions, comms, blockers, steps, approvals] = await Promise.all([
    db.from("cases").select("*").eq("id", caseId).single(),
    db.from("evidence").select("*").eq("case_id", caseId).order("created_at"),
    db.from("actions").select("*").eq("case_id", caseId).order("created_at"),
    db.from("communications").select("*").eq("case_id", caseId).order("created_at"),
    db.from("blockers").select("*").eq("case_id", caseId).order("created_at"),
    db.from("case_steps").select("*").eq("case_id", caseId).order("position"),
    db.from("approvals").select("*").eq("case_id", caseId).order("created_at"),
  ]);
  const cs = c.data!;
  const text = JSON.stringify(
    {
      original_goal: cs.original_goal,
      problem_statement: cs.problem_statement,
      category: cs.category,
      desired_outcome: cs.desired_outcome,
      current_state: cs.current_state_summary,
      status: cs.status,
      escalation_level: cs.escalation_level,
      entities: cs.entities,
      missing_information: cs.missing_information,
      evidence_found: (ev.data ?? []).filter((e) => e.kind === "found").map((e) => ({ label: e.label, fact: e.fact, page: e.page })),
      evidence_missing: (ev.data ?? []).filter((e) => e.kind === "missing").map((e) => e.requirement),
      action_history: (actions.data ?? []).map((a) => ({ type: a.type, title: a.title, status: a.status, executed_at: a.executed_at })),
      approval_history: (approvals.data ?? []).map((a) => ({ decision: a.decision, at: a.created_at })),
      communication_history: (comms.data ?? []).map((m) => ({ direction: m.direction, subject: m.subject, body: m.body, at: m.created_at, simulated: m.simulated })),
      blockers: (blockers.data ?? []).map((b) => ({ type: b.type, description: b.description, status: b.status })),
      current_plan: (steps.data ?? []).map((s) => ({ n: s.position, title: s.title, status: s.status })),
    },
    null,
    1
  );
  return {
    case: cs,
    evidence: ev.data ?? [],
    actions: actions.data ?? [],
    comms: comms.data ?? [],
    blockers: blockers.data ?? [],
    steps: steps.data ?? [],
    text,
  };
}

/** Effective "now" for the case: real time plus any simulated delay (demo mode only). */
export function caseNow(offsetHours: number) {
  return new Date(Date.now() + offsetHours * 3600_000);
}
