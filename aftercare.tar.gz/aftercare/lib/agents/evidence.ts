import { admin } from "@/lib/supabase/admin";
import { structured } from "@/lib/llm";
import { EvidenceOutput, IntakeOutput } from "@/lib/schemas";
import { EVIDENCE_PROMPT } from "@/lib/prompts";
import { recordRun } from "@/lib/workflow/events";
import { retrieve, labelChunks, quoteIsGrounded } from "@/lib/retrieval/store";

export async function runEvidence(caseId: string, goal: string, intake: IntakeOutput) {
  const db = admin();
  const queries = [goal, ...intake.required_evidence].slice(0, 6);
  const chunks = await retrieve(caseId, queries, { kind: "evidence", limit: 14 });

  // No readable documents: do not call the model, return INSUFFICIENT_EVIDENCE deterministically.
  if (chunks.length === 0) {
    const out: EvidenceOutput = {
      verdict: "INSUFFICIENT_EVIDENCE",
      found: [],
      missing: intake.required_evidence.map((r) => ({
        requirement: r,
        why_needed: "No readable document in this case contains it yet.",
      })),
      current_state_assessment: "No readable evidence was provided, so the process stage cannot be confirmed from documents.",
      confidence: 0.3,
    };
    await db.from("evidence").delete().eq("case_id", caseId).eq("kind", "missing");
    if (out.missing.length)
      await db.from("evidence").insert(
        out.missing.map((m) => ({ case_id: caseId, label: m.requirement, fact: m.why_needed, requirement: m.requirement, kind: "missing" }))
      );
    await recordRun(caseId, "EVIDENCE", { chunks: 0 }, out, { confidence: out.confidence });
    return { output: out, droppedUngrounded: 0 };
  }

  const { refs, text } = labelChunks(chunks, "C");
  const user = `AVAILABLE STATE:\nGoal: ${goal}\nDesired outcome: ${intake.desired_outcome}\nRequired evidence: ${JSON.stringify(intake.required_evidence)}\n\nAVAILABLE EVIDENCE (chunks):\n${text}\n\nReturn the JSON object.`;
  try {
    const r = await structured({ system: EVIDENCE_PROMPT, user, schema: EvidenceOutput });
    // Grounding enforcement: discard any item whose quote is not literally in the cited chunk.
    const grounded = r.data.found.filter((f) => {
      const ch = refs.get(f.chunk_ref);
      return ch && quoteIsGrounded(f.quote, ch.content);
    });
    const dropped = r.data.found.length - grounded.length;
    const out: EvidenceOutput = {
      ...r.data,
      found: grounded,
      verdict: grounded.length === 0 ? "INSUFFICIENT_EVIDENCE" : r.data.verdict,
    };

    await db.from("evidence").delete().eq("case_id", caseId);
    const rows = [
      ...grounded.map((f) => {
        const ch = refs.get(f.chunk_ref)!;
        return {
          case_id: caseId,
          document_id: ch.document_id,
          label: f.label,
          fact: f.fact,
          quote: f.quote,
          page: ch.page,
          requirement: f.requirement ?? null,
          kind: "found",
        };
      }),
      ...out.missing.map((m) => ({
        case_id: caseId,
        label: m.requirement,
        fact: m.why_needed,
        requirement: m.requirement,
        kind: "missing",
      })),
    ];
    if (rows.length) await db.from("evidence").insert(rows);
    await recordRun(caseId, "EVIDENCE", { chunk_count: chunks.length, dropped_ungrounded: dropped }, out, {
      model: r.model,
      confidence: out.confidence,
      durationMs: r.durationMs,
    });
    return { output: out, droppedUngrounded: dropped };
  } catch (e) {
    await recordRun(caseId, "EVIDENCE", { chunk_count: chunks.length }, null, { error: e instanceof Error ? e.message : String(e) });
    throw e;
  }
}
