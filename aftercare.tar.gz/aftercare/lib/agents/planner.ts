import { admin } from "@/lib/supabase/admin";
import { structured } from "@/lib/llm";
import { PlannerOutput } from "@/lib/schemas";
import { PLANNER_PROMPT } from "@/lib/prompts";
import { recordRun } from "@/lib/workflow/events";
import { caseContext } from "./context";

export async function runPlanner(caseId: string, reason: string) {
  const ctx = await caseContext(caseId);
  const user = `AVAILABLE STATE:\n${ctx.text}\n\nREASON FOR (RE)PLANNING: ${reason}\n\nReturn the JSON object.`;
  try {
    const r = await structured({ system: PLANNER_PROMPT, user, schema: PlannerOutput });
    const db = admin();
    // Preserve completed history; replace the remaining plan.
    await db.from("case_steps").delete().eq("case_id", caseId);
    await db.from("case_steps").insert(
      r.data.steps.map((s, i) => ({
        case_id: caseId,
        position: i + 1,
        title: s.title,
        description: s.description,
        requires_approval: s.requires_approval,
        depends_on: s.depends_on,
        status: s.status === "pending" && i === 0 ? "active" : s.status,
        rationale: s.rationale,
      }))
    );
    await db
      .from("cases")
      .update({ next_action: r.data.next_action, confidence: r.data.confidence, updated_at: new Date().toISOString() })
      .eq("id", caseId);
    await recordRun(caseId, "PLANNER", { reason }, r.data, {
      model: r.model,
      confidence: r.data.confidence,
      durationMs: r.durationMs,
    });
    return r.data;
  } catch (e) {
    await recordRun(caseId, "PLANNER", { reason }, null, { error: e instanceof Error ? e.message : String(e) });
    throw e;
  }
}

/** Mark plan steps by title keyword as done and activate the next pending one. */
export async function advancePlan(caseId: string, matcher: (title: string) => boolean) {
  const db = admin();
  const { data: steps } = await db.from("case_steps").select("*").eq("case_id", caseId).order("position");
  if (!steps?.length) return;
  for (const s of steps) {
    if (s.status !== "done" && matcher(s.title.toLowerCase())) {
      await db.from("case_steps").update({ status: "done", updated_at: new Date().toISOString() }).eq("id", s.id);
      s.status = "done";
    }
  }
  const next = steps.find((s) => s.status !== "done" && s.status !== "skipped");
  for (const s of steps) {
    const want = next && s.id === next.id ? "active" : s.status === "active" ? "pending" : s.status;
    if (want !== s.status) await db.from("case_steps").update({ status: want }).eq("id", s.id);
  }
}
