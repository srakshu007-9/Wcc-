import { structured } from "@/lib/llm";
import { VerificationOutput } from "@/lib/schemas";
import { VERIFICATION_PROMPT } from "@/lib/prompts";
import { recordRun } from "@/lib/workflow/events";
import { retrieve, labelChunks, quoteIsGrounded } from "@/lib/retrieval/store";
import { caseContext } from "./context";

/**
 * Decides whether the ORIGINAL goal was achieved.
 * Hard guard: RESOLUTION_VERIFIED is only accepted if the cited quote literally appears in a resolution document chunk.
 */
export async function runVerification(caseId: string) {
  const ctx = await caseContext(caseId);
  const resChunks = await retrieve(caseId, [ctx.case.desired_outcome ?? ctx.case.original_goal, "payment confirmation credited transaction"], {
    kind: "resolution",
    limit: 8,
  });
  const caseChunks = await retrieve(caseId, [ctx.case.original_goal], { kind: "evidence", limit: 4 });
  const R = labelChunks(resChunks, "R");
  const C = labelChunks(caseChunks, "C");

  const user = `AVAILABLE STATE:\n${ctx.text}\n\nORIGINAL GOAL: ${ctx.case.original_goal}\nDESIRED OUTCOME: ${ctx.case.desired_outcome}\n\nRESOLUTION DOCUMENT CHUNKS:\n${R.text || "(none uploaded)"}\n\nCASE DOCUMENT CHUNKS:\n${C.text || "(none)"}\n\nReturn the JSON object.`;

  try {
    const r = await structured({ system: VERIFICATION_PROMPT, user, schema: VerificationOutput });
    let out = r.data;
    let guard: string | null = null;

    if (out.verdict === "RESOLUTION_VERIFIED") {
      const ch = R.refs.get(out.resolution_chunk_ref);
      if (!ch) guard = "No resolution document chunk was cited.";
      else if (!quoteIsGrounded(out.resolution_evidence_quote, ch.content)) guard = "The cited quote does not appear in the resolution document.";
      if (guard) {
        out = {
          ...out,
          verdict: resChunks.length ? "NOT_RESOLVED" : "INSUFFICIENT_EVIDENCE",
          summary: `Verification downgraded: ${guard} ${out.summary}`,
          checks: out.checks.map((c) =>
            /outcome/i.test(c.name) ? { ...c, passed: false, detail: `${c.detail} (${guard})` } : c
          ),
        };
      }
    }
    await recordRun(caseId, "VERIFICATION", { resolution_chunks: resChunks.length, guard }, out, {
      model: r.model,
      confidence: out.confidence,
      durationMs: r.durationMs,
    });
    const refChunk = R.refs.get(out.resolution_chunk_ref);
    return { output: out, source: refChunk ? { document_id: refChunk.document_id, page: refChunk.page, filename: refChunk.filename } : null, guard };
  } catch (e) {
    await recordRun(caseId, "VERIFICATION", {}, null, { error: e instanceof Error ? e.message : String(e) });
    throw e;
  }
}
