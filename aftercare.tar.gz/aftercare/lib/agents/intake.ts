import { structured } from "@/lib/llm";
import { IntakeOutput } from "@/lib/schemas";
import { INTAKE_PROMPT } from "@/lib/prompts";
import { recordRun } from "@/lib/workflow/events";

export async function runIntake(caseId: string, goal: string, documentNames: string[]) {
  const user = `AVAILABLE STATE:\nUser description:\n"""${goal}"""\n\nUploaded document names: ${documentNames.join(", ") || "none"}\n\nReturn the JSON object.`;
  try {
    const r = await structured({ system: INTAKE_PROMPT, user, schema: IntakeOutput });
    await recordRun(caseId, "INTAKE", { goal, documentNames }, r.data, {
      model: r.model,
      confidence: r.data.confidence,
      durationMs: r.durationMs,
    });
    return r.data;
  } catch (e) {
    await recordRun(caseId, "INTAKE", { goal }, null, { error: e instanceof Error ? e.message : String(e) });
    throw e;
  }
}
