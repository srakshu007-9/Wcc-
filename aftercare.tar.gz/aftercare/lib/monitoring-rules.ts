// Deterministic monitoring rules (pure). The LLM explains and recovers; it does not decide whether time has passed.

export type Comm = { direction: "outbound" | "inbound"; created_at: string };

export type Deviation =
  | { kind: "none"; expected: string; actual: string }
  | { kind: "overdue"; expected: string; actual: string; hoursOverdue: number }
  | { kind: "response_received"; expected: string; actual: string };

export function detectDeviation(input: {
  now: Date;
  responseDueAt: string | null;
  expectedDays: number;
  comms: Comm[];
  lastVerificationAt?: string | null;
}): Deviation {
  const expected = `Response within ${input.expectedDays} day(s) of the last outbound request`;
  const outbound = input.comms.filter((c) => c.direction === "outbound");
  const lastOut = outbound.length ? outbound[outbound.length - 1].created_at : null;
  const inboundAfter = input.comms.filter(
    (c) =>
      c.direction === "inbound" &&
      (!lastOut || c.created_at >= lastOut) &&
      (!input.lastVerificationAt || c.created_at > input.lastVerificationAt)
  );
  if (inboundAfter.length) {
    return { kind: "response_received", expected, actual: "A response has been received and needs verification" };
  }
  if (!input.responseDueAt) return { kind: "none", expected, actual: "No outbound request is being tracked" };
  const due = new Date(input.responseDueAt).getTime();
  const diffH = (input.now.getTime() - due) / 3600_000;
  if (diffH > 0) {
    return {
      kind: "overdue",
      expected,
      actual: `No response ${Math.round(diffH / 24 + input.expectedDays)} day(s) after the request`,
      hoursOverdue: Math.round(diffH),
    };
  }
  return { kind: "none", expected, actual: `Still inside the response window (${Math.ceil(-diffH)}h remaining)` };
}
