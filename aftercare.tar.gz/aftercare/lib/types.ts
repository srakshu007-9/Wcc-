export type CaseRow = {
  id: string;
  case_number: number;
  title: string;
  original_goal: string;
  desired_outcome: string | null;
  category: string | null;
  current_state_summary: string | null;
  current_stage: string;
  status: string;
  confidence: number | null;
  priority: string | null;
  deadline: string | null;
  next_action: string | null;
  escalation_level: number;
  resolution_status: string;
  resolution_evidence: string | null;
  progress: number;
  response_due_at: string | null;
  expected_response_days: number;
  sim_clock_offset_hours: number;
  missing_information: string[];
  created_at: string;
  updated_at: string;
  open_blocker?: string | null;
  pending_approval?: boolean;
};

export type CaseDetail = {
  case: CaseRow;
  steps: any[];
  documents: any[];
  evidence: any[];
  actions: any[];
  approvals: any[];
  communications: any[];
  blockers: any[];
  followups: any[];
  escalations: any[];
  resolutions: any[];
  transitions: any[];
  events: any[];
  runs: any[];
  audit: any[];
};

export const caseId = (n: number) => `AC-${1000 + n}`;
