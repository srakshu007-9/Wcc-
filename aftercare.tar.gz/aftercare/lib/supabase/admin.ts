import { createClient, SupabaseClient } from "@supabase/supabase-js";

let client: SupabaseClient | null = null;

/** Service-role client. Server-only. Bypasses RLS, so every caller must check ownership first. */
export function admin(): SupabaseClient {
  if (client) return client;
  const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
  const key = process.env.SUPABASE_SERVICE_ROLE_KEY;
  if (!url || !key) {
    throw new AppError(
      "CONFIG_MISSING",
      "Supabase is not configured. Set NEXT_PUBLIC_SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY (see .env.example).",
      500
    );
  }
  client = createClient(url, key, { auth: { persistSession: false } });
  return client;
}

export class AppError extends Error {
  constructor(public code: string, message: string, public status = 400) {
    super(message);
  }
}
