import { admin } from "@/lib/supabase/admin";
import { ownedCase } from "./events";

export async function caseDetail(caseId: string, userId: string) {
  const c = await ownedCase(caseId, userId);
  const db = admin();
  const q = (t: string, order = "created_at", asc = true) => db.from(t).select("*").eq("case_id", caseId).order(order, { ascending: asc });
  const [steps, docs, evidence, actions, approvals, comms, blockers, followups, escalations, resolutions, transitions, events, runs, audit] = await Promise.all([
    q("case_steps", "position"),
    q("documents"),
    q("evidence"),
    q("actions"),
    q("approvals"),
    q("communications"),
    q("blockers"),
    q("followups"),
    q("escalations"),
    q("resolutions"),
    q("state_transitions"),
    q("agent_events"),
    q("agent_runs"),
    q("audit_logs"),
  ]);
  return {
    case: c,
    steps: steps.data ?? [],
    documents: docs.data ?? [],
    evidence: evidence.data ?? [],
    actions: actions.data ?? [],
    approvals: approvals.data ?? [],
    communications: comms.data ?? [],
    blockers: blockers.data ?? [],
    followups: followups.data ?? [],
    escalations: escalations.data ?? [],
    resolutions: resolutions.data ?? [],
    transitions: transitions.data ?? [],
    events: events.data ?? [],
    runs: (runs.data ?? []).map((r) => ({ ...r, input: undefined })),
    audit: audit.data ?? [],
  };
}

export async function listCases(userId: string) {
  const db = admin();
  const { data } = await db.from("cases").select("*").eq("user_id", userId).order("updated_at", { ascending: false });
  const cases = data ?? [];
  const ids = cases.map((c) => c.id);
  const [{ data: blockers }, { data: pending }] = ids.length
    ? await Promise.all([
        db.from("blockers").select("case_id, description, status").in("case_id", ids).eq("status", "open"),
        db.from("actions").select("case_id, id").in("case_id", ids).eq("status", "pending_approval"),
      ])
    : [{ data: [] }, { data: [] }];
  return cases.map((c) => ({
    ...c,
    open_blocker: (blockers ?? []).find((b) => b.case_id === c.id)?.description ?? null,
    pending_approval: (pending ?? []).some((p) => p.case_id === c.id),
  }));
}

export async function recentActivity(userId: string, limit = 25) {
  const db = admin();
  const { data: cs } = await db.from("cases").select("id, title, case_number").eq("user_id", userId);
  const ids = (cs ?? []).map((c) => c.id);
  if (!ids.length) return [];
  const { data } = await db.from("agent_events").select("*").in("case_id", ids).order("created_at", { ascending: false }).limit(limit);
  const map = new Map((cs ?? []).map((c) => [c.id, c]));
  return (data ?? []).map((e) => ({ ...e, case_title: map.get(e.case_id)?.title, case_number: map.get(e.case_id)?.case_number }));
}
