import { admin, AppError } from "@/lib/supabase/admin";
import { canTransition, CaseState, PROGRESS_OF, STAGE_OF } from "@/lib/state-machine";

type Json = Record<string, unknown> | unknown[] | null;

export async function audit(caseId: string, userId: string | null, actor: string, event: string, details?: Json) {
  await admin().from("audit_logs").insert({ case_id: caseId, user_id: userId, actor, event, details: details ?? null });
}

export async function event(
  caseId: string,
  agent: string | null,
  type: string,
  message: string,
  opts?: { data?: Json; simulated?: boolean }
) {
  await admin()
    .from("agent_events")
    .insert({ case_id: caseId, agent, type, message, data: opts?.data ?? null, simulated: opts?.simulated ?? false });
}

/** Every state change goes through here: validated, persisted, logged. */
export async function transition(
  caseId: string,
  to: CaseState,
  trigger: string,
  agent: string | null,
  patch: Record<string, unknown> = {}
) {
  const db = admin();
  const { data: c, error } = await db.from("cases").select("status").eq("id", caseId).single();
  if (error || !c) throw new AppError("NOT_FOUND", "Case not found.", 404);
  const from = c.status as CaseState;
  if (from !== to && !canTransition(from, to)) {
    throw new AppError("INVALID_TRANSITION", `Illegal state transition ${from} → ${to} (trigger: ${trigger}).`, 409);
  }
  const upd = await db
    .from("cases")
    .update({
      status: to,
      current_stage: STAGE_OF[to],
      progress: PROGRESS_OF[to],
      updated_at: new Date().toISOString(),
      ...patch,
    })
    .eq("id", caseId);
  if (upd.error) throw new AppError("DB_FAILURE", `Could not update case: ${upd.error.message}`, 500);
  await db.from("state_transitions").insert({ case_id: caseId, from_state: from, to_state: to, trigger, agent });
  return { from, to };
}

export async function recordRun(
  caseId: string,
  agent: string,
  input: Json,
  output: Json,
  meta: { model?: string; confidence?: number; durationMs?: number; error?: string }
) {
  await admin().from("agent_runs").insert({
    case_id: caseId,
    agent,
    input,
    output,
    model: meta.model ?? null,
    confidence: meta.confidence ?? null,
    duration_ms: meta.durationMs ?? null,
    status: meta.error ? "failed" : "ok",
    error: meta.error ?? null,
  });
}

/** Load a case and enforce ownership. */
export async function ownedCase(caseId: string, userId: string) {
  const { data, error } = await admin().from("cases").select("*").eq("id", caseId).maybeSingle();
  if (error) throw new AppError("DB_FAILURE", error.message, 500);
  if (!data || data.user_id !== userId) throw new AppError("NOT_FOUND", "Case not found.", 404);
  return data;
}
