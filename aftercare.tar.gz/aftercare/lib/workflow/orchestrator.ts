import { admin, AppError } from "@/lib/supabase/admin";
import { audit, event, ownedCase, transition } from "./events";
import { runIntake } from "@/lib/agents/intake";
import { runEvidence } from "@/lib/agents/evidence";
import { advancePlan, runPlanner } from "@/lib/agents/planner";
import { runAction, ActionMode } from "@/lib/agents/action";
import { runMonitoringAgent } from "@/lib/agents/monitoring";
import { runVerification } from "@/lib/agents/verification";
import { caseContext, caseNow } from "@/lib/agents/context";
import { detectDeviation } from "@/lib/monitoring-rules";
import { ingestDocument } from "@/lib/retrieval/store";
import type { CaseState } from "@/lib/state-machine";

const errMsg = (e: unknown) => (e instanceof Error ? e.message : String(e));

// ---------------------------------------------------------------- create

export async function createCase(userId: string, goal: string) {
  const { data, error } = await admin()
    .from("cases")
    .insert({
      user_id: userId,
      title: goal.slice(0, 60),
      original_goal: goal,
      problem_statement: goal,
      status: "NEW",
      current_stage: "UNDERSTAND",
      progress: 3,
    })
    .select()
    .single();
  if (error) throw new AppError("DB_FAILURE", `Could not create the case: ${error.message}`, 500);
  await event(data.id, "SYSTEM", "case_created", "Case created from the user's goal.");
  await audit(data.id, userId, "user", "case_created", { goal });
  return data;
}

// ---------------------------------------------------------------- analyze (intake → evidence → plan → draft action)

export async function analyzeCase(caseId: string, userId: string) {
  const c = await ownedCase(caseId, userId);
  if (c.status !== "NEW" && c.status !== "FAILED")
    throw new AppError("INVALID_STATE", `This case is already ${c.status}; analysis only runs on new or failed cases.`, 409);
  const db = admin();
  const { data: docs } = await db.from("documents").select("filename").eq("case_id", caseId);
  const names = (docs ?? []).map((d) => d.filename as string);

  try {
    // 1. Intake
    await transition(caseId, "UNDERSTANDING", "analysis started", "INTAKE");
    await event(caseId, "INTAKE", "agent_started", "Intake Agent is reading the goal.");
    const intake = await runIntake(caseId, c.original_goal, names);
    await db
      .from("cases")
      .update({
        title: intake.title,
        category: intake.category,
        desired_outcome: intake.desired_outcome,
        current_state_summary: intake.current_state,
        priority: intake.urgency,
        entities: intake.entities,
        missing_information: intake.missing_information,
        expected_response_days: intake.expected_response_days,
        confidence: intake.confidence,
      })
      .eq("id", caseId);
    await event(caseId, "INTAKE", "goal_understood", `Goal identified: ${intake.desired_outcome}`, { data: intake });

    // 2. Evidence
    await transition(caseId, "EVIDENCE_COLLECTION", "goal understood", "INTAKE");
    await event(caseId, "EVIDENCE", "agent_started", `Evidence Agent is reading ${names.length} document(s).`);
    const ev = await runEvidence(caseId, c.original_goal, intake);
    await db
      .from("cases")
      .update({ current_state_summary: ev.output.current_state_assessment, confidence: Math.min(intake.confidence, ev.output.confidence) })
      .eq("id", caseId);
    await event(
      caseId,
      "EVIDENCE",
      ev.output.verdict === "SUFFICIENT" ? "evidence_verified" : "insufficient_evidence",
      ev.output.verdict === "SUFFICIENT"
        ? `${ev.output.found.length} grounded evidence item(s) found; ${ev.output.missing.length} missing.`
        : `INSUFFICIENT_EVIDENCE: ${ev.output.found.length} grounded item(s), ${ev.output.missing.length} missing.`,
      { data: { dropped_ungrounded: ev.droppedUngrounded } }
    );

    // 3. Plan
    await transition(caseId, "PLANNING", "evidence assessed", "EVIDENCE");
    await event(caseId, "PLANNER", "agent_started", "Planning Agent is building the action plan.");
    const plan = await runPlanner(caseId, "Initial plan for a new case");
    await event(caseId, "PLANNER", "plan_generated", `Plan generated with ${plan.steps.length} steps. Next: ${plan.next_action}`);

    // 4. Prepare first action → human approval
    await event(caseId, "ACTION", "agent_started", "Action Agent is drafting the first request.");
    const action = await runAction(caseId, "first_contact");
    await transition(caseId, "WAITING_FOR_APPROVAL", "action drafted; approval required", "ACTION");
    await event(caseId, "ACTION", "approval_required", `Human approval required: ${action.title}`, { data: { action_id: action.id } });
    await audit(caseId, null, "agent:ACTION", "action_drafted", { action_id: action.id });
    return action;
  } catch (e) {
    await failSafely(caseId, e, "analysis");
    throw e;
  }
}

async function failSafely(caseId: string, e: unknown, phase: string) {
  try {
    const { data: c } = await admin().from("cases").select("status").eq("id", caseId).single();
    const s = c?.status as CaseState | undefined;
    const target: CaseState =
      s === "BLOCKED" || s === "FOLLOW_UP_REQUIRED" || s === "ESCALATION_REQUIRED" || s === "RESOLUTION_VERIFICATION" ? "HUMAN_INTERVENTION_REQUIRED" : "FAILED";
    await event(caseId, "SYSTEM", "action_blocked", `Action blocked during ${phase}: ${errMsg(e)}`);
    await transition(caseId, target, `${phase} failed`, "SYSTEM");
  } catch {
    /* never mask the original error */
  }
}

// ---------------------------------------------------------------- approve / reject

export async function approveAction(caseId: string, userId: string, actionId: string, edits?: { body?: string; subject?: string }) {
  const c = await ownedCase(caseId, userId);
  if (c.status !== "WAITING_FOR_APPROVAL")
    throw new AppError("INVALID_STATE", "This case is not waiting for approval.", 409);
  const db = admin();
  const { data: action } = await db.from("actions").select("*").eq("id", actionId).eq("case_id", caseId).maybeSingle();
  if (!action) throw new AppError("NOT_FOUND", "Action not found.", 404);
  if (action.status !== "pending_approval") throw new AppError("INVALID_STATE", "This action was already decided.", 409);

  const edited = !!(edits?.body && edits.body !== action.body) || !!(edits?.subject && edits.subject !== action.subject);
  const finalBody = edits?.body ?? action.body;
  const finalSubject = edits?.subject ?? action.subject;
  await db.from("approvals").insert({
    case_id: caseId,
    action_id: actionId,
    user_id: userId,
    decision: edited ? "edited_and_approved" : "approved",
    original_body: action.body,
    final_body: finalBody,
  });
  await db.from("actions").update({ status: "approved", body: finalBody, subject: finalSubject }).eq("id", actionId);
  await audit(caseId, userId, "user", edited ? "action_edited_and_approved" : "action_approved", { action_id: actionId, type: action.type });
  await event(caseId, "USER", "approved", edited ? "You edited and approved the action." : "You approved the action.", { data: { action_id: actionId } });

  try {
    await transition(caseId, "ACTION_READY", "human approved", "USER");
    // ---- SIMULATED EXTERNAL EXECUTION: nothing leaves this system. ----
    await db.from("communications").insert({
      case_id: caseId,
      direction: "outbound",
      channel: "simulated",
      counterparty: action.recipient,
      subject: finalSubject,
      body: finalBody,
      simulated: true,
    });
    await db.from("actions").update({ status: "executed", executed_at: new Date().toISOString() }).eq("id", actionId);
    const newLevel = action.type === "ESCALATE" ? 2 : action.type === "FOLLOW_UP" ? Math.max(1, c.escalation_level) : c.escalation_level;
    const due = new Date(caseNow(c.sim_clock_offset_hours).getTime() + Number(c.expected_response_days) * 86400_000);
    await transition(caseId, "ACTION_EXECUTED", "approved action executed (simulated)", "ACTION", {
      escalation_level: newLevel,
      response_due_at: due.toISOString(),
    });
    await event(caseId, "ACTION", "executed", `SIMULATED EXTERNAL ACTION: "${action.title}" was recorded as sent. No real organization was contacted.`, {
      simulated: true,
      data: { action_id: actionId },
    });
    await audit(caseId, userId, "agent:ACTION", "action_executed_simulated", { action_id: actionId });
    await advancePlan(caseId, (t) => (action.type === "FOLLOW_UP" || action.type === "ESCALATE" ? /follow|escalat|recover/.test(t) : /prepare|draft|approv|submit|send|request|status/.test(t)));

    await transition(caseId, "MONITORING", "monitoring activated", "MONITORING", { next_action: "Monitor for a response within the expected window" });
    await event(caseId, "MONITORING", "monitoring_started", `Monitoring Agent is watching for a response (expected within ${c.expected_response_days} day(s)).`);
  } catch (e) {
    await failSafely(caseId, e, "execution");
    throw e;
  }
  return ownedCase(caseId, userId);
}

export async function rejectAction(caseId: string, userId: string, actionId: string, note?: string) {
  const c = await ownedCase(caseId, userId);
  if (c.status !== "WAITING_FOR_APPROVAL") throw new AppError("INVALID_STATE", "This case is not waiting for approval.", 409);
  const db = admin();
  const { data: action } = await db.from("actions").select("*").eq("id", actionId).eq("case_id", caseId).maybeSingle();
  if (!action || action.status !== "pending_approval") throw new AppError("NOT_FOUND", "Pending action not found.", 404);
  await db.from("actions").update({ status: "rejected" }).eq("id", actionId);
  await db.from("approvals").insert({ case_id: caseId, action_id: actionId, user_id: userId, decision: "rejected", original_body: action.body, note: note ?? null });
  await audit(caseId, userId, "user", "action_rejected", { action_id: actionId, note });
  await event(caseId, "USER", "rejected", `You rejected "${action.title}".${note ? ` Reason: ${note}` : ""}`);
  try {
    await transition(caseId, "PLANNING", "human rejected action; replanning", "USER");
    await runPlanner(caseId, `The user rejected the proposed action "${action.title}". Reason: ${note || "none given"}. Replan.`);
    const mode: ActionMode = action.type === "ESCALATE" ? "escalation" : action.type === "FOLLOW_UP" ? "follow_up" : "first_contact";
    const next = await runAction(caseId, mode, { reason: `The previous draft was rejected by the user. ${note ? "Their note: " + note : ""}` });
    await transition(caseId, "WAITING_FOR_APPROVAL", "revised action drafted", "ACTION");
    await event(caseId, "ACTION", "approval_required", `Revised draft ready for approval: ${next.title}`);
  } catch (e) {
    await failSafely(caseId, e, "replanning after rejection");
    throw e;
  }
  return ownedCase(caseId, userId);
}

// ---------------------------------------------------------------- monitor

export async function monitorCase(caseId: string, userId: string) {
  let c = await ownedCase(caseId, userId);
  if (c.status === "HUMAN_INTERVENTION_REQUIRED") {
    await transition(caseId, "MONITORING", "user retried monitoring", "USER");
    c = await ownedCase(caseId, userId);
  }
  if (c.status !== "MONITORING") throw new AppError("INVALID_STATE", `Monitoring only runs on cases in MONITORING (this one is ${c.status}).`, 409);
  const db = admin();
  const ctx = await caseContext(caseId);
  const { data: lastRes } = await db.from("resolutions").select("created_at").eq("case_id", caseId).order("created_at", { ascending: false }).limit(1);
  const now = caseNow(c.sim_clock_offset_hours);
  const dev = detectDeviation({
    now,
    responseDueAt: c.response_due_at,
    expectedDays: Number(c.expected_response_days),
    comms: ctx.comms.map((m) => ({ direction: m.direction, created_at: m.created_at })),
    lastVerificationAt: lastRes?.[0]?.created_at ?? null,
  });
  await event(caseId, "MONITORING", "check", `Check: expected "${dev.expected}"; actual "${dev.actual}".`, { data: { deviation: dev } });

  if (dev.kind === "none") return { result: "on_track" as const, deviation: dev };

  if (dev.kind === "response_received") {
    await transition(caseId, "RESOLUTION_PENDING", "response received; verification needed", "MONITORING", { next_action: "Verify that the original goal was actually achieved" });
    await event(caseId, "MONITORING", "response_received", "A response arrived. A response is not resolution, so the Verification Agent must check the outcome.");
    return { result: "response_received" as const, deviation: dev };
  }

  // overdue → blocker → recovery
  try {
    await transition(caseId, "BLOCKED", "expected response window exceeded", "MONITORING");
    await event(caseId, "MONITORING", "blocker_detected", "BLOCKER_DETECTED: expected response window exceeded.");
    const note = `Hours past due: ${dev.hoursOverdue}. Escalation level so far: ${c.escalation_level}. Follow-ups sent: ${ctx.actions.filter((a) => a.type === "FOLLOW_UP" && a.status === "executed").length}.`;
    const m = await runMonitoringAgent(caseId, dev, note);
    const { data: blocker } = await db
      .from("blockers")
      .insert({ case_id: caseId, type: m.blocker_type, description: m.blocker_description, why_it_matters: m.why_it_matters, recommended_recovery: m.recovery_rationale, status: "open" })
      .select()
      .single();
    await audit(caseId, null, "agent:MONITORING", "blocker_detected", { blocker_id: blocker?.id, recovery: m.recommended_recovery });

    if (m.recommended_recovery === "HUMAN_INTERVENTION") {
      await transition(caseId, "HUMAN_INTERVENTION_REQUIRED", "no safe automated recovery", "MONITORING", { next_action: "Review the blocker and decide how to proceed" });
      await event(caseId, "MONITORING", "human_intervention", `Human intervention required: ${m.recovery_rationale}`);
      return { result: "human_intervention" as const, deviation: dev };
    }

    const escalate = m.recommended_recovery === "ESCALATE";
    await transition(caseId, escalate ? "ESCALATION_REQUIRED" : "FOLLOW_UP_REQUIRED", `recovery: ${m.recommended_recovery}`, "MONITORING");
    await event(caseId, "PLANNER", "replan_required", "REPLAN_REQUIRED: planner invoked for recovery.");
    await runPlanner(caseId, `Blocker detected: ${m.blocker_description}. Recovery chosen: ${m.recommended_recovery}. Replan from the current state without repeating completed steps.`);
    const action = await runAction(caseId, escalate ? "escalation" : "follow_up", { blockerId: blocker?.id, reason: m.blocker_description });
    await db.from("followups").insert({ case_id: caseId, blocker_id: blocker?.id ?? null, action_id: action.id, status: "drafted", due_at: now.toISOString() });
    if (escalate) await db.from("escalations").insert({ case_id: caseId, level: c.escalation_level + 1, reason: m.blocker_description, action_id: action.id });
    await transition(caseId, "WAITING_FOR_APPROVAL", "recovery action drafted; approval required", "ACTION", { next_action: action.title });
    await event(caseId, "ACTION", "approval_required", `Human approval required: ${action.title}`, { data: { action_id: action.id } });
    return { result: "blocker_detected" as const, deviation: dev, actionId: action.id };
  } catch (e) {
    await failSafely(caseId, e, "recovery");
    throw e;
  }
}

// ---------------------------------------------------------------- verify

export async function verifyCase(caseId: string, userId: string) {
  const c = await ownedCase(caseId, userId);
  if (c.status !== "MONITORING" && c.status !== "RESOLUTION_PENDING")
    throw new AppError("INVALID_STATE", `Verification runs from MONITORING or RESOLUTION_PENDING (this case is ${c.status}).`, 409);
  const db = admin();
  try {
    await transition(caseId, "RESOLUTION_VERIFICATION", "verification requested", "VERIFICATION");
    await event(caseId, "VERIFICATION", "agent_started", "Verification Agent is checking whether the original goal was achieved.");
    const v = await runVerification(caseId);
    const o = v.output;
    await db.from("resolutions").insert({
      case_id: caseId,
      verdict: o.verdict,
      checks: o.checks,
      summary: o.summary,
      evidence_refs: v.source ? [v.source] : [],
      confidence: o.confidence,
    });
    await audit(caseId, null, "agent:VERIFICATION", "verification_result", { verdict: o.verdict, guard: v.guard });

    if (o.verdict === "RESOLUTION_VERIFIED") {
      await db.from("blockers").update({ status: "resolved", resolved_at: new Date().toISOString() }).eq("case_id", caseId).eq("status", "open");
      await transition(caseId, "COMPLETED", "resolution verified with evidence", "VERIFICATION", {
        resolution_status: "RESOLUTION_VERIFIED",
        resolution_evidence: o.resolution_evidence_quote,
        next_action: null,
        confidence: o.confidence,
      });
      await advancePlan(caseId, () => true);
      await event(caseId, "VERIFICATION", "resolution_verified", "RESOLUTION VERIFIED: the original goal was achieved and evidence was found.");
    } else {
      const due = new Date(caseNow(c.sim_clock_offset_hours).getTime() + Number(c.expected_response_days) * 86400_000);
      await db.from("blockers").insert({
        case_id: caseId,
        type: "OUTCOME_NOT_VERIFIED",
        description: o.verdict === "NOT_RESOLVED" ? "A response was received but it does not prove the original goal was achieved." : "There is not enough evidence to confirm the outcome.",
        why_it_matters: "A case is only closed when the real outcome is evidenced, not when a reply arrives.",
        recommended_recovery: "Request explicit proof of the outcome, or provide a confirmation document.",
        status: "open",
      });
      await transition(caseId, "MONITORING", `${o.verdict}; case stays active`, "VERIFICATION", {
        resolution_status: o.verdict,
        response_due_at: due.toISOString(),
        next_action: "Request proof of the outcome or upload confirmation",
      });
      await event(caseId, "VERIFICATION", "not_resolved", `${o.verdict}: ${o.summary}`);
    }
    return { verdict: o.verdict, output: o, guard: v.guard };
  } catch (e) {
    await failSafely(caseId, e, "verification");
    throw e;
  }
}

// ---------------------------------------------------------------- demo simulation (external world only)

const SAMPLE_PAYMENT = `PAYMENT CONFIRMATION — DEMO SAMPLE (simulated external document created by AFTERCARE Demo Mode)

Subject: Scholarship disbursement completed

The sanctioned scholarship amount has been credited to the student's registered bank account.
Disbursement status: PAID.

This document was generated by Demo Mode to simulate an institution's confirmation. It does not come from a real organization.`;

export async function simulate(caseId: string, userId: string, kind: "delay" | "response_ack" | "response_blocker" | "resolution_evidence") {
  if (process.env.NEXT_PUBLIC_DEMO_MODE === "false") throw new AppError("DEMO_DISABLED", "Demo Mode is disabled in this deployment.", 403);
  const c = await ownedCase(caseId, userId);
  if (c.status !== "MONITORING") throw new AppError("INVALID_STATE", `Simulations apply while a case is in MONITORING (this one is ${c.status}).`, 409);
  const db = admin();

  if (kind === "delay") {
    const due = c.response_due_at ? new Date(c.response_due_at).getTime() : Date.now();
    const need = Math.max(24, Math.ceil((due - caseNow(c.sim_clock_offset_hours).getTime()) / 3600_000) + 24);
    await db.from("cases").update({ sim_clock_offset_hours: c.sim_clock_offset_hours + need }).eq("id", caseId);
    await event(caseId, "SYSTEM", "simulated_delay", `SIMULATED: case clock advanced by ${need} hours (demo control). No real time passed.`, { simulated: true });
    await audit(caseId, userId, "user", "simulate_delay", { hours: need });
  } else if (kind === "response_ack" || kind === "response_blocker") {
    const body =
      kind === "response_ack"
        ? "Your request has been processed. Thank you for contacting us."
        : "Your payment is on hold pending verification of bank account details. Please allow additional time.";
    await db.from("communications").insert({ case_id: caseId, direction: "inbound", channel: "simulated", counterparty: "Institution office (simulated)", subject: "Re: status request", body, simulated: true });
    await event(caseId, "SYSTEM", "simulated_response", `SIMULATED EXTERNAL RESPONSE received: "${body}"`, { simulated: true });
    await audit(caseId, userId, "user", `simulate_${kind}`, {});
  } else {
    await ingestDocument({ userId, caseId, filename: "demo_payment_confirmation.txt", mime: "text/plain", buffer: Buffer.from(SAMPLE_PAYMENT), kind: "resolution" });
    await db.from("communications").insert({ case_id: caseId, direction: "inbound", channel: "simulated", counterparty: "Institution office (simulated)", subject: "Payment confirmation", body: "Please find the payment confirmation attached.", simulated: true });
    await event(caseId, "SYSTEM", "simulated_resolution_evidence", "SIMULATED: a demo payment confirmation document was attached as resolution evidence.", { simulated: true });
    await audit(caseId, userId, "user", "simulate_resolution_evidence", {});
  }
  return monitorCase(caseId, userId);
}

/** Registers a real user-uploaded resolution document and lets monitoring pick it up. */
export async function addResolutionEvidence(caseId: string, userId: string, file: { filename: string; mime: string; buffer: Buffer }) {
  const c = await ownedCase(caseId, userId);
  if (c.status !== "MONITORING") throw new AppError("INVALID_STATE", "Resolution evidence can be added while the case is in MONITORING.", 409);
  const doc = await ingestDocument({ userId, caseId, ...file, kind: "resolution" });
  await admin().from("communications").insert({ case_id: caseId, direction: "inbound", channel: "upload", counterparty: "Uploaded by you", subject: "Resolution evidence", body: `Document uploaded: ${doc.filename}`, simulated: false });
  await event(caseId, "USER", "resolution_evidence_uploaded", `You uploaded resolution evidence: ${doc.filename}`);
  await audit(caseId, userId, "user", "resolution_evidence_uploaded", { document_id: doc.id });
  return monitorCase(caseId, userId);
}

// ---------------------------------------------------------------- advance (demo)

export async function advanceCase(caseId: string, userId: string) {
  const c = await ownedCase(caseId, userId);
  switch (c.status as CaseState) {
    case "NEW":
    case "FAILED":
      await analyzeCase(caseId, userId);
      return { step: "analyzed", message: "Case analyzed. Approval is required before anything is executed." };
    case "WAITING_FOR_APPROVAL":
      return { step: "needs_approval", message: "Human approval is required. AFTERCARE will not act on its own here." };
    case "MONITORING": {
      if (c.escalation_level === 0) {
        await simulate(caseId, userId, "delay");
        return { step: "delay_simulated", message: "Delay simulated; the Monitoring Agent checked the case." };
      }
      await simulate(caseId, userId, "resolution_evidence");
      return { step: "resolution_simulated", message: "Demo resolution evidence attached. Run verification next." };
    }
    case "RESOLUTION_PENDING":
    case "RESOLUTION_VERIFICATION": {
      const v = await verifyCase(caseId, userId);
      return { step: "verified", message: `Verification result: ${v.verdict}` };
    }
    case "HUMAN_INTERVENTION_REQUIRED":
      await monitorCase(caseId, userId);
      return { step: "retried", message: "Monitoring retried." };
    case "COMPLETED":
      return { step: "done", message: "Resolution already verified." };
    default:
      return { step: "noop", message: `Nothing to advance from ${c.status}.` };
  }
}

// ---------------------------------------------------------------- delete (privacy)

export async function deleteCase(caseId: string, userId: string) {
  await ownedCase(caseId, userId);
  const db = admin();
  const { data: docs } = await db.from("documents").select("storage_path").eq("case_id", caseId);
  const paths = (docs ?? []).map((d) => d.storage_path as string).filter(Boolean);
  if (paths.length) await db.storage.from("case-documents").remove(paths);
  const { error } = await db.from("cases").delete().eq("id", caseId);
  if (error) throw new AppError("DB_FAILURE", `Could not delete the case: ${error.message}`, 500);
}
