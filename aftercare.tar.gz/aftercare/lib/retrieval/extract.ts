import { AppError } from "@/lib/supabase/admin";

export type Page = { page: number; text: string };

export type Extracted = { pages: Page[]; status: "ok" | "empty" | "failed"; error?: string };

/** Extract text with page numbers. Images need OCR, which is not bundled; they are stored but flagged. */
export async function extractText(buf: Buffer, mime: string): Promise<Extracted> {
  try {
    if (mime === "text/plain") {
      const text = buf.toString("utf8").replace(/\u0000/g, "");
      return text.trim() ? { pages: [{ page: 1, text }], status: "ok" } : { pages: [], status: "empty" };
    }
    if (mime === "application/pdf") {
      const { extractText: pdfText, getDocumentProxy } = await import("unpdf");
      const pdf = await getDocumentProxy(new Uint8Array(buf));
      const { text } = await pdfText(pdf, { mergePages: false });
      const pages = (Array.isArray(text) ? text : [text])
        .map((t, i) => ({ page: i + 1, text: t.trim() }))
        .filter((p) => p.text.length > 0);
      return pages.length
        ? { pages, status: "ok" }
        : {
            pages: [],
            status: "empty",
            error: "This PDF has no selectable text (it may be a scan). Upload a text-based PDF or a .txt copy.",
          };
    }
    if (mime === "application/vnd.openxmlformats-officedocument.wordprocessingml.document") {
      const mammoth = await import("mammoth");
      const { value } = await mammoth.extractRawText({ buffer: buf });
      return value.trim() ? { pages: [{ page: 1, text: value }], status: "ok" } : { pages: [], status: "empty" };
    }
    if (mime === "image/png" || mime === "image/jpeg") {
      return {
        pages: [],
        status: "empty",
        error:
          "OCR is not enabled in this deployment, so no text was read from this image. Upload a PDF, DOCX or TXT version for it to count as evidence.",
      };
    }
    throw new AppError("UNSUPPORTED_TYPE", `Unsupported file type: ${mime}`, 415);
  } catch (e) {
    if (e instanceof AppError) throw e;
    return {
      pages: [],
      status: "failed",
      error: `Text extraction failed (${e instanceof Error ? e.message : "unknown error"}). The file may be corrupted or password-protected.`,
    };
  }
}

export type Chunk = { page: number; index: number; content: string };

/** Paragraph-aware chunking, ~900 chars, with page numbers preserved. */
export function chunkPages(pages: Page[], max = 900): Chunk[] {
  const out: Chunk[] = [];
  let index = 0;
  for (const p of pages) {
    const paras = p.text.split(/\n{2,}|\r\n{2,}/).map((s) => s.replace(/\s+/g, " ").trim()).filter(Boolean);
    let buf = "";
    const flush = () => {
      if (buf.trim()) out.push({ page: p.page, index: index++, content: buf.trim() });
      buf = "";
    };
    for (const para of paras.length ? paras : [p.text.replace(/\s+/g, " ").trim()]) {
      if ((buf + " " + para).length > max && buf) flush();
      if (para.length > max) {
        for (let i = 0; i < para.length; i += max) {
          buf = para.slice(i, i + max);
          flush();
        }
      } else buf = buf ? buf + " " + para : para;
    }
    flush();
  }
  return out;
}
