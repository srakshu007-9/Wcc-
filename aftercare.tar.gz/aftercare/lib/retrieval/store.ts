import { admin, AppError } from "@/lib/supabase/admin";
import { embed } from "@/lib/llm";
import { extractText, chunkPages } from "./extract";
import { ALLOWED_MIME, MAX_FILE_BYTES } from "@/lib/schemas";

export type ChunkRow = { id: string; document_id: string; page: number | null; content: string; filename?: string };

/** Validate, store, extract, chunk and embed one document. */
export async function ingestDocument(opts: {
  userId: string;
  caseId: string;
  filename: string;
  mime: string;
  buffer: Buffer;
  kind?: "evidence" | "resolution";
}) {
  const { userId, caseId, filename, mime, buffer } = opts;
  if (!(ALLOWED_MIME as readonly string[]).includes(mime))
    throw new AppError("UNSUPPORTED_TYPE", "Only PDF, DOCX, PNG, JPG and TXT files are accepted.", 415);
  if (buffer.length > MAX_FILE_BYTES)
    throw new AppError("FILE_TOO_LARGE", `File is larger than ${MAX_FILE_BYTES / 1024 / 1024} MB.`, 413);
  if (buffer.length === 0) throw new AppError("EMPTY_FILE", "The file is empty.", 400);

  const db = admin();
  const safe = filename.replace(/[^\w.\-]+/g, "_").slice(0, 120);
  const path = `${userId}/${caseId}/${Date.now()}_${safe}`;
  const up = await db.storage.from("case-documents").upload(path, buffer, { contentType: mime });
  if (up.error) throw new AppError("STORAGE_FAILED", `Could not store the file: ${up.error.message}`, 500);

  const ex = await extractText(buffer, mime);
  const { data: doc, error } = await db
    .from("documents")
    .insert({
      case_id: caseId,
      user_id: userId,
      filename: safe,
      mime_type: mime,
      size_bytes: buffer.length,
      storage_path: path,
      page_count: ex.pages.length || null,
      extraction_status: ex.status,
      extraction_error: ex.error ?? null,
      kind: opts.kind ?? "evidence",
    })
    .select()
    .single();
  if (error) throw new AppError("DB_FAILURE", `Could not save document metadata: ${error.message}`, 500);

  const chunks = chunkPages(ex.pages);
  if (chunks.length) {
    const vectors = await embed(chunks.map((c) => c.content));
    const rows = chunks.map((c, i) => ({
      document_id: doc.id,
      case_id: caseId,
      chunk_index: c.index,
      page: c.page,
      content: c.content,
      embedding: vectors?.[i] ? (`[${vectors[i].join(",")}]` as unknown as number[]) : null,
    }));
    const ins = await db.from("document_chunks").insert(rows);
    if (ins.error) throw new AppError("DB_FAILURE", `Could not save document text: ${ins.error.message}`, 500);
  }
  return doc;
}

/** Semantic retrieval for a set of queries; falls back to all chunks (capped) if embeddings are unavailable. */
export async function retrieve(caseId: string, queries: string[], opts?: { kind?: "evidence" | "resolution" | "all"; limit?: number }) {
  const db = admin();
  const limit = opts?.limit ?? 14;
  const { data: docs } = await db.from("documents").select("id, filename, kind").eq("case_id", caseId);
  const docMap = new Map((docs ?? []).map((d) => [d.id as string, d]));
  const kind = opts?.kind ?? "all";
  const allowed = (id: string) => {
    const d = docMap.get(id);
    return !!d && (kind === "all" || d.kind === kind);
  };

  const picked = new Map<string, ChunkRow>();
  const vectors = queries.length ? await embed(queries) : null;
  if (vectors) {
    for (const v of vectors) {
      const { data } = await db.rpc("match_chunks", {
        p_case_id: caseId,
        p_embedding: `[${v.join(",")}]`,
        p_count: 8,
      });
      for (const r of (data ?? []) as ChunkRow[]) if (allowed(r.document_id)) picked.set(r.id, r);
    }
  }
  if (picked.size === 0) {
    const { data } = await db
      .from("document_chunks")
      .select("id, document_id, page, content")
      .eq("case_id", caseId)
      .order("chunk_index")
      .limit(60);
    for (const r of (data ?? []) as ChunkRow[]) if (allowed(r.document_id)) picked.set(r.id, r);
  }
  return [...picked.values()].slice(0, limit).map((c) => ({ ...c, filename: docMap.get(c.document_id)?.filename as string }));
}

export function labelChunks(chunks: ChunkRow[], prefix = "C") {
  const refs = new Map<string, ChunkRow>();
  const text = chunks
    .map((c, i) => {
      const ref = `${prefix}${i + 1}`;
      refs.set(ref, c);
      return `[${ref}] (file: ${c.filename ?? "unknown"}, page ${c.page ?? "?"})\n${c.content}`;
    })
    .join("\n\n");
  return { refs, text };
}

const norm = (s: string) => s.toLowerCase().replace(/[\s ]+/g, " ").replace(/[“”"'`]/g, "").trim();

/** Grounding check: the quote must literally appear in the cited chunk. */
export function quoteIsGrounded(quote: string, chunkText: string) {
  const q = norm(quote);
  return q.length >= 8 && norm(chunkText).includes(q);
}
