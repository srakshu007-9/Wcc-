import { NextResponse } from "next/server";
import { ZodError } from "zod";
import { AppError } from "@/lib/supabase/admin";
import { requireUser } from "@/lib/supabase/server";

export type Ctx = { params: Promise<Record<string, string>> };

/** Wraps a route handler: auth, validation errors and typed errors become clean JSON. */
export function route<T>(fn: (user: { id: string; email?: string }, req: Request, ctx: Ctx) => Promise<T>) {
  return async (req: Request, ctx: Ctx) => {
    try {
      const user = await requireUser();
      const data = await fn({ id: user.id, email: user.email }, req, ctx);
      return NextResponse.json({ ok: true, data });
    } catch (e) {
      if (e instanceof ZodError)
        return NextResponse.json({ ok: false, error: { code: "VALIDATION", message: e.issues.map((i) => i.message).join(" ") } }, { status: 422 });
      if (e instanceof AppError)
        return NextResponse.json({ ok: false, error: { code: e.code, message: e.message } }, { status: e.status });
      console.error("[api]", e);
      return NextResponse.json(
        { ok: false, error: { code: "INTERNAL", message: "Something went wrong on our side. Your case data is safe. Please retry." } },
        { status: 500 }
      );
    }
  };
}

export async function jsonBody(req: Request) {
  try {
    return await req.json();
  } catch {
    throw new AppError("BAD_JSON", "Request body must be valid JSON.", 400);
  }
}
