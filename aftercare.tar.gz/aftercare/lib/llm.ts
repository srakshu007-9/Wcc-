import OpenAI from "openai";
import { z } from "zod";
import { AppError } from "@/lib/supabase/admin";

// Model abstraction layer. To swap providers, replace complete() and embed() only.

let openai: OpenAI | null = null;
function getClient() {
  if (!process.env.OPENAI_API_KEY) {
    throw new AppError(
      "AI_KEY_MISSING",
      "OPENAI_API_KEY is not set. Add it to your environment (see .env.example) and redeploy.",
      500
    );
  }
  openai ??= new OpenAI({ apiKey: process.env.OPENAI_API_KEY, timeout: 45_000, maxRetries: 1 });
  return openai;
}

export const MODEL = () => process.env.AFTERCARE_MODEL || "gpt-4o-mini";

/** Calls the model in JSON mode and validates the result against a zod schema. One repair retry. */
export async function structured<T extends z.ZodTypeAny>(opts: {
  system: string;
  user: string;
  schema: T;
}): Promise<{ data: z.infer<T>; model: string; durationMs: number }> {
  const started = Date.now();
  const client = getClient();
  let lastError = "";
  for (let attempt = 0; attempt < 2; attempt++) {
    try {
      const res = await client.chat.completions.create({
        model: MODEL(),
        temperature: 0.1,
        response_format: { type: "json_object" },
        messages: [
          { role: "system", content: opts.system },
          {
            role: "user",
            content:
              opts.user +
              (lastError ? `\n\nYour previous output failed validation: ${lastError}\nReturn corrected JSON only.` : ""),
          },
        ],
      });
      const text = res.choices[0]?.message?.content ?? "";
      const parsed = opts.schema.safeParse(JSON.parse(text));
      if (parsed.success) return { data: parsed.data, model: MODEL(), durationMs: Date.now() - started };
      lastError = parsed.error.issues.map((i) => `${i.path.join(".")}: ${i.message}`).join("; ");
    } catch (e: unknown) {
      if (e instanceof AppError) throw e;
      const msg = e instanceof Error ? e.message : String(e);
      if (attempt === 1) throw new AppError("AI_FAILURE", `The AI model call failed: ${msg}. Try again in a moment.`, 502);
      lastError = msg;
    }
  }
  throw new AppError("AI_INVALID_OUTPUT", `The agent returned output that failed validation: ${lastError}`, 502);
}

export async function embed(texts: string[]): Promise<number[][] | null> {
  if (texts.length === 0) return [];
  try {
    const res = await getClient().embeddings.create({
      model: process.env.AFTERCARE_EMBEDDING_MODEL || "text-embedding-3-small",
      input: texts,
    });
    return res.data.map((d) => d.embedding);
  } catch {
    return null; // caller falls back to lexical/all-chunks retrieval
  }
}
