import { z } from "zod";

// ---------- Agent output schemas (validated with zod after every LLM call) ----------

export const IntakeOutput = z.object({
  title: z.string().min(3).max(120),
  category: z.string(),
  desired_outcome: z.string(),
  current_state: z.string(),
  urgency: z.enum(["low", "medium", "high"]),
  entities: z.record(z.string()).default({}),
  missing_information: z.array(z.string()).default([]),
  expected_response_days: z.number().min(0.01).max(60).default(3),
  required_evidence: z.array(z.string()).default([]),
  confidence: z.number().min(0).max(1),
});
export type IntakeOutput = z.infer<typeof IntakeOutput>;

export const EvidenceOutput = z.object({
  verdict: z.enum(["SUFFICIENT", "INSUFFICIENT_EVIDENCE"]),
  found: z.array(
    z.object({
      label: z.string(),
      fact: z.string(),
      quote: z.string().describe("Exact text copied from the cited chunk"),
      chunk_ref: z.string().describe("e.g. C3"),
      requirement: z.string().optional(),
    })
  ),
  missing: z.array(z.object({ requirement: z.string(), why_needed: z.string() })),
  current_state_assessment: z.string(),
  confidence: z.number().min(0).max(1),
});
export type EvidenceOutput = z.infer<typeof EvidenceOutput>;

export const PlanStep = z.object({
  title: z.string(),
  description: z.string(),
  requires_approval: z.boolean(),
  depends_on: z.array(z.number()).default([]),
  status: z.enum(["pending", "done", "skipped"]).default("pending"),
  rationale: z.string(),
});

export const PlannerOutput = z.object({
  goal: z.string(),
  current_state: z.string(),
  steps: z.array(PlanStep).min(3).max(14),
  next_action: z.string(),
  why: z.string(),
  evidence_refs: z.array(z.string()).default([]),
  confidence: z.number().min(0).max(1),
});
export type PlannerOutput = z.infer<typeof PlannerOutput>;

export const ActionOutput = z.object({
  action_type: z.enum(["DRAFT_MESSAGE", "SUBMIT_REQUEST", "FOLLOW_UP", "ESCALATE"]),
  title: z.string(),
  recipient: z.string(),
  purpose: z.string(),
  subject: z.string(),
  body: z.string().min(20),
  evidence_used: z.array(z.string()).default([]),
  risk: z.enum(["low", "medium", "high"]),
  why_asking: z.string().describe("Plain-language reason the user is being asked to approve this"),
  confidence: z.number().min(0).max(1),
});
export type ActionOutput = z.infer<typeof ActionOutput>;

export const MonitoringOutput = z.object({
  assessment: z.string(),
  blocker_type: z.string(),
  blocker_description: z.string(),
  why_it_matters: z.string(),
  recommended_recovery: z.enum(["FOLLOW_UP", "ESCALATE", "HUMAN_INTERVENTION"]),
  recovery_rationale: z.string(),
  confidence: z.number().min(0).max(1),
});
export type MonitoringOutput = z.infer<typeof MonitoringOutput>;

export const VerificationOutput = z.object({
  verdict: z.enum(["RESOLUTION_VERIFIED", "NOT_RESOLVED", "INSUFFICIENT_EVIDENCE"]),
  checks: z.array(z.object({ name: z.string(), passed: z.boolean(), detail: z.string() })),
  summary: z.string(),
  resolution_evidence_quote: z.string().default(""),
  resolution_chunk_ref: z.string().default(""),
  confidence: z.number().min(0).max(1),
});
export type VerificationOutput = z.infer<typeof VerificationOutput>;

// ---------- API input schemas ----------

export const CreateCaseInput = z.object({
  goal: z.string().trim().min(10, "Describe what you are trying to get finished (at least 10 characters).").max(4000),
  documentIds: z.array(z.string().uuid()).max(10).default([]),
});

export const ApproveInput = z.object({
  actionId: z.string().uuid(),
  editedBody: z.string().trim().min(20).max(8000).optional(),
  editedSubject: z.string().trim().min(3).max(300).optional(),
});

export const RejectInput = z.object({
  actionId: z.string().uuid(),
  note: z.string().trim().max(1000).optional(),
});

export const SimulateInput = z.object({
  kind: z.enum(["delay", "response_ack", "response_blocker", "resolution_evidence"]),
});

export const ALLOWED_MIME = [
  "application/pdf",
  "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
  "image/png",
  "image/jpeg",
  "text/plain",
] as const;
export const MAX_FILE_BYTES = 8 * 1024 * 1024;
