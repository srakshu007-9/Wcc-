-- AFTERCARE schema. Run in Supabase SQL editor (see DATABASE_SETUP.md).
create extension if not exists vector;
create extension if not exists pgcrypto;

-- Users are managed by Supabase Auth (auth.users). profiles mirrors them.
create table if not exists profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  email text,
  created_at timestamptz not null default now()
);

create table if not exists cases (
  id uuid primary key default gen_random_uuid(),
  case_number serial,
  user_id uuid not null references auth.users(id) on delete cascade,
  title text not null,
  original_goal text not null,
  problem_statement text not null,
  desired_outcome text,
  category text,
  current_state_summary text,
  current_stage text not null default 'NEW',
  status text not null default 'NEW',
  confidence numeric,
  priority text default 'medium',
  deadline timestamptz,
  next_action text,
  assigned_actor text default 'user',
  escalation_level int not null default 0,
  resolution_status text not null default 'UNRESOLVED',
  resolution_evidence text,
  progress int not null default 0,
  response_due_at timestamptz,
  expected_response_days numeric not null default 3,
  sim_clock_offset_hours int not null default 0,
  entities jsonb default '{}'::jsonb,
  missing_information jsonb default '[]'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists case_steps (
  id uuid primary key default gen_random_uuid(),
  case_id uuid not null references cases(id) on delete cascade,
  position int not null,
  title text not null,
  description text,
  requires_approval boolean not null default false,
  depends_on int[] default '{}',
  status text not null default 'pending', -- pending | active | done | skipped
  rationale text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists documents (
  id uuid primary key default gen_random_uuid(),
  case_id uuid not null references cases(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  filename text not null,
  mime_type text not null,
  size_bytes int not null,
  storage_path text,
  page_count int,
  extraction_status text not null default 'pending', -- ok | failed | empty
  extraction_error text,
  kind text not null default 'evidence', -- evidence | resolution
  created_at timestamptz not null default now()
);

create table if not exists document_chunks (
  id uuid primary key default gen_random_uuid(),
  document_id uuid not null references documents(id) on delete cascade,
  case_id uuid not null references cases(id) on delete cascade,
  chunk_index int not null,
  page int,
  content text not null,
  embedding vector(1536),
  created_at timestamptz not null default now()
);
create index if not exists document_chunks_case_idx on document_chunks(case_id);

create table if not exists evidence (
  id uuid primary key default gen_random_uuid(),
  case_id uuid not null references cases(id) on delete cascade,
  document_id uuid references documents(id) on delete set null,
  label text not null,
  fact text not null,
  quote text,
  page int,
  requirement text,
  kind text not null default 'found', -- found | missing
  created_at timestamptz not null default now()
);

create table if not exists agent_runs (
  id uuid primary key default gen_random_uuid(),
  case_id uuid not null references cases(id) on delete cascade,
  agent text not null, -- INTAKE | EVIDENCE | PLANNER | ACTION | MONITORING | VERIFICATION
  input jsonb,
  output jsonb,
  model text,
  confidence numeric,
  status text not null default 'ok', -- ok | failed
  error text,
  duration_ms int,
  created_at timestamptz not null default now()
);

create table if not exists agent_events (
  id uuid primary key default gen_random_uuid(),
  case_id uuid not null references cases(id) on delete cascade,
  agent text,
  type text not null,
  message text not null,
  data jsonb,
  simulated boolean not null default false,
  created_at timestamptz not null default now()
);
create index if not exists agent_events_case_idx on agent_events(case_id, created_at);

create table if not exists actions (
  id uuid primary key default gen_random_uuid(),
  case_id uuid not null references cases(id) on delete cascade,
  type text not null, -- DRAFT_MESSAGE | SUBMIT_REQUEST | FOLLOW_UP | ESCALATE
  title text not null,
  recipient text,
  purpose text,
  body text,
  subject text,
  evidence_used jsonb default '[]'::jsonb,
  risk text default 'low',
  explanation text,
  requires_approval boolean not null default true,
  status text not null default 'pending_approval', -- pending_approval | approved | executed | rejected
  executed_at timestamptz,
  simulated boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists approvals (
  id uuid primary key default gen_random_uuid(),
  case_id uuid not null references cases(id) on delete cascade,
  action_id uuid not null references actions(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  decision text not null, -- approved | edited_and_approved | rejected
  original_body text,
  final_body text,
  note text,
  created_at timestamptz not null default now()
);

create table if not exists communications (
  id uuid primary key default gen_random_uuid(),
  case_id uuid not null references cases(id) on delete cascade,
  direction text not null, -- outbound | inbound
  channel text not null default 'simulated',
  counterparty text,
  subject text,
  body text not null,
  simulated boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists blockers (
  id uuid primary key default gen_random_uuid(),
  case_id uuid not null references cases(id) on delete cascade,
  type text not null,
  description text not null,
  why_it_matters text,
  recommended_recovery text,
  status text not null default 'open', -- open | resolved | ignored
  created_at timestamptz not null default now(),
  resolved_at timestamptz
);

create table if not exists followups (
  id uuid primary key default gen_random_uuid(),
  case_id uuid not null references cases(id) on delete cascade,
  blocker_id uuid references blockers(id) on delete set null,
  action_id uuid references actions(id) on delete set null,
  due_at timestamptz,
  status text not null default 'required', -- required | drafted | sent | cancelled
  created_at timestamptz not null default now()
);

create table if not exists escalations (
  id uuid primary key default gen_random_uuid(),
  case_id uuid not null references cases(id) on delete cascade,
  level int not null,
  reason text not null,
  action_id uuid references actions(id) on delete set null,
  created_at timestamptz not null default now()
);

create table if not exists resolutions (
  id uuid primary key default gen_random_uuid(),
  case_id uuid not null references cases(id) on delete cascade,
  verdict text not null, -- RESOLUTION_VERIFIED | NOT_RESOLVED | INSUFFICIENT_EVIDENCE
  checks jsonb not null default '[]'::jsonb,
  summary text,
  evidence_refs jsonb default '[]'::jsonb,
  confidence numeric,
  created_at timestamptz not null default now()
);

create table if not exists state_transitions (
  id uuid primary key default gen_random_uuid(),
  case_id uuid not null references cases(id) on delete cascade,
  from_state text,
  to_state text not null,
  trigger text not null,
  agent text,
  created_at timestamptz not null default now()
);
create index if not exists state_transitions_case_idx on state_transitions(case_id, created_at);

create table if not exists evaluation_runs (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  total_cases int not null,
  results jsonb not null,
  metrics jsonb not null,
  model text,
  created_at timestamptz not null default now()
);

create table if not exists audit_logs (
  id uuid primary key default gen_random_uuid(),
  case_id uuid references cases(id) on delete cascade,
  user_id uuid references auth.users(id) on delete set null,
  actor text not null, -- user | agent:<name> | system
  event text not null,
  details jsonb,
  created_at timestamptz not null default now()
);
create index if not exists audit_logs_case_idx on audit_logs(case_id, created_at);

-- Semantic retrieval scoped to a single case
create or replace function match_chunks(p_case_id uuid, p_embedding vector(1536), p_count int default 8)
returns table (id uuid, document_id uuid, page int, content text, similarity float)
language sql stable as $$
  select c.id, c.document_id, c.page, c.content, 1 - (c.embedding <=> p_embedding) as similarity
  from document_chunks c
  where c.case_id = p_case_id and c.embedding is not null
  order by c.embedding <=> p_embedding
  limit p_count;
$$;

-- Profile on signup
create or replace function handle_new_user() returns trigger language plpgsql security definer as $$
begin
  insert into profiles (id, email) values (new.id, new.email) on conflict do nothing;
  return new;
end $$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
  for each row execute function handle_new_user();

-- Row level security: users only see their own data.
alter table profiles enable row level security;
alter table cases enable row level security;
alter table case_steps enable row level security;
alter table documents enable row level security;
alter table document_chunks enable row level security;
alter table evidence enable row level security;
alter table agent_runs enable row level security;
alter table agent_events enable row level security;
alter table actions enable row level security;
alter table approvals enable row level security;
alter table communications enable row level security;
alter table blockers enable row level security;
alter table followups enable row level security;
alter table escalations enable row level security;
alter table resolutions enable row level security;
alter table state_transitions enable row level security;
alter table evaluation_runs enable row level security;
alter table audit_logs enable row level security;

create policy "own profile" on profiles for select using (id = auth.uid());
create policy "own cases" on cases for all using (user_id = auth.uid()) with check (user_id = auth.uid());
create policy "own evaluations" on evaluation_runs for all using (user_id = auth.uid()) with check (user_id = auth.uid());
create policy "own documents" on documents for all using (user_id = auth.uid()) with check (user_id = auth.uid());
create policy "own approvals" on approvals for select using (user_id = auth.uid());
create policy "own audit" on audit_logs for select using (user_id = auth.uid());

-- Child tables: readable when the parent case belongs to the user.
do $$
declare t text;
begin
  foreach t in array array['case_steps','document_chunks','evidence','agent_runs','agent_events','actions',
    'communications','blockers','followups','escalations','resolutions','state_transitions']
  loop
    execute format(
      'create policy "own via case" on %I for select using (exists (select 1 from cases c where c.id = %I.case_id and c.user_id = auth.uid()))',
      t, t);
  end loop;
end $$;
-- Writes to child tables happen server-side with the service role key only.

-- Private storage bucket for uploaded documents
insert into storage.buckets (id, name, public) values ('case-documents', 'case-documents', false)
on conflict (id) do nothing;
