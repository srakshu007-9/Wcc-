# Evaluation

Open **Evaluations** in the app and click **Run evaluation**. Until a run exists every metric shows "Not evaluated yet". Results are stored in `evaluation_runs` and shown per case, so nothing is estimated or hard-coded.

The harness (`lib/evaluation/run.ts`) uses the same prompts, schemas and guards as production, against the model set in `AFTERCARE_MODEL`. The labelled dataset is in `lib/evaluation/dataset.ts`. A run makes roughly 20 model calls.

| Metric | How it is measured | Kind |
|---|---|---|
| Goal understanding accuracy | 4 realistic goals: category and desired outcome match expected patterns; 1 vague input must yield confidence < 0.75 | model |
| Evidence extraction accuracy | 3 document sets: expected items found, expected items reported missing, no false "payment" claims, INSUFFICIENT_EVIDENCE when appropriate | model |
| Evidence grounding | every claimed quote must literally appear in the cited chunk | model + check |
| Plan correctness | has an approval step, ends with verification of the goal, no step falsely marked done | model |
| Blocker detection | 5 deterministic timing scenarios plus 2 recovery-choice cases (first follow-up vs escalate) | rules + model |
| State transition correctness | 14 legal/illegal transitions checked against the state machine | rules |
| Follow-up correctness | follow-up draft has type FOLLOW_UP and references the earlier request | model |
| Resolution verification accuracy | acknowledgement only, real confirmation, nothing, "on hold" notice: expected verdict after the literal-quote guard | model + check |
| Unsupported-action rate | drafts that contain invented identifiers (long numbers, emails, currency amounts) or cite non-existent evidence; reported as flagged fraction, lower is better | model + check |
| Human-approval compliance | externally facing plan steps must have `requires_approval = true` | model |

## Reading the results
- The benchmark is small and hand-written. It is a regression suite for these scenarios, not a general accuracy claim.
- Model-based metrics vary between runs. Re-run to see variance; change the model and compare.
- Human-approval compliance for drafted actions holds by construction (nothing executes without `/approve`), so the benchmark measures the planner's flagging instead.

## Extending
Add cases to `dataset.ts` and a matching branch in `run.ts`. Keep labels independent of model output.
