# Deployment (Vercel + Supabase)

## 1. Supabase
Follow `DATABASE_SETUP.md`. Keep the project URL, anon key and service-role key handy.

## 2. OpenAI
Create an API key at https://platform.openai.com. Default model is `gpt-4o-mini` (set `AFTERCARE_MODEL` to use a stronger one). Embeddings use `text-embedding-3-small` (1536 dims, matches the schema; if you change the embedding model, change the vector size in `schema.sql`).

## 3. Push the code
```bash
git init && git add . && git commit -m "AFTERCARE"
# create an empty GitHub repo, then:
git remote add origin <your repo url> && git push -u origin main
```

## 4. Vercel
1. https://vercel.com/new → import the repo. Framework: Next.js (auto-detected).
2. Add environment variables (Production and Preview):

| Name | Value |
|---|---|
| `NEXT_PUBLIC_SUPABASE_URL` | your project URL |
| `NEXT_PUBLIC_SUPABASE_ANON_KEY` | anon key |
| `SUPABASE_SERVICE_ROLE_KEY` | service-role key (server only) |
| `OPENAI_API_KEY` | your key (server only) |
| `AFTERCARE_MODEL` | optional, e.g. `gpt-4o-mini` |
| `NEXT_PUBLIC_DEMO_MODE` | `true` for the hackathon demo, `false` to hide simulation controls |

3. Deploy. Then in Supabase **Authentication → URL Configuration** set the Site URL to your Vercel URL.

## 5. Smoke test (do this before presenting)
1. Open the site, click **Try the demo**.
2. Run the demo script from `README.md` once end to end.
3. Open **Evaluations** and click **Run evaluation** to generate real measured scores.

## Notes
- Analysis, monitoring and verification routes call the model several times in sequence. They set `maxDuration` (60–120 s, evaluation 300 s). Check your Vercel plan's function duration limits; if analysis times out on a restrictive plan, lower the document size or use a faster model.
- `NEXT_PUBLIC_DEMO_MODE=false` is enforced on the server too: simulation and advance endpoints return an error.
- Fonts load from Google Fonts at runtime; if your policy forbids that, swap the `<link>` in `app/layout.tsx` for self-hosted fonts.
- Nothing in this app sends real email or contacts real organizations.
