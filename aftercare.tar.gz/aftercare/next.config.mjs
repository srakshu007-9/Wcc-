/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  serverExternalPackages: ["mammoth", "unpdf"],
  experimental: { serverActions: { bodySizeLimit: "10mb" } },
};
export default nextConfig;
