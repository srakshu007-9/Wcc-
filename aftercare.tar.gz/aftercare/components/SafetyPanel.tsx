import { Ban, BadgeCheck, FileSearch, Trash2, UserCheck, ScrollText } from "lucide-react";

const ITEMS = [
  [UserCheck, "You approve outbound actions", "Messages, submissions and escalations wait for approve, edit or reject. No exceptions."],
  [FileSearch, "Evidence must be quotable", "A claim only counts if its quote is found in your document. Others are discarded."],
  [BadgeCheck, "Closing needs proof", "A reply or a sent email never closes a case. A cited confirmation does."],
  [ScrollText, "Everything is logged", "State changes, agent runs, approvals and edits are stored in the audit trail."],
  [Ban, "Simulated means simulated", "In Demo Mode no real organization is contacted, and every such action is labeled."],
  [Trash2, "You can delete a case", "Deleting removes its records and the stored documents."],
] as const;

export function SafetyPanel() {
  return (
    <section aria-labelledby="safety-h" className="card p-6 sm:p-8">
      <h2 id="safety-h" className="font-display text-2xl font-extrabold">AI Safety &amp; Controls</h2>
      <ul className="mt-5 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
        {ITEMS.map(([Icon, t, d]) => (
          <li key={t} className="flex gap-3">
            <Icon className="mt-0.5 h-5 w-5 shrink-0 text-terra" aria-hidden />
            <div>
              <p className="font-semibold">{t}</p>
              <p className="text-sm text-ink-soft">{d}</p>
            </div>
          </li>
        ))}
      </ul>
    </section>
  );
}
