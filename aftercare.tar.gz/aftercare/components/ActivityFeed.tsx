"use client";
import Link from "next/link";
import { SimulatedTag, timeShort } from "@/components/ui";

type Ev = { id: string; agent: string | null; message: string; created_at: string; simulated: boolean; case_id: string; case_title?: string };

const AGENT: Record<string, string> = {
  INTAKE: "Intake Agent",
  EVIDENCE: "Evidence Agent",
  PLANNER: "Planning Agent",
  ACTION: "Action Agent",
  MONITORING: "Monitoring Agent",
  VERIFICATION: "Verification Agent",
  USER: "You",
  SYSTEM: "System",
};

export function ActivityFeed({ events, showCase = true }: { events: Ev[]; showCase?: boolean }) {
  if (!events.length)
    return <p className="rounded-xl border border-dashed border-ink/20 p-6 text-center text-ink-muted">No agent activity yet. Start a case and every step will show up here.</p>;
  return (
    <ol className="space-y-4" aria-live="polite">
      {events.map((e) => (
        <li key={e.id} className="grid grid-cols-[3.2rem_1fr] gap-3 text-sm">
          <time className="pt-0.5 font-semibold text-ink-muted" dateTime={e.created_at}>{timeShort(e.created_at)}</time>
          <div>
            <p>
              <span className="font-semibold">{AGENT[e.agent ?? "SYSTEM"] ?? e.agent}</span> · {e.message}
            </p>
            <div className="mt-1 flex flex-wrap items-center gap-2">
              {e.simulated && <SimulatedTag />}
              {showCase && e.case_title && (
                <Link href={`/app/cases/${e.case_id}`} className="text-xs font-semibold text-terra hover:underline">{e.case_title}</Link>
              )}
            </div>
          </div>
        </li>
      ))}
    </ol>
  );
}
