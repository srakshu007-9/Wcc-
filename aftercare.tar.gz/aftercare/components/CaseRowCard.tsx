"use client";
import Link from "next/link";
import { AlertTriangle, ArrowUpRight } from "lucide-react";
import { Confidence, Progress, StatePill } from "@/components/ui";
import { caseId, type CaseRow } from "@/lib/types";

export function CaseRowCard({ c }: { c: CaseRow }) {
  return (
    <Link href={`/app/cases/${c.id}`} className="card block p-5 transition-transform hover:-translate-y-0.5">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div className="min-w-0">
          <p className="text-xs font-semibold text-terra">Case #{caseId(c.case_number)}</p>
          <h3 className="truncate font-display text-xl font-extrabold">{c.title}</h3>
        </div>
        <div className="flex items-center gap-2">
          {c.pending_approval && <span className="rounded-full bg-warn-soft px-3 py-1 text-xs font-semibold text-warn">Needs approval</span>}
          <StatePill state={c.status} />
        </div>
      </div>
      <div className="mt-4 flex items-center gap-3">
        <div className="flex-1"><Progress value={c.progress} label={`${c.title} progress`} /></div>
        <span className="w-10 text-right text-sm font-semibold">{c.progress}%</span>
      </div>
      <dl className="mt-4 grid gap-x-6 gap-y-2 text-sm sm:grid-cols-2">
        <div>
          <dt className="text-ink-muted">Next action</dt>
          <dd className="font-medium">{c.next_action ?? "Not planned yet"}</dd>
        </div>
        <div>
          <dt className="text-ink-muted">Response expected by</dt>
          <dd className="font-medium">{c.response_due_at ? new Date(c.response_due_at).toLocaleDateString() : "Nothing pending"}</dd>
        </div>
      </dl>
      <div className="mt-3 flex flex-wrap items-center justify-between gap-2">
        {c.open_blocker ? (
          <p className="inline-flex items-center gap-1.5 text-sm font-semibold text-crit"><AlertTriangle className="h-4 w-4" aria-hidden /> {c.open_blocker}</p>
        ) : <span />}
        <span className="inline-flex items-center gap-2"><Confidence value={c.confidence} /><ArrowUpRight className="h-4 w-4 text-ink-muted" aria-hidden /></span>
      </div>
    </Link>
  );
}
