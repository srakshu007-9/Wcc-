"use client";
import { motion } from "framer-motion";
import { AlertTriangle, CheckCircle2, ChevronDown, Info, Loader2 } from "lucide-react";
import { useState } from "react";
import { STATE_LABEL, type CaseState } from "@/lib/state-machine";

export function StatePill({ state }: { state: string }) {
  const s = state as CaseState;
  const tone =
    s === "COMPLETED"
      ? "bg-ok-soft text-ok"
      : s === "BLOCKED" || s === "FAILED" || s === "HUMAN_INTERVENTION_REQUIRED" || s === "FOLLOW_UP_REQUIRED" || s === "ESCALATION_REQUIRED"
      ? "bg-crit-soft text-crit"
      : s === "WAITING_FOR_APPROVAL"
      ? "bg-warn-soft text-warn"
      : "bg-ink/10 text-ink";
  return <span className={`inline-flex items-center rounded-full px-3 py-1 text-xs font-semibold ${tone}`}>{STATE_LABEL[s] ?? state}</span>;
}

export function Progress({ value, label }: { value: number; label?: string }) {
  return (
    <div role="progressbar" aria-valuenow={value} aria-valuemin={0} aria-valuemax={100} aria-label={label ?? "Case progress"} className="h-2 w-full overflow-hidden rounded-full bg-ink/10">
      <motion.div className="h-full rounded-full bg-terra" initial={{ width: 0 }} animate={{ width: `${value}%` }} transition={{ type: "spring", stiffness: 90, damping: 18 }} />
    </div>
  );
}

export function Spinner({ label = "Working" }: { label?: string }) {
  return (
    <span role="status" className="inline-flex items-center gap-2 text-sm text-ink-muted">
      <Loader2 className="h-4 w-4 animate-spin" aria-hidden /> {label}
    </span>
  );
}

export function ErrorBox({ message, onRetry }: { message: string; onRetry?: () => void }) {
  return (
    <div role="alert" className="flex items-start gap-3 rounded-xl border border-crit/30 bg-crit-soft p-4 text-sm text-crit">
      <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0" aria-hidden />
      <div className="flex-1">
        <p className="font-semibold">Action blocked</p>
        <p className="mt-0.5 text-ink-soft">{message}</p>
      </div>
      {onRetry && (
        <button onClick={onRetry} className="btn-ghost !py-1.5">
          Try again
        </button>
      )}
    </div>
  );
}

export function Confidence({ value }: { value: number | null | undefined }) {
  if (value === null || value === undefined) return <span className="text-sm text-ink-muted">Not assessed</span>;
  const pct = Math.round(Number(value) * 100);
  const tone = pct >= 80 ? "text-ok" : pct >= 55 ? "text-warn" : "text-crit";
  return (
    <span className={`text-sm font-semibold ${tone}`} title="Model-reported confidence. It is a signal, not a guarantee.">
      {pct}% confidence
    </span>
  );
}

/** "Why am I asking you?" expandable explanation */
export function WhyAsking({ children, title = "Why am I asking you?" }: { children: React.ReactNode; title?: string }) {
  const [open, setOpen] = useState(false);
  return (
    <div className="rounded-xl border border-ink/10 bg-cream/60">
      <button onClick={() => setOpen(!open)} aria-expanded={open} className="flex w-full items-center justify-between gap-2 px-4 py-2.5 text-left text-sm font-semibold">
        <span className="inline-flex items-center gap-2">
          <Info className="h-4 w-4 text-terra" aria-hidden /> {title}
        </span>
        <ChevronDown className={`h-4 w-4 transition-transform ${open ? "rotate-180" : ""}`} aria-hidden />
      </button>
      {open && <div className="px-4 pb-3 text-sm leading-relaxed text-ink-soft">{children}</div>}
    </div>
  );
}

export function SimulatedTag({ children = "Simulated external action" }: { children?: React.ReactNode }) {
  return <span className="inline-flex items-center rounded-full border border-warn/40 bg-warn-soft px-2.5 py-0.5 text-xs font-semibold text-warn">{children}</span>;
}

export function Stat({ label, value, tone }: { label: string; value: number | string; tone?: "crit" | "warn" | "ok" }) {
  const c = tone === "crit" ? "text-crit" : tone === "warn" ? "text-warn" : tone === "ok" ? "text-ok" : "text-ink";
  return (
    <div className="card p-5">
      <p className={`font-display text-5xl font-extrabold ${c}`}>{value}</p>
      <p className="mt-1 text-sm text-ink-muted">{label}</p>
    </div>
  );
}

export function Check({ ok }: { ok: boolean }) {
  return ok ? <CheckCircle2 className="h-4 w-4 text-ok" aria-label="passed" /> : <AlertTriangle className="h-4 w-4 text-crit" aria-label="failed" />;
}

export function timeShort(iso: string) {
  return new Date(iso).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
}
export function dateTimeShort(iso: string) {
  return new Date(iso).toLocaleString([], { month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" });
}
