"use client";
import { AnimatePresence, motion } from "framer-motion";
import { AlertTriangle, ArrowRight, CheckCircle2, CircleDot } from "lucide-react";
import { useEffect, useState } from "react";

const STEPS = [
  { kind: "done", text: "Goal understood" },
  { kind: "done", text: "Evidence verified" },
  { kind: "done", text: "Action approved" },
  { kind: "done", text: "Request submitted" },
  { kind: "active", text: "Monitoring" },
  { kind: "warn", text: "Response overdue" },
  { kind: "next", text: "Recovery plan ready" },
] as const;

const PCT = [14, 28, 42, 56, 66, 72, 78];

/** Illustrative walkthrough of one case. It is not live data and says so. */
export function LiveCase() {
  const [n, setN] = useState(1);
  useEffect(() => {
    const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    if (reduce) {
      setN(STEPS.length);
      return;
    }
    const t = setInterval(() => setN((x) => (x >= STEPS.length ? 1 : x + 1)), 1400);
    return () => clearInterval(t);
  }, []);

  return (
    <div className="card relative w-full max-w-md p-6" aria-label="Illustrative live case example">
      <div className="flex items-start justify-between gap-3">
        <div>
          <p className="text-sm font-semibold text-terra">Case #AC-1042</p>
          <h3 className="font-display text-2xl font-extrabold leading-tight">Scholarship disbursement</h3>
        </div>
        <span className="rounded-full bg-ink px-3 py-1 text-xs font-semibold text-cream-light">Example</span>
      </div>
      <div className="mt-5 flex items-end justify-between">
        <motion.p key={PCT[n - 1]} initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} className="font-display text-6xl font-extrabold">
          {PCT[n - 1]}%
        </motion.p>
        <p className="pb-2 text-sm text-ink-muted">complete</p>
      </div>
      <div className="mt-2 h-2 overflow-hidden rounded-full bg-ink/10">
        <motion.div className="h-full rounded-full bg-terra" animate={{ width: `${PCT[n - 1]}%` }} transition={{ type: "spring", stiffness: 80, damping: 16 }} />
      </div>
      <ul className="mt-5 space-y-2.5">
        <AnimatePresence initial={false}>
          {STEPS.slice(0, n).map((s) => (
            <motion.li key={s.text} initial={{ opacity: 0, x: -10 }} animate={{ opacity: 1, x: 0 }} className="flex items-center gap-3 text-[15px]">
              {s.kind === "done" && <CheckCircle2 className="h-5 w-5 text-ok" aria-hidden />}
              {s.kind === "active" && <CircleDot className="h-5 w-5 text-terra" aria-hidden />}
              {s.kind === "warn" && <AlertTriangle className="h-5 w-5 text-warn" aria-hidden />}
              {s.kind === "next" && <ArrowRight className="h-5 w-5 text-terra" aria-hidden />}
              <span className={s.kind === "warn" ? "font-semibold text-warn" : ""}>{s.text}</span>
            </motion.li>
          ))}
        </AnimatePresence>
      </ul>
      <p className="mt-5 text-xs text-ink-muted">Illustration of a typical case. Your cases show real state.</p>
    </div>
  );
}
