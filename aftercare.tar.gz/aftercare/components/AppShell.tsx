"use client";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { Activity, FlaskConical, FolderOpen, LayoutDashboard, LogOut, PlusCircle } from "lucide-react";
import { browserClient } from "@/lib/supabase/browser";

const NAV = [
  { href: "/app", label: "Overview", icon: LayoutDashboard },
  { href: "/app/cases", label: "My cases", icon: FolderOpen },
  { href: "/app/new", label: "Create case", icon: PlusCircle },
  { href: "/app/activity", label: "Activity", icon: Activity },
  { href: "/app/evaluations", label: "Evaluations", icon: FlaskConical },
];

export function AppShell({ email, children }: { email?: string; children: React.ReactNode }) {
  const path = usePathname();
  const router = useRouter();
  const demo = process.env.NEXT_PUBLIC_DEMO_MODE !== "false";
  const active = (h: string) => (h === "/app" ? path === "/app" : path.startsWith(h));

  async function signOut() {
    await browserClient().auth.signOut();
    router.push("/");
    router.refresh();
  }

  return (
    <div className="min-h-screen md:grid md:grid-cols-[15rem_1fr]">
      <aside className="border-b border-ink/10 bg-cream-dark/50 md:sticky md:top-0 md:h-screen md:border-b-0 md:border-r">
        <div className="flex items-center justify-between px-5 py-4 md:block">
          <Link href="/app" className="font-display text-xl font-extrabold">AFTERCARE</Link>
          {demo && <p className="mt-1 hidden rounded-full bg-warn-soft px-2.5 py-0.5 text-xs font-semibold text-warn md:inline-block">Demo mode</p>}
        </div>
        <nav aria-label="Main" className="flex gap-1 overflow-x-auto px-3 pb-3 md:block md:space-y-1 md:overflow-visible md:pb-0">
          {NAV.map(({ href, label, icon: Icon }) => (
            <Link
              key={href}
              href={href}
              aria-current={active(href) ? "page" : undefined}
              className={`flex shrink-0 items-center gap-2.5 rounded-full px-4 py-2.5 text-sm font-semibold transition-colors ${active(href) ? "bg-ink text-cream-light" : "hover:bg-ink/5"}`}
            >
              <Icon className="h-4 w-4" aria-hidden /> {label}
            </Link>
          ))}
        </nav>
        <div className="hidden px-5 pt-8 md:absolute md:bottom-5 md:block md:w-full md:pr-5">
          <p className="truncate text-xs text-ink-muted">{email}</p>
          <button onClick={signOut} className="mt-2 inline-flex items-center gap-2 text-sm font-semibold hover:text-terra">
            <LogOut className="h-4 w-4" aria-hidden /> Sign out
          </button>
        </div>
      </aside>
      <main id="main" className="min-w-0 px-5 py-6 sm:px-8 sm:py-8">
        {children}
        <div className="mt-8 md:hidden">
          <button onClick={signOut} className="text-sm font-semibold text-ink-muted">Sign out</button>
        </div>
      </main>
    </div>
  );
}
