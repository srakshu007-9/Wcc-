"use client";
import { useState } from "react";
import { motion } from "framer-motion";
import { Pencil, ShieldAlert } from "lucide-react";
import { SimulatedTag, WhyAsking } from "@/components/ui";

type Action = {
  id: string;
  type: string;
  title: string;
  recipient: string | null;
  purpose: string | null;
  subject: string | null;
  body: string | null;
  evidence_used: string[];
  risk: string;
  explanation: string | null;
};

export function ApprovalCard({
  action,
  busy,
  onApprove,
  onReject,
}: {
  action: Action;
  busy: boolean;
  onApprove: (edits?: { editedBody?: string; editedSubject?: string }) => void;
  onReject: (note?: string) => void;
}) {
  const [editing, setEditing] = useState(false);
  const [body, setBody] = useState(action.body ?? "");
  const [subject, setSubject] = useState(action.subject ?? "");
  const [rejecting, setRejecting] = useState(false);
  const [note, setNote] = useState("");
  const risk = action.risk === "high" ? "text-crit" : action.risk === "medium" ? "text-warn" : "text-ok";
  const changed = body !== (action.body ?? "") || subject !== (action.subject ?? "");

  return (
    <motion.section
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      aria-labelledby="approval-h"
      className="rounded-[1.5rem] border-2 border-terra bg-cream-light p-6 shadow-soft sm:p-7"
    >
      <div className="flex flex-wrap items-center justify-between gap-3">
        <h2 id="approval-h" className="font-display text-3xl font-extrabold">AFTERCARE needs your approval</h2>
        <SimulatedTag />
      </div>
      <p className="mt-1 text-sm text-ink-muted">Recommended next action</p>
      <p className="mt-1 text-xl font-semibold">{action.title}</p>

      <dl className="mt-5 grid gap-4 sm:grid-cols-2">
        <div><dt className="text-sm text-ink-muted">To</dt><dd className="font-semibold">{action.recipient ?? "Not specified"}</dd></div>
        <div><dt className="text-sm text-ink-muted">Purpose</dt><dd className="font-semibold">{action.purpose}</dd></div>
        <div>
          <dt className="text-sm text-ink-muted">Evidence used</dt>
          <dd className="font-semibold">{action.evidence_used?.length ? action.evidence_used.join(", ") : "None cited"}</dd>
        </div>
        <div>
          <dt className="text-sm text-ink-muted">Risk</dt>
          <dd className={`inline-flex items-center gap-1.5 font-semibold capitalize ${risk}`}><ShieldAlert className="h-4 w-4" aria-hidden /> {action.risk}</dd>
        </div>
      </dl>

      <div className="mt-5">
        <p className="text-sm text-ink-muted">Generated message</p>
        {editing ? (
          <div className="mt-2 space-y-3">
            <label className="block text-sm font-semibold" htmlFor="ap-subject">Subject</label>
            <input id="ap-subject" className="field" value={subject} onChange={(e) => setSubject(e.target.value)} />
            <label className="block text-sm font-semibold" htmlFor="ap-body">Message</label>
            <textarea id="ap-body" className="field min-h-[12rem] font-[inherit]" value={body} onChange={(e) => setBody(e.target.value)} />
          </div>
        ) : (
          <div className="mt-2 rounded-xl border border-ink/10 bg-white p-4">
            <p className="font-semibold">{action.subject}</p>
            <p className="mt-2 whitespace-pre-wrap text-[15px] leading-relaxed">{action.body}</p>
          </div>
        )}
      </div>

      {action.explanation && <div className="mt-4"><WhyAsking>{action.explanation}</WhyAsking></div>}

      <p className="mt-4 text-sm text-ink-soft">
        In Demo Mode, approving records this message as sent inside AFTERCARE. No real organization is contacted.
      </p>

      {rejecting && (
        <div className="mt-4">
          <label htmlFor="rej" className="block text-sm font-semibold">What should change? (optional)</label>
          <input id="rej" className="field mt-1" value={note} maxLength={1000} onChange={(e) => setNote(e.target.value)} placeholder="For example: address it to the registrar instead" />
        </div>
      )}

      <div className="mt-5 flex flex-wrap gap-3">
        <button
          className="btn-primary"
          disabled={busy || (editing && body.trim().length < 20)}
          onClick={() => onApprove(editing && changed ? { editedBody: body, editedSubject: subject } : undefined)}
        >
          {editing && changed ? "Approve edits & execute" : "Approve & execute"}
        </button>
        <button className="btn-ghost" disabled={busy} onClick={() => setEditing(!editing)}>
          <Pencil className="h-4 w-4" aria-hidden /> {editing ? "Stop editing" : "Edit"}
        </button>
        {rejecting ? (
          <>
            <button className="btn-danger" disabled={busy} onClick={() => onReject(note.trim() || undefined)}>Confirm reject & replan</button>
            <button className="btn-ghost" disabled={busy} onClick={() => setRejecting(false)}>Cancel</button>
          </>
        ) : (
          <button className="btn-danger" disabled={busy} onClick={() => setRejecting(true)}>Reject</button>
        )}
      </div>
    </motion.section>
  );
}
