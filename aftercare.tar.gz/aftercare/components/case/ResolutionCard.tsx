"use client";
import { motion } from "framer-motion";
import { AlertTriangle, CheckCircle2, PartyPopper } from "lucide-react";
import type { CaseDetail } from "@/lib/types";

export function ResolutionCard({ d }: { d: CaseDetail }) {
  const latest = d.resolutions[d.resolutions.length - 1];
  if (!latest) return null;
  const verified = latest.verdict === "RESOLUTION_VERIFIED" && d.case.status === "COMPLETED";
  const ref = latest.evidence_refs?.[0];

  if (verified)
    return (
      <motion.section initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} aria-labelledby="res-h" className="rounded-[1.75rem] bg-ok p-7 text-white sm:p-9">
        <p className="inline-flex items-center gap-2 text-sm font-semibold"><PartyPopper className="h-5 w-5" aria-hidden /> Resolution verified</p>
        <h2 id="res-h" className="mt-1 font-display text-5xl font-extrabold">Goal verified</h2>
        <dl className="mt-5 grid gap-5 sm:grid-cols-2">
          <div><dt className="text-sm text-white/80">Original goal</dt><dd className="text-lg font-semibold">{d.case.desired_outcome ?? d.case.original_goal}</dd></div>
          <div>
            <dt className="text-sm text-white/80">Resolution evidence</dt>
            <dd className="text-lg font-semibold">
              {d.case.resolution_evidence ? `“${d.case.resolution_evidence}”` : "Cited in the resolution document"}
              {ref?.filename && <span className="block text-sm font-normal text-white/80">{ref.filename}{ref.page ? `, page ${ref.page}` : ""}</span>}
            </dd>
          </div>
        </dl>
        <h3 className="mt-6 font-display text-xl font-extrabold">Verification checks</h3>
        <ul className="mt-2 space-y-1.5">
          {(latest.checks ?? []).map((c: { name: string; passed: boolean; detail: string }) => (
            <li key={c.name} className="flex items-start gap-2">
              <CheckCircle2 className="mt-0.5 h-5 w-5 shrink-0" aria-hidden />
              <span><span className="font-semibold">{c.name}</span><span className="text-white/85"> · {c.detail}</span></span>
            </li>
          ))}
        </ul>
        <p className="mt-6 font-display text-2xl font-extrabold">Case closed</p>
        <p className="text-white/90">AFTERCARE verified the outcome instead of assuming completion.</p>
      </motion.section>
    );

  return (
    <section aria-labelledby="res-h" className="card border-warn/40 p-6">
      <h2 id="res-h" className="inline-flex items-center gap-2 font-display text-2xl font-extrabold text-warn">
        <AlertTriangle className="h-6 w-6" aria-hidden /> Not resolved yet
      </h2>
      <p className="mt-1 font-semibold">Verdict: {latest.verdict.replace(/_/g, " ").toLowerCase()}</p>
      <p className="mt-2 text-ink-soft">{latest.summary}</p>
      <ul className="mt-4 space-y-1.5 text-sm">
        {(latest.checks ?? []).map((c: { name: string; passed: boolean; detail: string }) => (
          <li key={c.name} className="flex items-start gap-2">
            {c.passed ? <CheckCircle2 className="mt-0.5 h-4 w-4 text-ok" aria-label="passed" /> : <AlertTriangle className="mt-0.5 h-4 w-4 text-crit" aria-label="failed" />}
            <span><span className="font-semibold">{c.name}</span> · {c.detail}</span>
          </li>
        ))}
      </ul>
      <p className="mt-4 text-sm text-ink-soft">The case stays active. A reply is not resolution until the outcome is evidenced.</p>
    </section>
  );
}
