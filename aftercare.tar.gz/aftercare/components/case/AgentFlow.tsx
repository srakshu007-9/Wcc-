"use client";
import { useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Confidence } from "@/components/ui";
import type { CaseDetail } from "@/lib/types";

const NODES = [
  { key: "UNDERSTAND", label: "Understand", agent: "Intake Agent" },
  { key: "EVIDENCE", label: "Evidence", agent: "Evidence Agent" },
  { key: "PLAN", label: "Plan", agent: "Planning Agent" },
  { key: "ACT", label: "Action", agent: "Action Agent" },
  { key: "MONITOR", label: "Monitor", agent: "Monitoring Agent" },
  { key: "RECOVER", label: "Recover", agent: "Monitoring & Recovery Agent" },
  { key: "VERIFY", label: "Verify", agent: "Verification Agent" },
] as const;

const lastRun = (d: CaseDetail, agent: string) => [...d.runs].reverse().find((r) => r.agent === agent && r.status === "ok");

function Row({ k, v }: { k: string; v: React.ReactNode }) {
  return (
    <div>
      <dt className="text-sm text-ink-muted">{k}</dt>
      <dd className="font-medium">{v}</dd>
    </div>
  );
}

export function AgentFlow({ d }: { d: CaseDetail }) {
  const stageOrder = NODES.map((n) => n.key as string);
  const activeKey = d.case.current_stage === "ACT" ? "ACT" : d.case.current_stage;
  const activeIdx = stageOrder.indexOf(activeKey);
  const [sel, setSel] = useState<string>(activeKey);
  const docName = (id: string | null) => d.documents.find((x) => x.id === id)?.filename ?? "document";

  const panel = () => {
    if (sel === "UNDERSTAND") {
      const r = lastRun(d, "INTAKE")?.output;
      if (!r) return <p className="text-ink-muted">The Intake Agent has not run yet.</p>;
      return (
        <dl className="grid gap-4 sm:grid-cols-2">
          <Row k="Goal" v={r.desired_outcome} />
          <Row k="Current state" v={r.current_state} />
          <Row k="Category" v={r.category} />
          <Row k="Urgency" v={<span className="capitalize">{r.urgency}</span>} />
          <Row k="Still unknown" v={r.missing_information?.length ? r.missing_information.join("; ") : "Nothing flagged"} />
          <Row k="Confidence" v={<Confidence value={r.confidence} />} />
        </dl>
      );
    }
    if (sel === "EVIDENCE") {
      const found = d.evidence.filter((e) => e.kind === "found");
      const miss = d.evidence.filter((e) => e.kind === "missing");
      return (
        <div className="space-y-4">
          <p className="font-semibold">{found.length} grounded item(s), {miss.length} missing{found.length === 0 ? " · INSUFFICIENT_EVIDENCE" : ""}</p>
          <ul className="space-y-3">
            {found.map((e) => (
              <li key={e.id} className="rounded-xl bg-cream p-3 text-sm">
                <p className="font-semibold">{e.label}</p>
                <p>{e.fact}</p>
                <p className="mt-1 text-ink-muted">“{e.quote}” · {docName(e.document_id)}{e.page ? `, page ${e.page}` : ""}</p>
              </li>
            ))}
            {miss.map((e) => (
              <li key={e.id} className="rounded-xl bg-warn-soft p-3 text-sm">
                <p className="font-semibold text-warn">Missing: {e.label}</p>
                <p>{e.fact}</p>
              </li>
            ))}
          </ul>
        </div>
      );
    }
    if (sel === "PLAN") {
      const r = lastRun(d, "PLANNER")?.output;
      if (!r) return <p className="text-ink-muted">The Planning Agent has not run yet.</p>;
      return (
        <dl className="grid gap-4 sm:grid-cols-2">
          <Row k="Goal" v={r.goal} />
          <Row k="Current state" v={r.current_state} />
          <Row k="Next action" v={r.next_action} />
          <Row k="Why" v={r.why} />
          <Row k="Evidence" v={r.evidence_refs?.length ? r.evidence_refs.join(", ") : "None cited"} />
          <Row k="Confidence" v={<Confidence value={r.confidence} />} />
        </dl>
      );
    }
    if (sel === "ACT") {
      const a = d.actions[d.actions.length - 1];
      if (!a) return <p className="text-ink-muted">No action has been prepared yet.</p>;
      return (
        <dl className="grid gap-4 sm:grid-cols-2">
          <Row k="Action" v={a.title} />
          <Row k="Status" v={<span className="capitalize">{a.status.replace(/_/g, " ")}{a.simulated && a.status === "executed" ? " (simulated)" : ""}</span>} />
          <Row k="To" v={a.recipient} />
          <Row k="Evidence used" v={a.evidence_used?.length ? a.evidence_used.join(", ") : "None cited"} />
          <Row k="Risk" v={<span className="capitalize">{a.risk}</span>} />
          <Row k="Why approval is needed" v={a.explanation ?? "Outbound actions always need your approval."} />
        </dl>
      );
    }
    if (sel === "MONITOR") {
      const ev = [...d.events].reverse().find((e) => e.type === "check");
      return (
        <dl className="grid gap-4 sm:grid-cols-2">
          <Row k="State" v={d.case.status === "MONITORING" ? "Watching for a response" : "Not currently monitoring"} />
          <Row k="Response expected by" v={d.case.response_due_at ? new Date(d.case.response_due_at).toLocaleString() : "Nothing pending"} />
          <Row k="Last check" v={ev ? ev.message : "No check has run yet"} />
          <Row k="Escalation level" v={d.case.escalation_level} />
        </dl>
      );
    }
    if (sel === "RECOVER") {
      const r = lastRun(d, "MONITORING")?.output;
      if (!r) return <p className="text-ink-muted">No blocker has been detected, so recovery has not been needed.</p>;
      return (
        <dl className="grid gap-4 sm:grid-cols-2">
          <Row k="Blocker" v={r.blocker_description} />
          <Row k="Why it matters" v={r.why_it_matters} />
          <Row k="Chosen recovery" v={r.recommended_recovery} />
          <Row k="Rationale" v={r.recovery_rationale} />
          <Row k="Confidence" v={<Confidence value={r.confidence} />} />
        </dl>
      );
    }
    const res = d.resolutions[d.resolutions.length - 1];
    if (!res) return <p className="text-ink-muted">Verification has not run yet. It runs after a response or resolution evidence arrives.</p>;
    return (
      <dl className="grid gap-4 sm:grid-cols-2">
        <Row k="Verdict" v={res.verdict.replace(/_/g, " ")} />
        <Row k="Summary" v={res.summary} />
        <Row k="Confidence" v={<Confidence value={res.confidence} />} />
      </dl>
    );
  };

  return (
    <div>
      <ol className="flex flex-wrap items-center gap-2" aria-label="Agent workflow">
        {NODES.map((n, i) => {
          const done = i < activeIdx || d.case.status === "COMPLETED";
          const active = i === activeIdx && d.case.status !== "COMPLETED";
          return (
            <li key={n.key} className="flex items-center gap-2">
              <button
                onClick={() => setSel(n.key)}
                aria-pressed={sel === n.key}
                className={`relative rounded-full px-4 py-2.5 text-sm font-semibold transition-colors ${sel === n.key ? "ring-2 ring-ink" : ""} ${active ? "bg-terra text-white" : done ? "bg-ok-soft text-ok" : "bg-ink/10 text-ink-soft"}`}
              >
                {active && <span className="pulse-ring absolute inset-0 rounded-full" aria-hidden />}
                <span className="relative">{n.label}</span>
              </button>
              {i < NODES.length - 1 && <span className="h-0.5 w-4 bg-ink/20" aria-hidden />}
            </li>
          );
        })}
      </ol>
      <AnimatePresence mode="wait">
        <motion.div key={sel} initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }} className="card mt-5 p-6">
          <h3 className="font-display text-2xl font-extrabold">{NODES.find((n) => n.key === sel)?.agent}</h3>
          <div className="mt-4">{panel()}</div>
        </motion.div>
      </AnimatePresence>
    </div>
  );
}
