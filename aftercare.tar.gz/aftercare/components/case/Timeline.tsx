"use client";
import { motion } from "framer-motion";
import { AlertTriangle, ArrowRight, CheckCircle2, CircleDot, Clock } from "lucide-react";
import { SimulatedTag, dateTimeShort } from "@/components/ui";
import { STATE_LABEL, type CaseState } from "@/lib/state-machine";

type Ev = { id: string; agent: string | null; type: string; message: string; created_at: string; simulated: boolean };

const WARN = new Set(["blocker_detected", "insufficient_evidence", "not_resolved", "human_intervention", "action_blocked", "simulated_delay", "replan_required"]);
const NEXT = new Set(["approval_required"]);

function icon(type: string, last: boolean) {
  if (WARN.has(type)) return <AlertTriangle className="h-4 w-4 text-warn" aria-label="attention" />;
  if (NEXT.has(type)) return <ArrowRight className="h-4 w-4 text-terra" aria-label="next" />;
  if (last && type === "monitoring_started") return <CircleDot className="h-4 w-4 text-terra" aria-label="in progress" />;
  return <CheckCircle2 className="h-4 w-4 text-ok" aria-label="done" />;
}

/** Entries come straight from the agent_events table. */
export function Timeline({ events }: { events: Ev[] }) {
  const list = events.filter((e) => e.type !== "agent_started" && e.type !== "check");
  if (!list.length) return <p className="text-ink-muted">No events yet.</p>;
  return (
    <ol className="relative ml-2 border-l-2 border-ink/10 pl-6">
      {list.map((e, i) => (
        <motion.li key={e.id} initial={{ opacity: 0, x: -6 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: Math.min(i, 8) * 0.03 }} className="relative pb-5 last:pb-0">
          <span className="absolute -left-[2.15rem] top-0.5 grid h-6 w-6 place-items-center rounded-full bg-cream-light ring-2 ring-ink/10">{icon(e.type, i === list.length - 1)}</span>
          <p className="text-[15px] font-medium">{e.message}</p>
          <p className="mt-0.5 flex flex-wrap items-center gap-2 text-xs text-ink-muted">
            <Clock className="h-3 w-3" aria-hidden /> {dateTimeShort(e.created_at)}
            {e.simulated && <SimulatedTag />}
          </p>
        </motion.li>
      ))}
    </ol>
  );
}

type Tr = { id: string; from_state: string | null; to_state: string; trigger: string; agent: string | null; created_at: string };

export function StateHistory({ transitions, current }: { transitions: Tr[]; current: string }) {
  return (
    <ol className="space-y-2 text-sm">
      {transitions.map((t) => (
        <li key={t.id} className="flex flex-wrap items-center gap-x-2 gap-y-1">
          <span className="text-ink-muted">{dateTimeShort(t.created_at)}</span>
          <span className="rounded-full bg-ink/10 px-2.5 py-0.5 font-semibold">{STATE_LABEL[t.from_state as CaseState] ?? t.from_state ?? "Start"}</span>
          <ArrowRight className="h-3.5 w-3.5 text-terra" aria-hidden />
          <span className={`rounded-full px-2.5 py-0.5 font-semibold ${t.to_state === current ? "bg-terra text-white" : "bg-ink/10"}`}>{STATE_LABEL[t.to_state as CaseState] ?? t.to_state}</span>
          <span className="text-ink-muted">because {t.trigger}</span>
        </li>
      ))}
    </ol>
  );
}
