"use client";
import { motion } from "framer-motion";
import { AlertTriangle } from "lucide-react";
import { dateTimeShort } from "@/components/ui";

type Blocker = { id: string; type: string; description: string; why_it_matters: string | null; recommended_recovery: string | null; created_at: string };

export function BlockerCard({ blocker }: { blocker: Blocker }) {
  return (
    <motion.section
      initial={{ opacity: 0, scale: 0.98 }}
      animate={{ opacity: 1, scale: 1 }}
      role="alert"
      className="rounded-[1.5rem] border-2 border-crit/50 bg-crit-soft p-6"
    >
      <p className="inline-flex items-center gap-2 font-display text-2xl font-extrabold text-crit">
        <AlertTriangle className="h-6 w-6" aria-hidden /> Blocker detected
      </p>
      <p className="mt-2 text-lg font-semibold">{blocker.description}</p>
      <p className="mt-1 text-xs text-ink-muted">Detected {dateTimeShort(blocker.created_at)}</p>
      {blocker.why_it_matters && (
        <div className="mt-4">
          <h3 className="font-display text-lg font-extrabold">Why this matters</h3>
          <p className="text-ink-soft">{blocker.why_it_matters}</p>
        </div>
      )}
      {blocker.recommended_recovery && (
        <div className="mt-4">
          <h3 className="font-display text-lg font-extrabold">Recommended recovery</h3>
          <p className="text-ink-soft">{blocker.recommended_recovery}</p>
        </div>
      )}
    </motion.section>
  );
}
