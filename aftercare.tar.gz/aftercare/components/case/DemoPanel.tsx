"use client";
import { useRef } from "react";
import { FastForward, FileUp } from "lucide-react";
import type { CaseRow } from "@/lib/types";

type Props = { c: CaseRow; busy: string | null; run: (label: string, url: string, json?: unknown) => void; onUpload: (f: File) => void };

export function DemoPanel({ c, busy, run, onUpload }: Props) {
  const file = useRef<HTMLInputElement>(null);
  const monitoring = c.status === "MONITORING";
  const canVerify = monitoring || c.status === "RESOLUTION_PENDING";
  const base = `/api/cases/${c.id}`;
  const sim = (kind: string) => run(kind, `${base}/simulate`, { kind });

  return (
    <section aria-labelledby="demo-h" className="rounded-[1.5rem] border-2 border-dashed border-warn/60 bg-warn-soft/50 p-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <h2 id="demo-h" className="font-display text-xl font-extrabold">Demo mode controls</h2>
        <span className="text-xs font-semibold text-warn">Only the outside world is simulated. The agents really run.</span>
      </div>
      <div className="mt-4 flex flex-wrap gap-2">
        <button className="btn-dark" disabled={!!busy} onClick={() => run("advance", `${base}/advance`)}>
          <FastForward className="h-4 w-4" aria-hidden /> {busy === "advance" ? "Advancing…" : "Advance case"}
        </button>
        <button className="btn-ghost" disabled={!!busy || !monitoring} onClick={() => sim("delay")} title={monitoring ? "" : "Available while the case is monitoring"}>Simulate delay</button>
        <button className="btn-ghost" disabled={!!busy || !monitoring} onClick={() => sim("response_ack")} title={monitoring ? "" : "Available while the case is monitoring"}>Simulate response</button>
        <button className="btn-ghost" disabled={!!busy || !monitoring} onClick={() => sim("response_blocker")} title={monitoring ? "" : "Available while the case is monitoring"}>Simulate blocker response</button>
        <button className="btn-ghost" disabled={!!busy || !monitoring} onClick={() => sim("resolution_evidence")} title={monitoring ? "" : "Available while the case is monitoring"}>Provide resolution evidence (demo)</button>
        <button className="btn-ghost" disabled={!!busy || !canVerify} onClick={() => run("verify", `${base}/verify`)}>Run verification</button>
        <button className="btn-ghost" disabled={!!busy || !monitoring} onClick={() => run("monitor", `${base}/monitor`)}>Run monitoring check</button>
      </div>
      <div className="mt-4 border-t border-warn/30 pt-4">
        <p className="text-sm text-ink-soft">Have a real confirmation document? Upload it as resolution evidence instead of using the demo sample.</p>
        <button className="btn-ghost mt-2" disabled={!!busy || !monitoring} onClick={() => file.current?.click()}>
          <FileUp className="h-4 w-4" aria-hidden /> Upload resolution evidence
        </button>
        <input ref={file} type="file" className="sr-only" aria-label="Upload resolution evidence" accept=".pdf,.docx,.txt,.png,.jpg,.jpeg" onChange={(e) => { const f = e.target.files?.[0]; if (f) onUpload(f); e.target.value = ""; }} />
      </div>
      {busy && <p role="status" className="mt-3 text-sm font-semibold text-ink-soft">Working: agents are running…</p>}
    </section>
  );
}
