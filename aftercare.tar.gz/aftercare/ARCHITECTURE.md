# Architecture

```
Browser (Next.js UI) ──► /api/* route handlers (auth + zod validation)
                              │
                              ▼
                    lib/workflow/orchestrator.ts   ◄── state machine (lib/state-machine.ts)
                    │        │        │
        agents (lib/agents)  │   retrieval (lib/retrieval)
        + prompts            │        │
                 │           ▼        ▼
                 └──────► Supabase Postgres + pgvector + Storage
                              ▲
                     OpenAI (lib/llm.ts, structured JSON + zod)
```

## Principle
The LLM never owns state. The database does. Agents read persisted case state, return schema-validated JSON, and the orchestrator decides legal transitions. Time-based facts (is a response overdue?) come from deterministic code in `lib/monitoring-rules.ts`; the Monitoring Agent explains the blocker and chooses the recovery path.

## Agents (`lib/agents`, prompts in `lib/prompts`)
| Agent | Input | Output |
|---|---|---|
| Intake | user text | category, desired outcome, urgency, missing info, expected response window |
| Evidence | retrieved chunks | found items (with quote + chunk), missing items, INSUFFICIENT_EVIDENCE |
| Planner | persisted case state | steps with dependencies and approval flags, next action |
| Action | case state + real evidence labels | draft message (never executed by the agent) |
| Monitoring & Recovery | deterministic deviation + history | blocker, why it matters, FOLLOW_UP / ESCALATE / HUMAN_INTERVENTION |
| Verification | resolution chunks + history | RESOLUTION_VERIFIED / NOT_RESOLVED / INSUFFICIENT_EVIDENCE |

Every run is stored in `agent_runs` (output, model, confidence, duration, error).

## State machine
16 states, explicit legal transitions. `transition()` in `lib/workflow/events.ts` rejects illegal moves (HTTP 409), updates the case, and inserts a row in `state_transitions` with trigger and agent. The UI renders this history and the timeline from `agent_events`.

## Flows
- `POST /api/cases` creates the case. Documents upload against it. `POST /api/cases/:id/analyze` runs intake → evidence → planner → action draft and lands in `WAITING_FOR_APPROVAL`.
- `POST /approve` records the approval (with edits if any), executes the action **in simulated mode** (stored as a communication flagged `simulated`), sets the response deadline, activates monitoring.
- `POST /monitor`: deviation none / response_received / overdue. Overdue → `BLOCKED` → blocker row → replan → drafted follow-up or escalation → `WAITING_FOR_APPROVAL`.
- `POST /verify`: Verification Agent plus a hard guard (see below). Verified → `COMPLETED`; otherwise the case returns to `MONITORING` with a new blocker.
- `POST /reject`: stores the rejection, replans with your note, drafts a revised action.

## Safety mechanisms in code
- Outbound actions are only ever created as `pending_approval`; only `/approve` executes them, and only for the signed-in owner.
- Evidence grounding: a "found" item survives only if its quote literally appears in the cited chunk (`quoteIsGrounded`). If none survive, the verdict becomes INSUFFICIENT_EVIDENCE. With no readable documents the model is not called at all.
- Resolution guard: `RESOLUTION_VERIFIED` is downgraded unless the quote is found in a **resolution** document chunk.
- The Action Agent can only cite evidence labels that exist in the database; others are stripped.
- Demo controls can be disabled server-side with `NEXT_PUBLIC_DEMO_MODE=false`.
- Uploads: MIME allow-list, 8 MB limit, private bucket, ownership checks on every route.

## Demo simulation
`simulate` and `advance` only create the external world: advance the case clock, add an inbound message, add a sample confirmation document. Everything after that (monitoring, blocker, replanning, verification) is the real workflow. All such events carry a visible "Simulated" label.
